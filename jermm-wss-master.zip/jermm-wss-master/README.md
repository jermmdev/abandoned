# jermm-wss
A simple wss wrapper used in jermm-bots.
