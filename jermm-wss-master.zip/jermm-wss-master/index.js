let crypto = require('crypto')
let WebSocket = require('ws')
let jermmWss = function(port, server) {
    let wss = {}
    if(server){
        wss = new WebSocket.Server({server: server})
    }
    else {
        console.log('wssListening')
        wss = new WebSocket.Server({port: port})
    }
    let core = this
    core.connected = {}
    core.onConnect = (wsId) => {}
    core.onMessage = (msg, wsId) => {}
    core.onClose = (closeCode, wsId) => {}
    core.badMessage = (wsId) => {}
    core.GetSocket = (address)=>{
        let newWs = new WebSocket(address)
        newWs.sendify = (msg)=>{
            try{
                msg = JSON.stringify(msg)
            }catch(err){
                console.error(err)
                return false
            }
            newWs.send(msg)
        }
        newWs.onOpen = ()=>{}
        newWs.on('open', ()=>{
            newWs.onOpen()
        })
        newWs.on('error', (err)=>{
            console.error(err)
        })
        newWs.onMessage = (msg)=>{}
        newWs.on('message', (msg) => {
            try{
                msg = JSON.parse(msg)
            }catch(err){
                console.error(err)
                return false
            }
            newWs.onMessage(msg)
            return true
        })
        newWs.onClose = () => {}
        newWs.on('close', (closeCode)=>{
            newWs.onClose(closeCode)
        })
        return newWs 
    }
    wss.on('connection', (ws, req) => {
        let created = Date.now()
        let wsId = crypto
            .createHash('md5')
            .update(
                req.headers['x-forwarded-for'] 
                + req.connection.remoteAddress 
                + req.headers['user-agent']
                + created
            ).digest('hex')
        ws.sendify = (msg) => {
            try{
                msg = JSON.stringify(msg)
            }catch(err){
                console.error(err)
                return false
            }
            ws.send(msg)
        }
        ws.on('message', (msg) => {
            try{
                msg = JSON.parse(msg)
            }catch(err){
                core.onBadMessage(msg, wsId)
                console.error(err)
                return false
            }
            core.onMessage(msg, wsId)
            return true
        })
        ws.on('close', (closeCode) => {
            delete core.connected[wsId]
            core.onClose(closeCode, wsId)
        })
        core.connected[wsId] = {
            ws: ws
            , req: {
                headers: req.headers
                , body: req.body
                , remoteAddress: req.connection.remoteAddress
            }
            , created: created
        }
        core.onConnect(wsId)
    })
    if(server) {
        server.listen(port, ()=>{
            console.log('wssListening')
        })
    }
}
module.exports = jermmWss