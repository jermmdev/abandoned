let path = require('path')
let jtls = require(path.join(__dirname, 'jermm-tls.js'))
let Events = require('events')
let worker = function(inputBotName, stimergyPath){
    let core = this
    core.events = new Events()
    let stimergySocket = jtls.connect(stimergyPath)
    stimergySocket.on('close', closeCode => {
        console.log('Stimergy Connection Closed')
    })
    stimergySocket.on('error', err => {
        console.error('Stimergy Socket', err)
    })
    stimergySocket.on('open', ()=>{
        console.log('Stimergy Connected')
        stimergySocket.write(JSON.stringify({brain: inputBotName}))
        stimergySocket.on('data', data => {
            data = JSON.parse(data)
            core.search = searchInput => {
                let searchResults = {}
                for(let searchInd in searchInput){
                    let input = searchInput[searchInd]
                    for(let outcome in core.trainers[trainerName].bots[data.botName][input]){
                        if(!searchResults[outcome]) searchResults[outcome] = 0
                        searchResults[outcome] += core.trainers[trainerName].bots[data.botName][input][outcome]
                    }
                }
                let sortedKeys = Object.keys(searchResults).sort((a, b)=>{
                    return searchResults[a]-searchResults[b]
                })
                return searchResults[sortedKeys[0]]
            }
            core.events.emit('botOnline')
            stimergySocket.close()
        })
    })
}
module.exports = worker