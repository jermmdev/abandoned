# jermm-worker
A worker bot for a jermm colony
