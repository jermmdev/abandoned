let fs = require('fs')
let path = require('path')
let tls = require('tls')
let requestOptions = {
    key: fs.readFileSync('key.pem')
    , cert: fs.readFileSync('cert.pem')
    , ca: []
    , dhparam: fs.readFileSync('dhparam.pem')
}
let stimergyCertsDir = path.join(__dirname, '/stimergyCerts')
let stimergyCerts = fs.readdirSync(stimergyCertsDir)
for(let certInd in stimergyCerts){
    requestOptions.ca.push(fs.readFileSync(path.join(stimergyCertsDir, stimergyCerts[certInd])))
}
module.exports = {
    connect: (port, domain) => {
        return tls.connect(port, domain, requestOptions)
    }
}