var jermmDash = {};

jermmDash.extensionList = [];
jermmDash.extensions = [];
jermmDash.extensionsLoaded = 0;
jermmDash.widgetList = [];
jermmDash.activeWidget = null;


/** START: load extensions **/
jermmDash.currentExtension = 0;

jermmDash.loadExtensions = function(){
    console.log('jd:loadExtensions');
    jermmDash.loadExtensionList();
    jermmDash.loadExtension();
    return;
}

jermmDash.loadExtensionList = function(){
    console.log('jd:loadExtensionList');
    var extensionList = $('#extensionList').children();
    for(var i=0; i<extensionList.length; i++){
        var extName = extensionList[i].value;
        jermmDash.extensionList.push(extName);
    }
    return;
}

jermmDash.loadExtension = function(){
    console.log('jd:loadExtensions');
    if(jermmDash.currentExtension < jermmDash.extensionList.length){
        console.log('jd:loadExtensions:moreToLoad');
        var extName = jermmDash.extensionList[jermmDash.currentExtension]
        jermmDash.extensions[extName] = new window[extName]();
        jermmDash.checkRequirements(jermmDash.extensions[extName]);
        jermmDash.extensions[extName].open(function(){ jermmDash.loadExtensionCallback(extName); })
        return;
    }else{
        console.log('jd:loadExtensions:allLoaded')
        jermmDash.loadFirstWidget();
        return;
    }
}

jermmDash.checkRequirements = function(extension){
    console.log('jd:checkRequirements');
    if(typeof extension.requires == 'array'){
        for(var i=0; i < extension.requires.length; i++){
            if(!jermmDash.extensionList.includes(extension.requires[i])){
                alert('Requirement not met.  \r\n' + extension.requires[i] + ' (Missing)');
                exit();
            }else{
                console.log('jd:checkRequirements:' + extension.requires[i] + ':loaded');
            }
        }
        if(extension.requires.length == 0){ console.log('jd:checkRequirements:noRequirements'); }
    }
}

jermmDash.loadExtensionCallback = function(extName){
    console.log('jd:loadExtensionCallback: ' + extName);
    console.log('jd:ex:' + extName + ':ready');
    $('body').trigger('extensionLoaded');
    jermmDash.currentExtension++;
    jermmDash.loadExtension();
}
/** END: load extensions **/

/** START: load widgets **/
jermmDash.loadWidget = function(wdgName){
    console.log('jd:loadWidget');
    jermmDash.activeWidget = new window[wdgName]();
    jermmDash.activeWidget.open(jermmDash.openWidgetCallback);
    return;
}

jermmDash.loadFirstWidget = function(){
    console.log('jd:loadFirstWidget');
    jermmDash.loadWidgetList();
    jermmDash.loadWidget(jermmDash.widgetList[0]);
    return;
}

jermmDash.loadWidgetList = function(){
    console.log('jd:loadWidgetList');
    var widgetList = $('#widgetList').children();
    for(var i=0; i<widgetList.length; i++){
        var wdgName = widgetList[i].value;
        jermmDash.widgetList.push(wdgName);
    }
    return;
}

jermmDash.baseContentHeight = null;
jermmDash.openWidgetCallback = function(){
    console.log('jd:openWidgetCallback');
    jermmDash.baseContentHeight = $('.jdAppContent').height();
    jermmDash.showWidget();
    return;
}
/** END: load widgets **/

/** START: button navigation **/
jermmDash.showWidgetCallback = null;
jermmDash.showWidget = function(finishedShowingCb){
    console.log('jd:showWidget');
    jermmDash.showWidgetCallback = finishedShowingCb;
    jermmDash.setHolderHeight();
}

jermmDash.setHolderHeight = function(){
    var widgetHolder = $('#jdWidgetContent');
    jermmDash.activeWidget.widgetContent.hide();
    widgetHolder.append(jermmDash.activeWidget.widgetContent);
    var contentHeight = jermmDash.activeWidget.widgetContent.height();
    $('#jdWidgetContent').animate({height: contentHeight}, 300, jermmDash.fadeInContent);
    return;
}

jermmDash.fadeInContent = function(){
    var widgetHolder = $('#jdWidgetContent');
    widgetHolder.css('height','auto'); 
    jermmDash.activeWidget.widgetContent.fadeIn(300, jermmDash.finishedShowing);
}

jermmDash.finishedShowing = function(){
    console.log('jd:finishedShowing');
    if(jermmDash.showWidgetCallback != null){
        jermmDash.showWidgetCallback();
        jermmDash.showWidgetCallback = null;
    }
    $('body').trigger('widgetLoaded');
}

jermmDash.hideWidgetCallback = null;
jermmDash.hideWidget = function(finishedHidingCb){
    console.log('jd:hideWidget');
    jermmDash.hideWidgetCallback = finishedHidingCb;
    jermmDash.fadeOutContent();
    return;
}

jermmDash.fadeOutContent = function(){
    var widgetHolder = $('#jdWidgetContent');
    var curHeight = jermmDash.activeWidget.widgetContent.height();
    console.log('curHeight: ' + curHeight);
    widgetHolder.height(curHeight);
    jermmDash.activeWidget.widgetContent.fadeOut(300, jermmDash.resetHolderHeight);
}
jermmDash.resetHolderHeight = function(){
    $('#jdWidgetContent').animate({height: jermmDash.baseContentHeight}, 300, jermmDash.finishedHiding);

}
jermmDash.finishedHiding = function(){
    console.log('jd:finishedHiding');
    if(jermmDash.hideWidgetCallback != null){
        jermmDash.hideWidgetCallback();
        jermmDash.hideWidgetCallback = null;
    }
}

jermmDash.widgetButtonPressed = null;
jermmDash.buttonPressed = function(wdgName){
    console.log('jd:buttonPressed');
    jermmDash.widgetButtonPressed = wdgName;
    jermmDash.hideWidget(jermmDash.closeWidget);
}

jermmDash.closeWidget = function(){
    console.log('jd:closeWidget');
    jermmDash.activeWidget.close(jermmDash.loadNextWidget);
}

jermmDash.loadNextWidget = function(){
    console.log('jd:loadNextWidget');
    delete jermmDash.activeWidget;
    jermmDash.activeWidget = null;
    jermmDash.loadWidget(jermmDash.widgetButtonPressed);
    jermmDash.widgetButtonPressed = null;
}
/** END: button navigation **/

/** START: Utilities **/
//Get the current unix timestamp in seconds.
jermmDash.currentUnix = function(){
    return Math.round((new Date()).getTime() / 1000);
}

//Some animation functions.
$.fn.extend({
    animateCss: function(animationName) {
        var animationEnd = 'webkitAnimationEnd mozAnimationEnd MSAnimationEnd oanimationend animationend';
        this.addClass('animated ' + animationName).one(animationEnd, function() {
            $(this).removeClass('animated ' + animationName);
        });
    },
    zoomHide: function(endTrigger){
        this.isHiding = true;
        var animationEnd = 'webkitAnimationEnd mozAnimationEnd MSAnimationEnd oanimationend animationend';
        this.addClass('animated zoomOut').one(animationEnd, function() {
            $(this).css('display', 'none');
            $(this).removeClass('animated zoomOut');
            if(typeof endTrigger != 'undefined'){
                endTrigger();
            }
            this.isHiding = false;
        });
    },
    zoomShow: function(endTrigger){
        this.isShowing = true;
        var animationEnd = 'webkitAnimationEnd mozAnimationEnd MSAnimationEnd oanimationend animationend';
        $(this).css('display', 'block');
        this.addClass('animated zoomIn').one(animationEnd, function() {
            $(this).removeClass('animated zoomIn');
            if(typeof endTrigger != 'undefined'){
                endTrigger();
            }
            this.isShowing = false;
        });
    }
});
/** END: Utilities**/


/** START: Activate Dashboard **/
console.log('jd:activateJermmDash');

//Fill empty app space with white.
$('.jdAppContent').css('min-height',$('.container').height());
//Get 'er rollin'.
jermmDash.loadExtensions();

/** END: Activate Dashboard **/