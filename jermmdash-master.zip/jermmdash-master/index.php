<?php include 'viewCode.php'; ?>

<html>
	<head>
		<!-- START: metadata -->
		<?php echo file_get_contents('meta.html'); ?>
		<!-- END: metadata -->

		<!-- START: main styles -->
		<?php foreach($viewData['styles'] as $style) : ?>
			<link rel="stylesheet" href="<?php echo $style; ?>">
		<?php endforeach; ?>
		<!-- END: main styles -->

		<!-- START:  dashboard style -->
		<link rel="stylesheet" href="jermmDash.css">
		<!-- END:  dashboard style -->

		<!-- START: plugin styles -->
		<?php foreach($viewData['extensions'] as $ext) : ?>
			<?php if(file_exists('extensions/'.$ext.'/'.$ext.'.css')) : ?>
				<link rel="stylesheet" href="extensions/<?php echo $ext.'/'.$ext; ?>.css">
			<?php endif; ?>
		<?php endforeach; ?>
		<?php foreach($viewData['widgets'] as $wdg) : ?>
			<?php if(file_exists('widgets/'.$wdg.'/'.$wdg.'.css')) : ?>
				<link rel="stylesheet" href="widgets/<?php echo $wdg.'/'.$wdg; ?>.css">
			<?php endif; ?>
		<?php endforeach; ?>
		<!-- END: plugin styles -->

	</head>
	<body>
		<!-- START: installed plugins -->
		<div id="extensionList">
			<?php foreach($viewData['extensions'] as $ext) : ?>
				<input type="hidden" value="<?php echo $ext; ?>" >
			<?php endforeach; ?>
		</div>
		<div id="widgetList">
			<?php foreach($viewData['widgets'] as $wdg) : ?>
				<input type="hidden" value="<?php echo $wdg; ?>" >
			<?php endforeach; ?>
		</div>
		<!-- END: installed plugins -->

		<!-- START: extension html -->
		<?php foreach($viewData['extensions'] as $ext) : ?>
			<?php if(file_exists('extensions/'.$ext.'/'.$ext.'.html')) : ?>
				<?php echo file_get_contents('extensions/'.$ext.'/'.$ext.'.html'); ?>
			<?php endif; ?>
		<?php endforeach; ?>
		<!-- END: extension html -->



		<!-- START: main app -->
		<div class="container">
			<!--START: navigation -->
			<div class='col-sm-2 jdSideNav'>
				<?php foreach($viewData['widgets'] as $wdg) : ?>
					<div class="jdAppIcon <?php echo $wdg.'Icon'; ?>" onclick="jermmDash.buttonPressed('<?php echo $wdg; ?>');">
						<img src="widgets/<?php echo $wdg; ?>/icon.png"></div>
				<?php endforeach; ?>
			</div>
			<!-- END: navigation -->
			<!-- START: widget content -->
			<div class='col-sm-10 jdAppContent'>
				<div id='jdWidgetContent'>
				</div>
			</div>
			<!-- END: widget content -->
		</div>
		<!-- END: main app -->



		<!-- START: main scripts -->
		<?php foreach($viewData['scripts'] as $script) : ?>
			<script type="text/javascript" src="<?php echo $script; ?>"></script> 
		<?php endforeach; ?>
		<!-- END: main scripts -->

		<!-- START: plugin scripts -->
		<?php foreach($viewData['extensions'] as $ext) : ?>
			<?php if(file_exists('extensions/'.$ext.'/'.$ext.'.js')) : ?>
				<script type="text/javascript" src="extensions/<?php echo $ext.'/'.$ext; ?>.js"></script> 
			<?php endif; ?>
		<?php endforeach; ?>
		<?php foreach($viewData['widgets'] as $wdg) : ?>
			<?php if(file_exists('widgets/'.$wdg.'/'.$wdg.'.js')) : ?>
				<script type="text/javascript" src="widgets/<?php echo $wdg.'/'.$wdg; ?>.js"></script>
			<?php endif; ?>
		<?php endforeach; ?>
		<!-- END: plugin scripts -->

		<!-- START: load the dashboard js -->
			<script type="text/javascript" src="jermmDash.js"></script>
		<!-- START: load the dashboard js -->

	</body>
</html>