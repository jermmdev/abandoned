var scrollToTop = function(){
    this.requires = [];
    var core = this;

    this.open = function(openCb){
        console.log('jd:ex:scrollToTop:open');
        setUpEvents();
        openCb();
    }

    var setUpEvents = function(){
        console.log('jd:ex:scrollToTop:setUpEvents');
        $(function() {
            $(document).on('scroll', function() {
                if ($(window).scrollTop() > 150) {
                    $('.scroll-top-wrapper').addClass('show');
                } else {
                    $('.scroll-top-wrapper').removeClass('show');
                }
            });
            $('.scroll-top-wrapper').on('click', jermmDash.extensions['scrollToTop'].scroll);
        });
    }

    this.scroll = function(){
        console.log('jd:ex:scrollToTop:scroll');
        verticalOffset = typeof(verticalOffset) != 'undefined' ? verticalOffset : 0;
        element = $('body');
        offset = element.offset();
        offsetTop = offset.top;
        $('html, body').animate({
            scrollTop: offsetTop
        }, 500, 'linear');
    }
}