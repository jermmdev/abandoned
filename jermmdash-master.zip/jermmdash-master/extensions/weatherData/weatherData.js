var weatherData = function(){
    var units = "us";
    var refreshSeconds = 300;
    var autoLoad = true;

    this.requires = ['locationData'];
    var core = this;
    var weatherInfo = null;
    var location = null;

    var openCallback = null;
    this.open = function(openCallbackCB){
        openCallback = openCallbackCB;
        console.log('jd:ex:weatherData:open');
        if(autoLoad){
            console.log('jd:ex:weatherData:open:autoLoad');
            this.getWeatherData();
            return;
        }else{
            console.log('jd:ex:weatherData:open:noAutoLoad');
            openCallback();
            return;
        }
    }
    
    var processWeatherData = null;
    this.getWeatherData = function(processWeatherDataCB){
        processWeatherData = processWeatherDataCB;
        console.log('jd:ex:weatherData:getWeatherData');
        if(weatherInfo == null || jermmDash.currentUnix() - weatherInfo.update > refreshSeconds){
            console.log('jd:ex:weatherData:getLatLon:dataNotSet');
            getLocation();
            return;
        }else{
            console.log('jd:ex:weatherData:getLatLon:dataIsSet');
            processWeatherData(weatherInfo.json);
            processWeatherData = null;
            openCallback = null;
            return;
        }
    }

    var getLocation = function(){
        console.log('jd:ex:weatherData:getLocation');
        jermmDash.extensions['locationData'].getLatLon(callWeatherData);
    }

    var setWeatherDataFail = 0;
    var callWeatherData = function(latLon){
        console.log('jd:ex:weatherData:callWeatherData');
        var weatherUrl = "https://api.darksky.net/forecast/0214ddf09c891cbcc6919d1447cae41c/" + latLon.latitude + "," + latLon.longitude + "?callback=?&exclude=minutely,alerts,flags&units=" + units;
        $.getJSON(weatherUrl).then(function(json) {
            console.log('jd:ex:weatherData:callWeatherData:responseReceived');
            setWeatherData(json);
            return;
        }).fail(function() {
            console.log('jd:ex:weatherData:callWeatherData:responseFailed');
            callWeatherDataFailReaction();
            return;
        });
        return;
    }

    var callWeatherDataFailReaction = 0;
    var callWeatherDataFailReaction = function(){
        console.log('jd:ex:weatherData:callWeatherDataFailReaction');
        callWeatherDataFailReaction++;
        if(callWeatherDataFailReaction < 10){
            console.log('jd:ex:weatherData:callWeatherDataFailReaction:retrying');
            setTimeout(callWeatherData, 500);
            return;
        }else{
            callWeatherDataFailReaction = 0;
            alert('jd:ex:weatherData:callWeatherDataFailReaction:CRASH \r\nhttps://api.darksky.net/ failed to respond.');
            exit();
        }
    }

    var setWeatherData = function(data){
        console.log('jd:ex:locationData:setWeatherData');
        callWeatherDataFailReaction = 0;
        weatherInfo = {};
        weatherInfo.json = data;
        weatherInfo.update = jermmDash.currentUnix();
        if(openCallback == null){
            core.getWeatherData(processWeatherData);
            processWeatherData = null;
            return;
        }else{
            core.getWeatherData(openCallback);
            openCallback = null;
            return;
        }
    }
}
