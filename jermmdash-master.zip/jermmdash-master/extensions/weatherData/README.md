Similar to the location data (and relies on it), this one sets weather data for other plugins to access.  It also relies on callbacks when giving DarkSky's json weather response for our lat/lon.

```js
jermmDash.extensions['weatherData'].getWeatherData(processWeatherDataCB);
var processWeatherDataCB = function(json){
	//do stuff with weather data
}
```

So don't be expecting a return value here.  Callback.