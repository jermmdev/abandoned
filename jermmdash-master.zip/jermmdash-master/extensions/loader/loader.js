var loader = function(){
	var core = this;
	this.requires = [];

	var extensionList = [];
	var loaded = 0;
	var done = false;

	this.open = function(openCB){
        console.log('jd:ex:loader:open');
		extensionList = $('#extensionList').children();
		$('body').on('extensionLoaded', extensionLoaded);
		$('body').on('widgetLoaded', widgetLoaded);
		openCB();
	}

	var extensionLoaded = function(){
		if(!done){
	        console.log('jd:ex:loader:extensionLoaded');
			loaded++;
			var perc = Math.round((loaded/(extensionList.length+1))*100);
			setLoader(perc);
		}
	}

	var widgetLoaded = function(){
		if(!done){
	        console.log('jd:ex:loader:widgetLoaded');
			setLoader(100);
			closeLoader();
			done=true;
		}
	}

	var setLoader = function(perc) {
        console.log('jd:ex:loader:setLoader');
	    $('.progress-bar').css('width',perc+'%');
	}

	var closeLoader = function(){
        console.log('jd:ex:loader:closeLoader');
		$('.se-pre-con').animateCss("slideOutLeft");
		$('.se-pre-con').css({
		    "opacity": 0,
		    "z-index": -1,
		    "transition": "z-index 0.8s step-end, opacity 0.5s linear"
		});
	}
}
