var locationData = function(){
    var autoLoad = true;

    this.requires = [];
    var core = this;
    var latLon = null;

    var openCallback = null;
    this.open = function(openCallbackCB){
        openCallback = openCallbackCB;
        console.log('jd:ex:locationData:open');
        if(autoLoad){
            console.log('jd:ex:locationData:open:autoLoad');
            this.getLatLon(openCallbackCB);
            return;
        }else{
            console.log('jd:ex:locationData:open:noAutoLoad');
            openCallback();
            return;
        }
    }

    var processLatLon = null;
    this.getLatLon = function(processLatLonCB){
        processLatLon = processLatLonCB;
        console.log('jd:ex:locationData:getLatLon');
        if(latLon == null){
            console.log('jd:ex:locationData:getLatLon:dataNotSet');
            callLocationData();
            return;
        }else{
            console.log('jd:ex:locationData:getLatLon:dataIsSet');
            processLatLon(latLon);
            return;
        }
    }

    var callLocationData = function(){
        console.log('jd:ex:locationData:callLocationData');
        var ipInfoUrl = 'https://ipinfo.io/json';

        $.getJSON(ipInfoUrl, processLocationData).fail(callLocationDataFailReaction);
    }

    var callLocationDataFailReaction = 0;
    var callLocationDataFailReaction = function(){
        console.log('jd:ex:locationData:callLocationDataFailReaction');
        callLocationDataFailReaction++;
        if(callLocationDataFailReaction < 10){
            console.log('jd:ex:locationData:callLocationDataFailReaction:retrying');
            setTimeout(callLocationData, 500);
            return;
        }else{
            callLocationDataFailReaction = 0;
            alert('jd:ex:locationData:callLocationDataFailReaction:CRASH \r\nhttps://ipinfo.io/ failed to respond correctly.');
            exit();
        }
    }

    var processLocationData = function(data){
        console.log('jd:ex:locationData:processLocationData');
        if(typeof data == 'undefined' || typeof data.loc == 'undefined'){
            console.log('jd:ex:locationData:processLocationData:badData');
            callLocationDataFailReaction();
            return;
        }else{
            console.log('jd:ex:locationData:processLocationData:goodData');
            setLocationData(data);
            return;
        }
    }

    var setLocationData = function(data){
        console.log('jd:ex:locationData:setLocationData');
        callLocationDataFailReaction = 0;
        var coords = data.loc.split(",");
        latLon = {};
        latLon.latitude = coords[0];
        latLon.longitude = coords[1];
        if(openCallback == null){
            core.getLatLon(processLatLon);
            return;
        }else{
            core.getLatLon(openCallback);
            openCallback = null;
            return;
        }
    }
}