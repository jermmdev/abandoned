Simple location tracking from IP for now.  Gives back an object called latLon that is a json with latLon.latitude and latLon.longitude.  Must be processed with a callback.

```js
jermmDash.extensions['locationData'].getLatLon(processLatLonCB);
var processLatLonCB = function(latLon){
	//do stuff with location info
}
```

So don't be expecting a return value here.  Callback.