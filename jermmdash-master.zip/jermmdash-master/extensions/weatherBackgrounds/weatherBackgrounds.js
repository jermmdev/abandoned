var weatherBackgrounds = function(){
    var autoLoad = true;
    var units = "us";
    var refreshTimer = 301000;  //ms

    this.requires = [];
    var core = this;

    var sunriseBegin = null
    var sunriseEnd = null;
    var sunsetBegin = null;
    var sunsetEnd = null;
    var currentTime = null;

    var openCallback = null;
    this.open = function(openCallbackCB){
        console.log('jd:ex:weatherBackgrounds:open');
        if(autoLoad){
            openCallback = openCallbackCB;  
            console.log('jd:ex:weatherBackgrounds:open:autoLoad');
            prepUI();
            refreshBg();
            return;            
        }else{
            console.log('jd:ex:weatherBackgrounds:open:noAutoLoad');
            openCallbackCB();
            return;
        }
    }

    var prepUI = function() {
        console.log('jd:ex:weatherBackgrounds:prepUI');
        var div = document.createElement('div');
        div.id = 'weatherEffect';
        $('body').append(div);
        var div = document.createElement('div');
        div.id = 'cloudEffect';
        $('body').append(div);
        return;
    }

    var refreshBg = function(){
        console.log('jd:ex:weatherBackgrounds:refreshBg');
        getWeatherData(processWeatherData);
        setTimeout(refreshBg, refreshTimer);
        return;
    }

    var getWeatherData = function(processWeatherData){
        console.log('jd:ex:weatherBackgrounds:getWeatherData');
        jermmDash.extensions['weatherData'].getWeatherData(processWeatherData);
        return;
    }

    var oldBgData = null;
    var processWeatherData = function(json){
        console.log('jd:ex:weatherBackgrounds:processWeatherData');
        setSunriseTimes(json);
        var bgData = getBgData(json.currently.icon);
        if(oldBgData == null || !(
            bgData.img == oldBgData.img 
            && bgData.effect == oldBgData.effect
            && bgData.cloud == oldBgData.cloud
        )){
            console.log('jd:ex:weatherBackgrounds:processWeatherData:newData');
            setWeatherBackground(bgData);
        }
        oldBgData = bgData;
        return;
    }

    var setSunriseTimes = function(json) {
        console.log('jd:ex:weatherBackgrounds:setSunriseTimes');
        var fmt = "h:mm A ddd, MM/DD";
        var fmt1 = "h:mm A";
        var compareFmt = "YYYYMMDDHHmm";
        var newTime = convertTime(json.currently.time, json.timezone, fmt);
        var newSunrise = convertTime(json.daily.data[0].sunriseTime, json.timezone, fmt1);
        sunriseBegin = parseInt(convertTime(json.daily.data[0].sunriseTime - 3600, json.timezone, compareFmt));
        sunriseEnd = parseInt(convertTime(json.daily.data[0].sunriseTime + 3600, json.timezone, compareFmt));
        var newSunset = convertTime(json.daily.data[0].sunsetTime, json.timezone, fmt1);
        sunsetBegin = parseInt(convertTime(json.daily.data[0].sunsetTime - 3600, json.timezone, compareFmt));
        sunsetEnd = parseInt(convertTime(json.daily.data[0].sunsetTime + 3600, json.timezone, compareFmt));
        var date = new Date();
        currentTime = parseInt(date.getFullYear() + "" + addLeadZero((date.getMonth() + 1)) + "" + addLeadZero(date.getDate()) + "" + addLeadZero(date.getHours()) + "" + addLeadZero(date.getMinutes()));
        return;
    }

    var convertTime = function(input, timezone, format) {
        var timestamp = moment.unix(input);
        return moment(timestamp).tz(timezone).format(format);
    }

    var addLeadZero = function(num) {
        if (num < 10) {
            num = "0" + num;
            return num;
        } else {
            return num + "";
        }
    }

    var getBgData = function(currentIcon) {
        console.log('jd:ex:weatherBackgrounds:getBgData');
        var img, effect, cloud;
        img = "extensions/weatherBackgrounds/images/" + getSunState() + ".png";
        switch (currentIcon) {
            case "rain":
                effect = 'rain';
                break;
            case "clear-day":
                break;
            case "partly-cloudy-day":
                cloud = 'cloudLight';
                break;
            case "clear-night":
                break;
            case "partly-cloudy-night":
                cloud = 'cloudLight';
                break;
            case "snow":
                effect = 'snow';
                break;
            case "sleet":
                effect = 'snow';
                break;
            case "wind":
                break;
            case "cloudy":
                cloud = 'cloudDark';
                break;
            case "fog":
                effect = 'fog';
                break;
            default:
                //nothing
        }
        var results = {
            img: img,
            effect: effect,
            cloud: cloud
        };
        return results;
    }

    var getSunState = function() {
        console.log('jd:ex:weatherBackgrounds:getSunState');
        if (currentTime < sunriseBegin) {
            console.log('jd:ex:weatherBackgrounds:getSunState:night');
            return "night";
        }
        if (sunriseBegin <= currentTime && currentTime < sunriseEnd) {
            console.log('jd:ex:weatherBackgrounds:getSunState:sunrise');
            return "sunrise";
        }
        if (sunriseEnd <= currentTime && currentTime < sunsetBegin) {
            console.log('jd:ex:weatherBackgrounds:getSunState:day');
            return "day";
        }
        if (sunsetBegin <= currentTime && currentTime < sunsetEnd) {
            console.log('jd:ex:weatherBackgrounds:getSunState:sunset');
            return "sunset";
        }
        if (sunsetEnd <= currentTime) {
            console.log('jd:ex:weatherBackgrounds:getSunState:night');
            return "night";
        }
    }

    var setWeatherBackground = function(bgData){
        console.log('jd:ex:weatherBackgrounds:setWeatherBackground');
        $('body').css({
            'background': "linear-gradient(to bottom, rgba(255,255,255,0), rgba(255,255,255,0)), url(" + bgData.img + ") center repeat",
            'background-attachment': 'fixed',
            'background-size': 'cover',
        });
        $('#weatherEffect').removeClass();
        $('#weatherEffect').addClass(bgData.effect);
        $('#cloudEffect').removeClass();
        $('#cloudEffect').addClass(bgData.cloud);
        $('body').trigger('backgroundChanged');
        if(openCallback != null){
            openCallback();
            openCallback = null;
        }
        return;
    }
}