/** START: Manage the "transparency" effect which is really a fancy positioning of the bg to match. **/

/** END: Manage the "transparency" effect which is really a fancy positioning of the bg to match. **/

var weather = function(){
    var units = "us";
    var deg = "&deg;F";
    var isRepeating = false;
    var repeatTimer = 301000; //ms
    
    this.widgetContent = null;
    this.requires = ['weatherData', 'locationData'];
    var core = this;

    //todo: replace icon reset functionality with liveIcon extension plugged into in this file

    var openCallback = null;
    this.open = function(openCallbackCB){
        console.log('jd:wd:weather:open');
        openCallback = openCallbackCB;
        isRepeating = true;
        core.refreshContent();
    }

    this.close = function(closeCallbackCB){
        console.log('jd:wd:weather:close');
        isRepeating = false;
        closeCallbackCB();
    }

    this.refreshContent = function(){
        console.log('jd:wd:weather:refreshContent');
        if(openCallback == null){
            jermmDash.extensions['weatherData'].getWeatherData(processWeatherData);
        }else{
            getHtml();
        }
        if(isRepeating){
            setTimeout(core.refreshContent, repeatTimer);
        }
    }

    var getHtml = function(){
        console.log('jd:wd:weather:getHtml');
        $.get('widgets/weather/weather.html', processHtml);
    }

    var processHtml = function(data){
        console.log('jd:wd:weather:processHtml');
        core.widgetContent = $(data);
        jermmDash.extensions['weatherData'].getWeatherData(processWeatherData);
    }

    var processWeatherData = function(json){
            console.log('jd:wd:weather:processWeatherData');
            setMainPanel(json);
            var arr = json.daily.data;
            for(var i=arr.length; i > 6; i--){
                arr.pop();
            }
            var subDays = [];
            for (i = 0; i < arr.length; i++) {
                var html = setSubPanel(json.daily.data[i], deg, json.timezone);
                subDays += html;
                if (i % 2 == 1 && i < arr.length - 2) {
                    var spacer = '<div class="xsBreak"></div>';
                    subDays += spacer;
                }
                if (i % 3 == 2 && i < arr.length - 3) {
                    var spacer = '<div class="smPlusBreak"></div>';
                    subDays += spacer;
                }
            }
            core.widgetContent.find(".daily-summary").html(json.daily.summary).animateCss("fadeIn");
            core.widgetContent.find(".succeeding-days").html(subDays).animateCss("fadeIn");
            setAddress();
    }

    var setMainPanel = function(json) {
        console.log('jd:wd:weather:setMainPanel');
        var jsonTemp;
        var fmt = "h:mm A ddd, MM/DD";
        var fmt1 = "h:mm A";
        var compareFmt = "YYYYMMDDHHmm";
        var newTime = convertTime(json.currently.time, json.timezone, fmt);
        var newSunrise = convertTime(json.daily.data[0].sunriseTime, json.timezone, fmt1);
        sunriseBegin = parseInt(convertTime(json.daily.data[0].sunriseTime - 3600, json.timezone, compareFmt));
        sunriseEnd = parseInt(convertTime(json.daily.data[0].sunriseTime + 3600, json.timezone, compareFmt));
        var newSunset = convertTime(json.daily.data[0].sunsetTime, json.timezone, fmt1);
        sunsetBegin = parseInt(convertTime(json.daily.data[0].sunsetTime - 3600, json.timezone, compareFmt));
        sunsetEnd = parseInt(convertTime(json.daily.data[0].sunsetTime + 3600, json.timezone, compareFmt));
        var date = new Date();
        currentTime = parseInt(date.getFullYear() + "" + addLeadZero((date.getMonth() + 1)) + "" + addLeadZero(date.getDate()) + "" + addLeadZero(date.getHours()) + "" + addLeadZero(date.getMinutes()));
        var iconCode = json.currently.icon;
        var humidity = Math.round(json.currently.humidity * 100);
        var cloudCover = Math.round(json.currently.cloudCover * 100);
        var windScale = beaufortScale(json.currently.windSpeed);
        //   Display main panel
        var mainTemp = Math.round(json.currently.temperature);
        var mainTempColor = getColorForTemp(mainTemp);
        var dailyIcon = getConditionIcons(iconCode);
        core.widgetContent.find(".main-weat").html(dailyIcon.icon).animateCss('fadeIn');
        core.widgetContent.find(".main-temp").html('<i style="font-size:30px; color:' + mainTempColor + ';" class="wi wi-thermometer"></i><span class="temp-val"> ' + mainTemp + '</span>' + deg).animateCss('fadeIn');
        core.widgetContent.find(".main-summary").html(json.hourly.summary).animateCss('fadeIn');
        var windColor = getColorForWind(windScale.scale);
        core.widgetContent.find(".main-wind").html(windScale.icon + '<div class="rowHalfBreak"></div><span style="font-size:19px">' + windScale.scale + '</span>').animateCss('fadeIn');
        core.widgetContent.find(".main-wind i").css('color', windColor);
        var humidityColor = getColorForHumidity(humidity);
        core.widgetContent.find(".humidity").html('<i class="wi wi-humidity wi-ml" style="color:' + humidityColor + ';"></i>' + '<div class="rowHalfBreak"></div><span style="font-size:19px">' + humidity + '%' + '</span>').animateCss('fadeIn');
        var cloudColor = getColorForHumidity(cloudCover);
        core.widgetContent.find(".cloud-cover").html('<i class="wi wi-cloud wi-ml" style="color:' + cloudColor + '"></i>' + '<div class="rowHalfBreak"></div><span style="font-size:19px">' + cloudCover + '%' + '</span>').animateCss('fadeIn');
    }

    var setSubPanel = function(dailyData, deg, timezone) {
        console.log('jd:wd:weather:setSubPanel');
        var dailyIcon = getConditionIcons(dailyData.icon);
        var ftm = 'ddd, MM/DD';
        var newTime = convertTime(dailyData.time, timezone, ftm);
        var html = '<div class="weatherAndTemp col-xs-6 col-sm-4">';
        html += '<h3 class="sub-date">' + newTime + '</h3>';
        html += '<div class="sub-icons">';
            html += '<div class="sub-weat">' + dailyIcon.iconSmall + '</div>';
            var subTemp = Math.round(dailyData.temperatureMax);
            var subTempColor = getColorForTemp(subTemp);

            html += '<div class="temp-pad"></div>';
                html += '<div class="sub-temp">' + '<i style="margin-right:5px; color:' + subTempColor + '" class="wi wi-thermometer wi-sm"></i>' + subTemp + deg + '</div>';
            html += '</div>';
        html += '<div style="clear:both;"></div>';
        html += '<div class="sub-summary">' + dailyData.summary + '</div>';
        html += '</div>';

        return html;
    }
    var setAddress = function(){
        console.log('jd:wd:weather:setAddress');
        jermmDash.extensions['locationData'].getLatLon(getAddressData);
    }

    var getAddressData = function(latLon) {
        console.log('jd:wd:weather:getAddressData');
        var latitude = latLon.latitude;
        var longitude = latLon.longitude;
        var googleUrl = 'https://maps.googleapis.com/maps/api/geocode/json?latlng=' + latitude + ',' + longitude + '&sensor=false';
        $.getJSON(googleUrl, processAddressData).fail(function() { getAddressDataFailReaction(latLon); });
    }

    var processAddressData = function(data){
        console.log('jd:wd:weather:processAddressData');
        var address = data.results[3].formatted_address;
        core.widgetContent.find(".main-address").text(address).animateCss('fadeIn');
        $('body').on("backgroundChanged", resetTrans);
        resetTrans();
        if(openCallback != null){
            openCallback();
            openCallback = null;
        }
    }

    var resetTrans = function() {
        console.log('jd:wd:weather:resetTrans');
        if(core.widgetContent.find('#weatherIsLoaded').length > 0){
            setTransEffect(getBodyBg());
        }
        return;
    }

    var setTransEffect = function(gradient, image) {
        core.widgetContent.find('.main-info').css({
            'background': "linear-gradient(to bottom, rgba(245 ,247 ,250,.8), rgba(245,247,250,.8)), url(" + getBodyBg() + ") center repeat",
            'background-attachment': 'fixed',
            'background-size': 'cover',
        });
    }

    var getBodyBg = function() {
        var bgcss = $('body').css('background-image');
        return bgcss.substring(bgcss.indexOf('url(') + 5, bgcss.indexOf('")'));
    }

    var getAddressFail = 0;
    var getAddressDataFailReaction = function(latLon){
        console.log('jd:wd:weather:getAddressDataFailReaction');
        getAddressFail++;
        if (getAddressFail < 10) {
            setTimeout(function() { getAddressData(latLon); }, 500);
            return;
        }else{
            getAddressFail = 0;
            alert('crash');
            exit();
        }
    }

    var convertTime = function(input, timezone, format) {
        var timestamp = moment.unix(input);
        return moment(timestamp).tz(timezone).format(format);
    }

    var addLeadZero = function(num) {
        if (num < 10) {
            num = "0" + num;
            return num;
        } else {
            return num + "";
        }
    }

    var getConditionIcons = function(currentIcon) {
        var icon, iconSmall;
        switch (currentIcon) {
            case "rain":
                icon = '<div class="rainy jBigIcon"></div>';
                iconSmall = '<div class="rainy jSmallIcon"></div>';
                break;
            case "clear-day":
                icon = '<div class="sunny jBigIcon"></div>';
                iconSmall = '<div class="sunny jSmallIcon"></div>';
                break;
            case "partly-cloudy-day":
                icon = '<div class="partlySun jBigIcon"></div>';
                iconSmall = '<div class="partlySun jSmallIcon"></div>';
                break;
            case "clear-night":
                icon = '<div class="night jBigIcon"></div>';
                iconSmall = '<div class="night jSmallIcon"></div>';
                break;
            case "partly-cloudy-night":
                icon = '<div class="partlyMoon jBigIcon"></div>';
                iconSmall = '<div class="partlyMoon jSmallIcon"></div>';
                break;
            case "snow":
                icon = '<div class="snow jBigIcon"></div>';
                iconSmall = '<div class="snow jSmallIcon"></div>';
                break;
            case "sleet":
                icon = '<div class="sleet jBigIcon"></div>';
                iconSmall = '<div class="sleet jSmallIcon"></div>';
                break;
            case "wind":
                icon = '<div class="wind jBigIcon"></div>';
                iconSmall = '<div class="wind jSmallIcon"></div>';
                break;
            case "cloudy":
                icon = '<div class="cloudy jBigIcon"></div>';
                iconSmall = '<div class="cloudy jSmallIcon"></div>';
                break;
            case "fog":
                icon = '<div class="fog jBigIcon"></div>';
                iconSmall = '<div class="fog jSmallIcon"></div>';
                break;
            default:
                icon = '<i class="wi wi-na wi-lg"></i>';
                iconSmall = '<i class="wi wi-na iconUp10 wi-md"></i>';
        }
        var results = {
            icon: icon,
            iconSmall: iconSmall
        };
        return results;
    }

    var beaufortScale = function(windSpeed) {
        var kmSpeed;
        var icon, scale;
        var speed, unit;
        if (units == "us") {
            unit = "mph";
            kmSpeed = Math.round(windSpeed * 1.6);
            speed = windSpeed;
        } else {
            kmSpeed = Math.round(windSpeed);
            speed = windSpeed;
            unit = "km/h";
        }

        if (kmSpeed < 1) {
            icon = '<i class="wi wi-wind-beaufort-0 wi-ml"></i>';
            scale = 'Calm';
        } else if (kmSpeed >= 1 && kmSpeed <= 5) {
            icon = '<i class="wi wi-wind-beaufort-1 wi-ml"></i>';
            scale = 'Light Air';
        } else if (kmSpeed >= 6 && kmSpeed <= 11) {
            icon = '<i class="wi wi-wind-beaufort-2 wi-ml"></i>';
            scale = 'Light Breeze';
        } else if (kmSpeed >= 12 && kmSpeed <= 19) {
            icon = '<i class="wi wi-wind-beaufort-3 wi-ml"></i>';
            scale = 'Gentle Breeze';
        } else if (kmSpeed >= 20 && kmSpeed <= 28) {
            icon = '<i class="wi wi-wind-beaufort-4 wi-ml"></i>';
            scale = 'Moderate Breeze';
        } else if (kmSpeed >= 29 && kmSpeed <= 38) {
            icon = '<i class="wi wi-wind-beaufort-5 wi-ml"></i>';
            scale = 'Fresh Breeze';
        } else if (kmSpeed >= 39 && kmSpeed <= 49) {
            icon = '<i class="wi wi-wind-beaufort-6 wi-ml"></i>';
            scale = 'Strong Breeze';
        } else if (kmSpeed >= 50 && kmSpeed <= 61) {
            icon = '<i class="wi wi-wind-beaufort-7 wi-ml"></i>';
            scale = 'High Wind';
        } else if (kmSpeed >= 62 && kmSpeed <= 74) {
            icon = '<i class="wi wi-wind-beaufort-8 wi-ml"></i>';
            scale = 'Gale';
        } else if (kmSpeed >= 75 && kmSpeed <= 88) {
            icon = '<i class="wi wi-wind-beaufort-9 wi-ml"></i>';
            scale = 'Strong Gale';
        } else if (kmSpeed > 88) {
            icon = '<i class="wi wi-wind-beaufort-10 wi-ml"></i>';
            scale = 'Storm';
        }

        var results = {
            speed: speed,
            unit: unit,
            icon: icon,
            scale: scale
        };
        return results;
    }

    var getColorForTemp = function(temp) {
        if (temp < 32) {
            return '#4FC1E9';
        }
        if (temp >= 32 && temp < 60) {
            return '#3BAFDA';
        }
        if (temp >= 60 && temp < 70) {
            return '#A0D468';
        }
        if (temp >= 70 && temp < 80) {
            return '#8CC152';
        }
        if (temp >= 80 && temp < 95) {
            return '#FC6E51';
        }
        if (temp >= 95) {
            return '#E9573F';
        }
    }

    var getColorForWind = function(scale) {
        if (scale == "Calm") {
            return '#4FC1E9';
        }
        if (scale == "Light Air" || scale == "Light Breeze") {
            return '#3BAFDA';
        }
        if (scale == "Gentle Breeze" || scale == "Moderate Breeze") {
            return '#A0D468';
        }
        if (scale == "Fresh Breeze" || scale == "Strong Breeze") {
            return '#8CC152';
        }
        if (scale == "High Wind" || scale == "Gale") {
            return '#FC6E51';
        }
        if (scale == "Strong Gale" || scale == "Storm") {
            return '#E9573F';
        }
    }

    var getColorForHumidity = function(humidity) {
        if (humidity < 10) {
            return '#4FC1E9';
        }
        if (humidity >= 10 && humidity < 20) {
            return '#3BAFDA';
        }
        if (humidity >= 20 && humidity < 40) {
            return '#A0D468';
        }
        if (humidity >= 40 && humidity < 60) {
            return '#8CC152';
        }
        if (humidity >= 60 && humidity < 80) {
            return '#FC6E51';
        }
        if (humidity >= 80) {
            return '#E9573F';
        }
    }
}