var second = {};
second.setIcon = function(){
	$('.secondIcon').html('<div>hi</div>');
}
second.openWidget = function(){
	$('#jdWidgetContent').html('<div>hi</div>');
}
second.closeWidget = function(){
	$('jdWidgetContent').html('');
}