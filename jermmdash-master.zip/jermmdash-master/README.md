# jermmdash v1.0.1
A general purpose dashboard, designed to be extensible and mobile-ready.  This is the first complete working model with a fully established convention for use.  It would require a lot of setup to actually use as-is, though.  Still to come is an admin panel / user logins.

* [Installation](#Installation)
* [Configuration](#Configuration)
  * [Dashboard](#Dashboard)
  * [Extensions](#Extensions)
  * [Widgets](#Widgets)
* [How To Use](#HowToUse)

## Installation
Copy the project to a php server of your choice and visit the directory into which you installed it.  The core app can have empty widgets and extensions folders, but it's not very useful that way.

## Configuration
There are really a few levels of configuration at work between the main app and the plugins.

### Dashboard
Generally, the dashboard is configured by editing viewCode.php.  You'd probably like to set meta.html as well.  

Notes:
* jermmDash/viewCode.php holds all the 3rd party scripts and stylesheets.
* jermmDash/index.php paints the home page.
* jermmDash/jermmDash.js holds the dashboard's main software that pilots all extensions and widgets.
* css loading priority goes: jermmDash > extensions > widgets
* javascript loading priority goes: extensions > widgets > jermmDash
* js execution priority goes: jermmDash > extensions > widgets

### Extensions
Extensions are installed by dropping a directory named for your extension in the /extensions directory, and putting the extension name in viewCode.php.  (This process will be smoother after the admin panel is added.)  Once added to viewCode, the dashboard will begin looking for all of these, and assign any it finds:

* /extensionName
  * extensionName.css
  * extensionName.html
  * extensionName.js

Within extensionName.js, this is the minimum template:
```js
var extensionName = function(){
	this.requires = ['extensionName', 'extensionName'];  // An array of strings naming other extensions that should be loaded first.
	this.open = function(openCallback){
		console.log('my script setup should all happen before the callback');
		openCallback();  // Callback tells the dashboard the extension is ready.
	}
```

Notes:
* Be sure to include this.open with an openCallback that is executed after the script is ready.
* Existing extensions (and widgets) all have extensive console reporting.

### Widgets
Where extensions will keep running as long as the site is open, widgets are loaded one at a time.  They are UI components that will be cleared from memory when not being used.  Like the extensions, the dashboard will go looking for these files and folders once the widget name is added to viewCode.php:

* /widgetName
  * icon.png
  * widgetName.css
  * widgetName.js

Within widgetName.js, this is the minimum template:
```js
var widgetName = function(){
    this.widgetContent = null;
    this.requires = ['extensionName', 'extensionName'];  // An array of strings naming other extensions that should be loaded first.

    this.open = function(openCallbackCB){
    	console.log('This is where you should set up your widget's html and javascript, and stick them in this.widgetContent as a jQuery object.'');
        openCallbackCB();
    }

    this.close = function(closeCallbackCB){
    	console.log('This is where you would kill loops, destroy objects, whatever readies your widget for shutdown.');
        closeCallbackCB();
    }
}
```

Notes:
* Unique here is widgetContent.  It is a jQuery object.  The app will treat it as your widget's html.  Loading the html into memory before attaching to the DOM enables us to provide smooth transitions when going between widgets as well as aids in memory management.
* Widget code usually should not act on anything outside of its own html.  They are intended to be self-contained.

## HowToUse
For the existing software, there's not a lot to this still.  The navbar will automatically load a button for every widget listed in viewCode.php, and will automatically set icon.png as its image.  It will also automatically load the first widget in the list after the extensions are ready.