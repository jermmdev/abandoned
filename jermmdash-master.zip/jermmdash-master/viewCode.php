<?php
	$viewData = [];
	
	$viewData['scripts'] = [];
	array_push($viewData['scripts'], "https://cdnjs.cloudflare.com/ajax/libs/jquery/1.11.0-rc1/jquery.min.js");
	array_push($viewData['scripts'], "https://cdnjs.cloudflare.com/ajax/libs/moment.js/2.18.1/moment.min.js");
	array_push($viewData['scripts'], "https://cdnjs.cloudflare.com/ajax/libs/moment-timezone/0.5.13/moment-timezone-with-data.min.js");
	array_push($viewData['scripts'], "https://cdnjs.cloudflare.com/ajax/libs/twitter-bootstrap/3.3.0/js/bootstrap.min.js");
	array_push($viewData['scripts'], "https://cdnjs.cloudflare.com/ajax/libs/bootflat/2.0.4/js/jquery.fs.selecter.min.js");
	array_push($viewData['scripts'], "https://cdnjs.cloudflare.com/ajax/libs/bootflat/2.0.4/js/jquery.fs.stepper.min.js");

	$viewData['styles'] = [];
	array_push($viewData['styles'],"https://cdnjs.cloudflare.com/ajax/libs/twitter-bootstrap/3.3.0/css/bootstrap.min.css");
	array_push($viewData['styles'],"https://cdnjs.cloudflare.com/ajax/libs/bootflat/2.0.4/css/bootflat.min.css");
	array_push($viewData['styles'],"https://fonts.googleapis.com/css?family=Alegreya+Sans+SC:300,400|Lato");
	array_push($viewData['styles'],"https://cdnjs.cloudflare.com/ajax/libs/animate.css/3.5.2/animate.min.css");
	array_push($viewData['styles'],"https://maxcdn.bootstrapcdn.com/font-awesome/4.7.0/css/font-awesome.min.css");
	array_push($viewData['styles'],"https://cdnjs.cloudflare.com/ajax/libs/weather-icons/2.0.9/css/weather-icons.css");

	$viewData['extensions'] = ['loader','locationData','weatherData', 'weatherBackgrounds', 'scrollToTop'];
	/** AutoLoad... but it's hard to account for order this way.
	$subDirs = scandir(__DIR__."/extensions");
	foreach($subDirs as $dir){
		if($dir != "." && $dir != ".."){
			array_push($viewData['extensions'], $dir);
		}
	}
	**/

	$viewData['widgets'] = ['weather'];
	/** AutoLoad... but it's hard to account for order this way.
	$subDirs = scandir(__DIR__."/widgets");
	foreach($subDirs as $dir){
		if($dir != "." && $dir != ".."){
			array_push($viewData['widgets'], $dir);
		}
	}
	**/
?>