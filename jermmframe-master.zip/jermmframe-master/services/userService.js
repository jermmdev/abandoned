module.exports = function(){
	var repo = new (require('./../repository.js'));

	this.getUserFrameDataAsync = async function(user){
		var extensions = await repo.selectByKeysAsync(user.extensions);
		var newExtensions = [];
		for(var i=0; i<extensions.length; i++){
			if(extensions[i].extensionName == 'loader') newExtensions[0] = extensions[i];
			if(extensions[i].extensionName == 'scrollToTop') newExtensions[1] = extensions[i];
			if(extensions[i].extensionName == 'locationData') newExtensions[2] = extensions[i];
			if(extensions[i].extensionName == 'weatherData') newExtensions[3] = extensions[i];
			if(extensions[i].extensionName == 'weatherBackground') newExtensions[4] = extensions[i];
		}
		extensions = newExtensions;
		var widgets = await repo.selectByKeysAsync(user.widgets);
		var response = {};
		response.extensions = extensions;
		response.widgets = widgets;
		return response;
	}

	this.getUserByNameAsync = async function(userName){
		var queryData = {};
		queryData.kind = 'user';
		queryData.rel = '=';
		queryData.data = userName;
		queryData.prop = 'userName';
		return (await repo.runQueryAsync(queryData))[0];
	}
}