module.exports = function(){

	var uService = new (require('./userService.js'));
	this.generateFrameAsync = async function(view, userName){
		var user = await uService.getUserByNameAsync(userName);
		var frameData = await uService.getUserFrameDataAsync(user);

		/** probably gonna store with user **/
		var meta = view.exportMeta();
		meta.title = user.userName + "'s Frame";
		meta.description = user.userName + "'s personal dashboard provided by jermmfra.me.";

		meta.og = {};
		meta.og.title = meta.title;
		meta.og.url = 'https://jermmfra.me/u/' + user.userName;

		view.importMeta(meta);
		/** probably gonna store with user **/


		var extensionHtml = '<div id="extensionHtml">';
		for(var i=0; i<frameData.extensions.length; i++){
			view.addStyle('<style>' + frameData.extensions[i].css + '</style>');
			view.addScript('<script>' + frameData.extensions[i].js + '</script>');
			extensionHtml += '<div class="extensionHtml ' + frameData.extensions[i].extensionName + '">';
			extensionHtml += frameData.extensions[i].html;
			extensionHtml += '</div>';
		}
		extensionHtml += '</div>';

		var widgetHtml = '<div id="widgetHtml">';
		for(var i=0; i<frameData.widgets.length; i++){
			view.addStyle('<style>' + frameData.widgets[i].css + '</style>');
			view.addScript('<script>' + frameData.widgets[i].js + '</script>');
			widgetHtml += '<div class="widgetHtml ' + frameData.widgets[i].widgetName + '">';
			widgetHtml += frameData.widgets[i].html;
			widgetHtml += '</div>';
		}
		widgetHtml += '</div>';

		var appContainer = '';
		appContainer += '<div class="container">';
			appContainer += '<div class=\'col-sm-2 jdSideNav\'>';
				appContainer += '<div class="jdAppIcon weatherIcon" onclick="jermmDash.buttonPressed(\'weather\');">';
					appContainer += '<img src="/views/widgets/weather/icon.png">';
				appContainer += '</div>';
				appContainer += '<div class=\'col-sm-10 jdAppContent\'>';
					appContainer += '<div id=\'jdWidgetContent\'>';
					appContainer += '</div>';
				appContainer += '</div>';
			appContainer += '</div>';
		appContainer += '</div>';
				
			
				
			
		view.setBody(extensionHtml + widgetHtml + appContainer);
		view.addScript('/views/jermmDash.js');
		view.addStyle('/views/jermmFrame.css');
		return view;
	}
}