module.exports = function(){
	var Promise = require("bluebird");
	var datastore = Promise.promisifyAll(require('@google-cloud/datastore')({
	  projectId: 'jermmdash',
	  keyFilename: 'C:\\jermm\\git\\jermmdashkey.json'
	}));

	this.getKey = function(kind, id){
		if(typeof id != 'undefined'){
			return datastore.key([kind, id]);
		}else{
			return datastore.key([kind]);
		}
	}

	this.createAsync = async function(kind, object){
		var key = null;
		key = datastore.key([kind]);
		return await datastore.saveAsync({
		  key: key,
		  data: object
		});
	}

	this.selectByIdAsync = async function(kind, ids){
		var keyData = [];
		if(typeof ids == 'object'){
			for(var i=0; i<ids.length; i++){
				keyData.push(kind);
				keyData.push(ids[i]);
			}
		}else{
			keyData.push(kind);
			keyData.push(ids);
		}
		var keys = datastore.key(keyData);
		return await datastore.getAsync(keys);
	}

	this.selectByKeysAsync = async function(keys){
		return await datastore.getAsync(keys);
	}

	this.runQueryAsync = async function(queryData){
		var query = datastore.createQuery(queryData.kind).filter(queryData.prop, queryData.rel, queryData.data);
		return await datastore.runQueryAsync(query);
	}
}