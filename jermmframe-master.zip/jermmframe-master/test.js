
var userService = require("./services/userService.js");
var us = new userService();


//var repository = require('./repository.js');
//var repo = new repository();

us.getUserByName('jermm').then(function(result){console.log(result);});