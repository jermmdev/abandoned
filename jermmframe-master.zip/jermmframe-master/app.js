'use strict';

const express = require('express');
const server = express();
var frameBuilderService = require('./services/frameBuilderService.js');
var viewBuilder = require('./node_modules/jermmViewBuilder/jermmViewBuilder.js');

server.use('/views', express.static('views'));

server.get('/*', async function(req, res){
	var host = req.hostname;
	var url = req.originalUrl;
	var debug = host.search('localhost') > -1;
	var secure = req.headers['x-forwarded-proto'] == 'https';
	//Force secure and pretty url.
	if( (host != 'jermmfra.me' || !secure) && !debug){
		res.redirect('https://jermmfra.me'+url);
		return;
	}

	var view = new (require('./node_modules/jermmViewBuilder/jermmViewBuilder.js'))();
	view = setViewBase(view);

	//Where are you trying to go?.
	var urlSplit = req.originalUrl.split('/');
	urlSplit.splice(0,1);


	if(urlSplit[0] == 'create'){
		view.setBody("This is where the user create page will go.");
		res.send(view.renderView());
		return;
	}

	if(urlSplit[0] == 'mod'){
		view.setBody("This is where the moderation page will go.");
		res.send(view.renderView());
		return;
	}

	if(urlSplit[0] == 'u'){
		var fService = new frameBuilderService();
		if(urlSplit.length > 1){
			if(urlSplit[2] == 'admin'){
				view.setBody("This is where user admin will go.");
				res.send(view.renderView());
				return;
			}
		}
		view = await fService.generateFrameAsync(view, urlSplit[1]);
		res.send(view.renderView());
		return;
	}

	view.setBody("This is where the splash page will go.");
	res.send(view.renderView());
	return;
});



const PORT = process.env.PORT || 8080;
server.listen(PORT, () => {
	console.log('Beeb bork the app has started!');
});





var setViewBase = function(view){
	view.addStyle('https://cdnjs.cloudflare.com/ajax/libs/twitter-bootstrap/3.3.0/css/bootstrap.min.css');
	view.addStyle('https://cdnjs.cloudflare.com/ajax/libs/bootflat/2.0.4/css/bootflat.min.css');
	view.addStyle('https://fonts.googleapis.com/css?family=Alegreya+Sans+SC:300,400|Lato');
	view.addStyle('https://cdnjs.cloudflare.com/ajax/libs/animate.css/3.5.2/animate.min.css');
	view.addStyle('https://maxcdn.bootstrapcdn.com/font-awesome/4.7.0/css/font-awesome.min.css');

	view.addScript('https://cdnjs.cloudflare.com/ajax/libs/jquery/1.11.0-rc1/jquery.min.js');
	view.addScript('https://cdnjs.cloudflare.com/ajax/libs/moment.js/2.18.1/moment.min.js');
	view.addScript('https://cdnjs.cloudflare.com/ajax/libs/moment-timezone/0.5.13/moment-timezone-with-data.min.js');
	view.addScript('https://cdnjs.cloudflare.com/ajax/libs/twitter-bootstrap/3.3.0/js/bootstrap.min.js');
	view.addScript('https://cdnjs.cloudflare.com/ajax/libs/bootflat/2.0.4/js/jquery.fs.selecter.min.js');
	view.addScript('https://cdnjs.cloudflare.com/ajax/libs/bootflat/2.0.4/js/jquery.fs.stepper.min.js');

	var meta = {};
	meta.charset = "utf-8";
	meta.viewport = "width=device-width";
	meta.title = "Jermm";
	meta.description = "Jermm development projects.";
	meta.keywords = ['dashboard', 'web', 'bootstrap', 'flat ui', 'flatui', 'design', 'web design', 'web developer', 'engineer', 'jermm', 'organization'];
	meta.shortcutIcon = "favicon.ico";
	meta.bookmark = meta.shortcutIcon;

	meta.og = {};
	meta.og.title = meta.title;
	meta.og.url = 'https://jermmfra.me/';
	meta.og.image = 'Default OG Image';
	meta.og.type = 'website';

	view.importMeta(meta);

	return view;
}