let crypto = require('crypto')
let danger = require('./dangerRepo.js')
let Events = require('events')
let seedClient = function(yggRootAddress, myName, myPublicKey, myPrivateKey, port, server){
    let wss = new (require('./jermmWss.js'))(port, server)
    let loginToken = crypto.createHash('md5').update(myPublicKey+Date.now()).digest('hex')
    let mySeedClient = this
    mySeedClient.yggApi = {}
    let yggdrasilCentral = false
    mySeedClient.events = new Events()
    let innerEvents = new Events()

    let sessions = {}

    let awaitingResponse = {}

    let reLoginTimer = 10*1000
    let requestLogin = ()=>{
        if(yggdrasilCentral) return false
        console.log('Requesting Ygg Login')
        let loginWs = wss.GetSocket(yggRootAddress)
        loginWs.on('open', ()=>{
            loginWs.sendify({
                clientLogin: {
                    name: myName
                    , publicKey: myPublicKey
                    , token: loginToken
                }
            })
        })
        setTimeout(requestLogin, reLoginTimer)
    }

    let buildPromises = (yggApi, logicPath = '', skipCore = true, coreName = '') =>{
        let responseObj = {}
        let newPath = ''
        for(let ind in yggApi){
            if(skipCore){
                coreName = ind
            }else{
                newPath = ind+'/'
            }
            if(yggApi[ind] !== 'function') {
                responseObj[ind] = buildPromises(yggApi[ind], newPath, false, coreName)
            }
            if(yggApi[ind] === 'function'){
                logicPath = logicPath + ind
                responseObj[ind] = async function(input){
                    return new Promise((resolve, reject)=>{
                        let logicToken = crypto.createHash('md5').update(logicPath+Date.now()).digest('hex')
                        yggdrasilCentral.ws.sendify({
                            core: coreName
                            , logic: logicPath
                            , input: input
                            , token: logicToken
                        })
                        awaitingResponse[logicToken] = {}
                        innerEvents.on('dataResponse', (responseToken)=>{
                            if(logicToken === responseToken){
                                resolve(awaitingResponse[logicToken].response)
                                delete awaitingResponse[logicToken]
                            }
                        })
                        setTimeout(()=>{
                            if(awaitingResponse[logicToken]){
                                delete awaitingResponse[logicToken]
                                let errMsg = {
                                    error: 'Data Request Timed Out'
                                }
                                console.error(errMsg)
                                reject(errMsg)
                            }
                        }, reLoginTimer)
                    })
                }
            }
        }
        return responseObj
    }
    wss.onClose = (closeCode, wsId)=>{
        if(sessions[wsId]) delete sessions[wsId]
    }
    wss.onConnect = (wsId) => {
        if(yggdrasilCentral && !sessions[wsId]){
            //danger.log('Foreign Post Login Connection', {req: wss.connected[wsId].req})
            if(wss.connected[wsId]) wss.connected[wsId].ws.close()
        }
    }
    wss.onBadMessage = (msg, wsId) => {
        if(!sessions[wsId] && wss.connected[wsId]) wss.connected[wsId].ws.close()
    }
    wss.onMessage = (msg, wsId) => {
        if(yggdrasilCentral && !sessions[wsId]) {
            //danger.log('Foreign Post Login Message', {msg: msg, req: wss.connected[wsId].req})
            if(wss.connected[wsId]) wss.connected[wsId].ws.close()
            return false
        }
        if(msg.yggLoginResponse){
            if(
                !sessions[wsId]
                && msg.yggLoginResponse.privateKey === myPrivateKey
                && msg.yggLoginResponse.token === loginToken
                && !yggdrasilCentral
            ){
                yggdrasilCentral = wss.connected[wsId]
                console.log('Ygg Online')
                sessions[wsId] = true
                wss.connected[wsId].ws.on('close', (closeCode)=>{
                    mySeedClient.events.emit('offline', closeCode)
                    yggdrasilCentral = false
                    console.error('Ygg Offline.  Attempting reconnect.')
                    requestLogin()
                })
                mySeedClient.yggApi = buildPromises(msg.yggLoginResponse.yggApi)
                mySeedClient.events.emit('online', true)
                return false
            }else{
                // danger.log('Invalid yggLoginResponse', {
                //     msg: msg
                //     , req: wss.connected[wsId] ? wss.connected[wsId].req : null
                //     , actualToken: loginToken
                // })
                if(wss.connected[wsId]) wss.connected[wsId].ws.close()
                return false
            }
        }
        if(!sessions[wsId]){
            // danger.log('non-login message from new client', {
            //     req: wss.connected[wsId].req
            //     , msg: msg
            // })
            wss.connected[wsId].ws.close()
            return false
        }
        if(msg.yggApi){
            mySeedClient.yggApi = buildPromises(msg.yggApi)
            mySeedClient.events.emit('apiUpdated', true)
        }
        if(msg.output){
            if(awaitingResponse[msg.token]){
                awaitingResponse[msg.token].response = msg.output
                innerEvents.emit('dataResponse', msg.token)
                return false
            }
            else{
                danger.log('Invalid ygg Output', {
                    msg: msg
                    , req: wss.connected[wsId] ? wss.connected[wsId].req : null
                })
            }
            return false
        }
    }
    requestLogin()
}
module.exports = seedClient