let seedClient = require('./index.js')
let sc = new seedClient('localhost:8080'
, 'clientName'
, 'pubKey'
, 'privKey'
, 8080)
sc.events.on('online', ()=>{
    console.log('am online', sc.yggApi)
})
sc.events.on('offline', ()=>{
    console.log('am offline', sc.yggApi)
})
sc.events.on('apiUpdated', ()=>{
    console.log('am updated', sc.yggApi)
})