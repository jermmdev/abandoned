let getHub = require('gethub')
let path = require('path')
let crypto = require('crypto')
let Events = require('events')
let fs = require('fs')
let wssPath = path.join(__dirname, 'jermm-wss')
let seedClient = function(yggRootAddress, myName, myPublicKey, myPrivateKey, port, server){
    let mySeedClient = this
    mySeedClient.events = new Events()
    mySeedClient.yggApi = {}
    let wssIsReady = ()=>{
        let wss = new (require(wssPath))(port, server)
        let loginToken = crypto.createHash('md5').update(myPublicKey+Date.now()).digest('hex')
        let yggdrasilCentral = false
        let innerEvents = new Events()
        let sessions = {}
        let awaitingResponse = {}
        let hasError = {}
        let reLoginTimer = 10*1000
        let requestLogin = ()=>{
            if(yggdrasilCentral) return false
            console.log('Requesting Ygg Login')
            let loginWs = wss.GetSocket(yggRootAddress)
            loginWs.on('open', ()=>{
                loginWs.sendify({
                    clientLogin: {
                        name: myName
                        , publicKey: myPublicKey
                        , token: loginToken
                    }
                })
            })
            setTimeout(requestLogin, reLoginTimer)
        }

        let buildPromises = (yggApi, logicPath = '', skipCore = true, coreName = '') =>{
            let responseObj = {}
            let newPath = ''
            for(let ind in yggApi){
                if(skipCore){
                    coreName = ind
                }else{
                    newPath = ind+'/'
                }
                if(yggApi[ind] !== 'function') {
                    responseObj[ind] = buildPromises(yggApi[ind], newPath, false, coreName)
                }
                if(yggApi[ind] === 'function'){
                    logicPath = logicPath + ind
                    responseObj[ind] = async function(input){
                        return new Promise((resolve, reject)=>{
                            let logicToken = crypto.createHash('md5').update(logicPath+Date.now()).digest('hex')
                            yggdrasilCentral.ws.sendify({
                                core: coreName
                                , logic: logicPath
                                , input: input
                                , token: logicToken
                            })
                            awaitingResponse[logicToken] = {}
                            innerEvents.on('dataResponse', (responseToken)=>{
                                if(hasError[logicToken]){
                                    let theError = hasError[logicToken]
                                    delete hasError[logicToken]
                                    if(awaitingResponse[logicToken]) delete awaitingResponse[logicToken]
                                    reject(theError)
                                }
                                if(awaitingResponse[logicToken]){
                                    if(logicToken === responseToken){
                                        resolve(awaitingResponse[logicToken].response)
                                        delete awaitingResponse[logicToken]
                                    }
                                }else{
                                    let errMsg = {
                                        error: 'Was not awaiting this response.'
                                    }
                                    reject(errMsg)
                                }
                            })
                            setTimeout(()=>{
                                if(awaitingResponse[logicToken]){
                                    delete awaitingResponse[logicToken]
                                    let errMsg = {
                                        error: 'Data Request Timed Out'
                                    }
                                    console.error(errMsg)
                                    reject(errMsg)
                                }
                            }, reLoginTimer)
                        })
                    }
                }
            }
            return responseObj
        }
        wss.onClose = (closeCode, wsId)=>{
            if(sessions[wsId]) delete sessions[wsId]
        }
        wss.onConnect = (wsId) => {
            if(yggdrasilCentral && !sessions[wsId]){
                //danger.log('Foreign Post Login Connection', {req: wss.connected[wsId].req})
                if(wss.connected[wsId]) wss.connected[wsId].ws.close()
            }
        }
        wss.onBadMessage = (msg, wsId) => {
            if(!sessions[wsId] && wss.connected[wsId]) wss.connected[wsId].ws.close()
        }
        wss.onMessage = (msg, wsId) => {
            if(yggdrasilCentral && !sessions[wsId]) {
                //danger.log('Foreign Post Login Message', {msg: msg, req: wss.connected[wsId].req})
                if(wss.connected[wsId]) wss.connected[wsId].ws.close()
                return false
            }
            if(msg.yggLoginResponse){
                if(
                    !sessions[wsId]
                    && msg.yggLoginResponse.privateKey === myPrivateKey
                    && msg.yggLoginResponse.token === loginToken
                    && !yggdrasilCentral
                ){
                    yggdrasilCentral = wss.connected[wsId]
                    console.log('Ygg Online')
                    sessions[wsId] = true
                    wss.connected[wsId].ws.on('close', (closeCode)=>{
                        mySeedClient.events.emit('offline', closeCode)
                        yggdrasilCentral = false
                        console.error('Ygg Offline.  Attempting reconnect.')
                        requestLogin()
                    })
                    mySeedClient.yggApi = buildPromises(msg.yggLoginResponse.yggApi)
                    mySeedClient.events.emit('online', true)
                    return false
                }else{
                    // danger.log('Invalid yggLoginResponse', {
                    //     msg: msg
                    //     , req: wss.connected[wsId] ? wss.connected[wsId].req : null
                    //     , actualToken: loginToken
                    // })
                    if(wss.connected[wsId]) wss.connected[wsId].ws.close()
                    return false
                }
            }
            if(!sessions[wsId]){
                // danger.log('non-login message from new client', {
                //     req: wss.connected[wsId].req
                //     , msg: msg
                // })
                wss.connected[wsId].ws.close()
                return false
            }
            if(msg.jermmPing){
                setTimeout(()=>{
                    if(wss.connected[wsId]) wss.connected[wsId].ws.sendify({jermmPing: 'pong'})
                }, 50*1000)
                return false
            }
            if(msg.yggApi){
                mySeedClient.yggApi = buildPromises(msg.yggApi)
                mySeedClient.events.emit('apiUpdated', true)
            }
            if(msg.output){
                if(awaitingResponse[msg.token]){
                    if(msg.error) hasError[msg.token] = msg.error
                    awaitingResponse[msg.token].response = msg.output
                    innerEvents.emit('dataResponse', msg.token)
                    return false
                }
                else{
                    // danger.log('Invalid ygg Output', {
                    //     msg: msg
                    //     , req: wss.connected[wsId] ? wss.connected[wsId].req : null
                    // })
                }
                return false
            }
        }
        requestLogin()
    }
    if(!fs.existsSync(wssPath)){
        getHub('jermmdev', 'jermm-wss', 'master', wssPath).then(wssIsReady).catch((err)=>{
            throw err
        })
    }else{
        wssIsReady()
    }
}
module.exports = seedClient