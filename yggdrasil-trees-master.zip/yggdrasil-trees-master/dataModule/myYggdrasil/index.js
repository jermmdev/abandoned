let yggdrasil = require('./../../../yggdrasil')
let myModule = new (require('./../'))()
let myYggdrasil = new yggdrasil({
    name: 'DataMaker'
    , key: 'DataMeUp'
    , port: 2244
    , modules: myModule
})