let redditModule = function(options){
    let path = require('path')
    let r = require(path.join(__dirname+'/redditBot'))
}

module.exports = redditModule