'use strict';
const snoowrap = require('snoowrap');
const r = new snoowrap({
    userAgent: 'jermmBotNodeJs',
    clientId: '9SS5C2rbrbSAQA',
    clientSecret: 'zsFiACHLbDvIhQtqDsyJ5PtUJrA',  
    username: 'jermmbot',
    password: 'RedditWammWammWazzle'
  })
module.exports = r