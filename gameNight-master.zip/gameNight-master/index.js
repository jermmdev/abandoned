let jb = require('./../jermmBots');
// jb.jermmBotCreateStock(require('./data/data.js'));
// jb.jermmBotCreateStock(require('./gameNightHost.js'));

jb.jermmBotCreateStock(function(jermmBots){
    this.jermmBotStockName = 'adminJermmBot'
})