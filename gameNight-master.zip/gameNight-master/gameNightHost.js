module.exports = function(jermmBots){
    this.jermmBotName = 'gameNightHost';
    this.jermmBotStockName = 'hostJermmBot';
    this.port = 3000;
    this.apis = [jermmBots.jermmBotCreateStock(require('./gameNightApi.js'))];
    }