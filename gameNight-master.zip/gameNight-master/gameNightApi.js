module.exports = function(jermmBots){
    this.jermmBotName = 'gameNightApi';
    this.jermmBotStockName = 'apiJermmBot';
    this.apiHeader = 'Game Night';
    this.requireLogin = true;
    this.loginLogicBot = jermmBots.jermmBotCreate(require('./logic/login.js'));
    this.loginSuccessPath = '/home';
    this.paths = {
        home: {
            navName: 'Home'
            , children: {
                homeChild: {
                    navName: 'Child'
                    , viewBot: jermmBots.jermmBotCreateStock(require('./views/home.js'))
                    , children: {
                        nestedChild: {
                            navName: 'Nested'
                            , viewBot: jermmBots.homePageView
                        }
                    }
                }
                , otherChild: {
                    navName: 'Sibling'
                    , viewBot: jermmBots.homePageView
                    , viewBot: jermmBots.homePageView
                }

            }
            , viewBot: jermmBots.homePageView
        }
        , homeSib: {
            navName: 'Adding a lot of crap in here'
            , viewBot: jermmBots.homePageView
        }
        , homeSibx: {
            navName: 'Addingx holy geez it can fit'
            , viewBot: jermmBots.homePageView
        }
        , homeSibxx: {
            navName: 'okay but lets make Addingxx'
            , viewBot: jermmBots.homePageView
        }
        , homeSibxxx: {
            navName: 'Addingxxx a couple of stupid ones'
            , viewBot: jermmBots.homePageView
        }
        , homeSibxxxx: {
            navName: 'Addingxxxx'
            , viewBot: jermmBots.homePageView
        }
        , homeSibxxxxx: {
            navName: 'Addingxxxxx'
            , viewBot: jermmBots.homePageView
        }
    }
}