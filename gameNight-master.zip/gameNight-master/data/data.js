module.exports = function(jermmBots){
    this.jermmBotName = 'gameNightData';
    this.jermmBotStockName = 'dataJermmBot';
    this.databaseFile = __dirname + '/db.json';
    this.repository = function(dataBot){
        this.getUserWithMessages = function(userId){
            let user = dataBot.select('/users', {userId: userId});
            let mess = dataBot.select('/messages', {userId: userId});
            return {user: user, mess: mess}
            }
        }
    }