let moduleDigger = function(){
    let core = this
    this.execFuncAtPath = function(obj, path, inputs) {
        if(typeof(obj)!='object' || typeof(path)!='string') throw new Error("StringAccess: Invalid stringAccess Inputs")
        let pathSplit = path.split('/')
        for(let ind in pathSplit){
            if(!obj[pathSplit[ind]]) throw new Error("StringAccess: Path Broke Down at " + pathSplit[ind] + " Path: " + path)
            let objType = typeof(obj[pathSplit[ind]])
            if(objType =='object') obj = obj[pathSplit[ind]]
            if(objType =='function') {
                return obj[pathSplit[ind]](inputs)
            }
            if(objType != 'object' && objType !='function'){
                throw new Error("StringAccess: Path Broke Down at " + pathSplit[ind] + " Path: " + path)
            }
        }
        throw new Error('finished path split with no success')
    }
    this.getFuncApi = function(obj){
        if(typeof(obj) != 'object' && typeof(obj) != 'function') return false
        if(typeof(obj) == 'function') {
            return obj
        }
        let feedbackObj = {}
        for(let ind in obj){
            let innerObj = obj[ind]
            let feedback = core.getFuncApi(innerObj)
            if(feedback) {
                if(typeof(feedback) == 'function'){
                    feedbackObj[ind] = 'function'
                }else{
                    feedbackObj[ind] = feedback
                }
            }
        }
        return feedbackObj
    }
}
let myExport = new moduleDigger()
module.exports = myExport