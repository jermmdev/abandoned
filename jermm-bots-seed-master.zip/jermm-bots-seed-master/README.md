# jermm-bots-seed
Seed a module in a jermm-bots network.
