let crypto = require('crypto')
let fs = require('fs')
let path = require('path')
let njdb = require('node-json-db')
let dangerRepo = function() {
    let dataPath = path.join(__dirname, '/dangerLog.json')
    let dangerDb = new njdb(dataPath, true, true)
    if(!fs.existsSync(dataPath)) fs.writeFileSync(dataPath, '{}')
    this.log = (header='emptyHdr', msg='emptyMsg')=>{
        let logCreated = Date.now()
        let random = Math.random().toString()
        let uniqua = crypto.createHash('md5').update(random).digest('hex')
        dangerDb.push('/'+logCreated+'/'+uniqua+'/'+header, msg, false)
        console.error('DangerLog ('+header+'): ', msg)
        return false
    }
}
module.exports = new dangerRepo()