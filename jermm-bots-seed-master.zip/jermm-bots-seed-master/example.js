let seedCore = require('./index.js')

let foxModule = {
    idothings: ()=>{
        return 'things'
    }
}
let sc = new seedCore(
    foxModule
    , 'ws://localhost:8080'
    , 'coreName'
    , 'pubKey'
    , 'privKey'
    , 8080)