let path = require('path')
let fs = require('fs')
let crypto = require('crypto')
let danger = require('./dangerRepo.js')
let moduleDig = require('./moduleDig')
let wssPath = path.join(__dirname, 'jermm-wss')
let displayPath = path.join(__dirname, 'display.pug')
let getHub = require('gethub')
let express = require('express')
let bot = new express()
let pug = require('pug')
let displayView = pug.compileFile(displayPath)
let http = require('http')
let seedCore = function(yggBot, yggRootAddress, myName, myPublicKey, myPrivateKey, port){
    let wssIsReady = ()=>{
        let api = moduleDig.getFuncApi(yggBot)
        bot.get('/*', (req, res)=>{
            res.status(200).send(displayView({
                coreName: myName
                , coreApi: api
            }))
        })
        let server = http.createServer(bot)
        let wss = new (require(wssPath))(port, server)
        let loginToken = crypto.createHash('md5').update(myPublicKey+Date.now()).digest('hex')
        let yggdrasilCentral = false

        let reLoginTimer = 10*1000
        let requestLogin = ()=>{
            if(yggdrasilCentral) return false
            console.log('Sending Ygg Login Request')
            let loginWs = wss.GetSocket(yggRootAddress)
            if(loginWs){
                loginWs.on('open', ()=>{
                    loginWs.sendify({
                        coreLogin: {
                            name: myName
                            , publicKey: myPublicKey
                            , token: loginToken
                        }
                    })
                })
            }else{
                console.error('Ygg Not Available', err)
            }
            setTimeout(requestLogin, reLoginTimer)
        }

        let sessions = {}

        wss.onClose = (closeCode, wsId)=>{
            if(sessions[wsId]) delete sessions[wsId]
        }
        wss.onConnect = (wsId) => {
            if(yggdrasilCentral && !sessions[wsId]){
                danger.log('Foreign Post Login Connection', {msg: msg, req: wss.connected[wsId].req})
                if(wss.connected[wsId]) wss.connected[wsId].ws.close()
            }
        }
        wss.onBadMessage = (msg, wsId) => {
            if(!sessions[wsId] && wss.connected[wsId]) wss.connected[wsId].ws.close()
        }
        wss.onMessage = (msg, wsId) => {
            if(yggdrasilCentral && !sessions[wsId]) {
                danger.log('Foreign Post Login Message', {msg: msg})
                if(wss.connected[wsId]) wss.connected[wsId].ws.close()
                return false
            }
            if(msg.yggLoginResponse){
                if(
                    !sessions[wsId]
                    && msg.yggLoginResponse.privateKey === myPrivateKey
                    && msg.yggLoginResponse.token === loginToken
                    && !yggdrasilCentral
                ){
                    yggdrasilCentral = wss.connected[wsId]
                    console.log('Ygg Online')
                    sessions[wsId] = true
                    wss.connected[wsId].ws.on('close', ()=>{
                        yggdrasilCentral = false
                        console.error('Ygg Offline.  Attempting reconnect.')
                        requestLogin()
                    })
                    wss.connected[wsId].ws.sendify({
                        coreApi: api
                    })
                    return true
                }else{
                    danger.log('Invalid yggLoginResponse', {
                        msg: msg
                        , req: wss.connected[wsId] ? wss.connected[wsId].req : null
                        , actualToken: loginToken
                    })
                    if(wss.connected[wsId]) wss.connected[wsId].ws.close()
                    return false
                }
            }
            if(!sessions[wsId]){
                // danger.log('non-login message from new client', {
                //     req: wss.connected[wsId].req
                //     , msg: msg
                // })
                // wss.connected[wsId].ws.close()
                return false
            }
            //Okay I'm pretty sure this is Yggdrasil now.
            if(msg.jermmPing){
                setTimeout(()=>{
                    if(wss.connected[wsId]) wss.connected[wsId].ws.sendify({jermmPing: 'pong'})
                }, 50*1000)
                return false
            }
            if(msg.logic){
                try{
                    let funcResponse = moduleDig.execFuncAtPath(yggBot, msg.logic, msg.input)
                    wss.connected[wsId].ws.sendify({
                        output: funcResponse
                        , input: msg
                    })
                    return true
                }catch(err){
                    console.error(err)
                    wss.connected[wsId].ws.sendify({
                        error: err
                        , originalMsg: msg
                    })
                    return false
                }
            }
        }
        requestLogin()
    }
    if(!fs.existsSync(wssPath)){
        getHub('jermmdev', 'jermm-wss', 'master', wssPath).then(wssIsReady).catch((err)=>{
            throw err
        })
    }else{
        wssIsReady()
    }
}
module.exports = seedCore