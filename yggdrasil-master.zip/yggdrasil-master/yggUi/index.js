let yggUi = function(options){
    let core = this
    let gateKeeper = new (require(options.path.join(__dirname, '/gatekeeper')))(options)
    core.receiveRequest = function(req, res){
        res.status(200).send(JSON.stringify(options.modules))
        return true
    }
}
module.exports = yggUi