let logger = function(options){
    require('colors')
    let treeHeader = '{' + options.name + '}: '
    let underLinedHeader = ('{' + options.name + '}').underline + ': '

    let oldLog = console.log
    console.log = function(msg){
        if(typeof(msg) == 'string'){
            oldLog(treeHeader.blue + msg)
        }else{
            oldLog(underLinedHeader.blue)
            oldLog(msg)
        }
    }

    let oldError = console.error
    console.error = function(msg){
        if(typeof(msg) == 'string'){
            oldError(treeHeader.red + msg)
        }else{
            oldError(underLinedHeader.red)
            oldError(msg)
        }
    }

    console.yggdrasilOnline = function(){
        let yggonline = '{Yggdrasil Online}'.rainbow
        let treeLine = '\r\n    Tree: '.rainbow + treeHeader.blue
        let portLine = '\r\n    Port: '.rainbow + options.port
        oldLog(yggonline + treeLine + portLine)
    }
    console.treeOnline = function(treeName){
        oldLog(treeHeader.blue + 'Tree Online ('.cyan + treeName + ')'.cyan)
    }
    console.treeError = function(treeName){
        oldError(treeHeader.red + 'Error Communicating With: '.magenta + treeName)
    }
    console.chatter = function(chatter){
        let chatHeader = treeHeader.blue + 'Chatter From ('.cyan + chatter.user + ')'.cyan
        let chatLine = '\r\n    ' + chatter.data
        oldLog(chatHeader + chatLine)
    }
}
module.exports = logger