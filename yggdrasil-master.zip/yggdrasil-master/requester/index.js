let requester = function(options){
    let request = require('request')
    let core = this
    core.sendRequestAsync = function(options){
        if(typeof(options.uri) != 'string') throw new Error("Invalid URI Passed to Request")
        return new Promise(function(resolve, reject){
            request({
                uri: options.uri
                , method: 'POST'
                , json: options.json
            }, function(err, resp, body){
                if (err) {
                    reject(err)
                    return false
                } 
                if(!resp.status == 200){
                    reject(resp)
                    return false
                }
                resolve(body)
                return true
            })
        })
    }
}
module.exports = requester