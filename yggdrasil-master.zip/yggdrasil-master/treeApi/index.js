let treeApi = function(options){
    let core = this
    let gatekeeper = new (require(options.path.join(__dirname, '/gatekeeper')))({
        repo: options.repo
        , name: options.name
        , key: options.key
        , path: options.path
        , sendRequestAsync: options.sendRequestAsync
        , events: options.events
        , modules: options.modules
    })
    let treeChat = new (require(options.path.join(__dirname, '/treeChat')))({name: options.name, sendRequestAsync: options.sendRequestAsync})
    core.trees = gatekeeper.trees
    treeChat.trees = core.trees

    core.receiveRequest = function(req, res){
        if(!gatekeeper.validateRequest(req, res)) return null
        if(req.body.chatter){
            treeChat.receive(req.body.chatter)
            res.status(200).send('chat received')
            return true
        }
        try{
            let pathSplit = req.body.function.split('/')
            let moduleObj = options.modules
            for(let ind in pathSplit){
                if(pathSplit[ind] && pathSplit[ind].length > 0 && moduleObj[pathSplit[ind]]){
                    moduleObj = moduleObj[pathSplit[ind]]
                }else{
                    throw new Error("Tree Signal Does Not Correspond to Module")
                }
            }
            if(typeof(moduleObj) != 'function') throw new Error("Tree Signal Does Not Correspond to Module")
            let functionResponse = moduleObj(req.body.inputs)
            res.status(200).send(functionResponse)
            return true
        }
        catch(error){
            res.status(503).send(error)
            return false
        }
    }
}
module.exports = treeApi