let authenticator = function(options){
    let core = this
    let bcrypt = require('bcrypt')
    let salt = bcrypt.genSaltSync(10)
    core.trees = {}
    core.authenticateTree = function(authInput){
        if(!core.trees[authInput.tree]){
            repo.badLogin({ip: authInput.ip, tree: authInput.tree, badKey: authInput.key})
            throw new Error('Bad Login Attempt:\r\nOrigin: ' + authInput.tree + '\r\nIp: ' + authInput.ip)
        }
        let keyHash = bcrypt.hashSync(core.trees[authInput.tree].keyHole, salt)
        if(bcrypt.compareSync(authInput.key, keyHash)){
            return true
        }else{
            repo.badLogin({ip: authInput.ip, tree: authInput.tree, badKey: authInput.key})
            throw new Error('Bad Login Attempt:\r\nOrigin: ' + authInput.tree + '\r\nIp: ' + authInput.ip)
        }
    }
}
module.exports = authenticator