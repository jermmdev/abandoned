let mapper = function(options){
    let core = this
    core.trees = {}
    core.genMap = function(inputModule){
        if(typeof(inputModule) == 'function'){
            return inputModule
        }
        let returnObject = {}
        for(let ind in inputModule){
            let cleaned = core.genMap(inputModule[ind])
            if(typeof(cleaned)=='function') returnObject[ind] = true
            if(typeof(cleaned)=='object') returnObject[ind] = cleaned
        }
        return returnObject
    }
    core.genFunctions = function(moduleMap, treeName, functionPath = ''){
        if(!treeName) throw new Error("genFunctions requires a tree name")
        let returnObject = {}
        if(moduleMap === true) return function(inputs){
            return options.sendRequestAsync({
                uri: core.trees[treeName].address
                , json: {
                    tree: options.name
                    , scent: core.trees[treeName].scent
                    , function: functionPath.substring(0, functionPath.length - 1)
                    , inputs: inputs
                }
            }).catch(function(error){
                console.treeError(treeName)
            })
        }
        for(let ind in moduleMap){
            returnObject[ind] = core.genFunctions(moduleMap[ind], treeName, functionPath + ind + '/')
        }
        return returnObject
    }
}
module.exports = mapper