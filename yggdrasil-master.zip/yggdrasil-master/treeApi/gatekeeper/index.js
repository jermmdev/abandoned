let gatekeeper = function(options){
    let core = this
    let sessions = {}
    let mapper = new (require(options.path.join(__dirname, '/moduleMapper')))(options)
    core.trees = options.repo.getTrees()
    mapper.trees = core.trees
    let moduleMap = mapper.genMap(options.modules)

    let authenticator = new (require(options.path.join(__dirname+'/authenticator')))()
    authenticator.trees = core.trees
    let invalidSignalLimits = new (require(options.path.join(__dirname+'/invalidSignalLimits')))({repo: options.repo})

    let sendLoginRequestAsync = async function(treeName){
        return options.sendRequestAsync({
            uri: core.trees[treeName].address
            , json: {
                login: true
                , tree: options.name
                , key: options.key
            }
        }).then(function(data){
            if(data.scent && data.moduleMap){
                core.trees[treeName].scent = data.scent
                core.trees[treeName].moduleMap = data.moduleMap
                core.trees[treeName].modules = mapper.genFunctions(data.moduleMap, treeName)
                options.events.emit('treeOnline', treeName)
                console.treeOnline(treeName)
            }else{
                throw new Error('Login Failed with Remote Tree: ' + treeName)
            }
        }).catch(function(error){
            console.treeError(treeName)
            if(core.trees[treeName].scent) delete core.trees[treeName].scent
            if(core.trees[treeName].moduleMap) delete core.trees[treeName].scent
            if(core.trees[treeName].modules) delete core.trees[treeName].modules
        })
    }

    for(let ind in core.trees){
        core.trees[ind].sendLoginRequestAsync = async function(){
            return sendLoginRequestAsync(ind)
        }
    }

    let counterLoginAsync = async function(treeName){
        if(!core.trees[treeName]) throw new Error('Cannot verify login with a tree not in the forest.')
        return options.sendRequestAsync({
            uri: core.trees[treeName].address
            , json: {
                isValid: true
                , tree: options.name
                , scent: sessions[treeName]
            }
        }).then(function(data){
            if(!data.isValid){
                sendLoginRequestAsync(treeName)
            }
        }).catch(function(error){
            console.error('Failed Counter Login with: ' + treeName + '\r\n   Is your address correct?')
        })
    }

    core.validateRequest = function(req, res){
        let forbiddenMsg = {error: 'Source Not Trusted'}
        if(invalidSignalLimits.overBadSignalLimit(req.connection.remoteAddress)){
            options.repo.badLogin({ip: req.connection.remoteAddress, tree: req.body.tree, badKey: req.body.key})
            options.repo.badSignal({ip: req.connection.remoteAddress, body: req.body})
            res.status(403).send(forbiddenMsg)
            return false
        }
        if(req.body.login){
            if(invalidSignalLimits.overBadLoginLimit(req.connection.remoteAddress)){
                options.repo.badLogin({ip: req.connection.remoteAddress, tree: req.body.tree, badKey: req.body.key})
                options.repo.badSignal({ip: req.connection.remoteAddress, body: req.body})
                res.status(403).send(forbiddenMsg)
                return false
            }
            try{
                let scent = authenticator.authenticateTree({ip: req.connection.remoteAddress, tree: req.body.tree, key: req.body.key})
                sessions[req.body.tree] = scent
                counterLoginAsync(req.body.tree)
                res.status(200).send({scent: scent, moduleMap: moduleMap})
                return false
            }catch(error){
                options.repo.badLogin({ip: req.connection.remoteAddress, tree: req.body.tree, badKey: req.body.key})
                options.repo.badSignal({ip: req.connection.remoteAddress, body: req.body})
                res.status(403).send(forbiddenMsg)
                return false
            }
        } 
        if(sessions[req.body.tree] && sessions[req.body.tree] == req.body.scent){
            if(req.body.isValid){
                res.status(200).send({isValid: true})
                return false
            }
            return true
        }
        else {
            options.repo.badSignal({ip: req.connection.remoteAddress, body: req.body})
            res.status(403).send(forbiddenMsg)
            return false
        }
    }
}
module.exports = gatekeeper