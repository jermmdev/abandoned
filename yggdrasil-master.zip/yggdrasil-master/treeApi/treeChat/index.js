let treeChat = function(options){
    let core = this
    let myName = options.name
    core.trees = {}
    core.receive = function(chat){
        chat.data = chat.data.trim()
        console.chatter(chat)
        if(chat.user != myName) process.stdout.write('\u0007')
        return true
    }
    core.send = function(data){
        let chatString = `${data}`
        core.receive({user: myName, data: chatString})
        for(let ind in core.trees){
            if(core.trees[ind].scent){
                options.sendRequestAsync({
                    uri: core.trees[ind].address
                    , json: {
                        tree: myName
                        , scent: core.trees[ind].scent
                        , chatter: {
                            user: myName
                            , data: chatString
                        }
                    }
                }).catch(function(error){
                    console.error('Chatter '.underline.grey + 'NOT'.underline.red + ' Received By'.underline.grey + ': '.grey + ind)
                    console.error(error)
                })
            }
        }
    }
    process.stdin.on('data', core.send)
}
module.exports = treeChat