let serveModule = function(options){
    let core = this
    let bodyParser = require('body-parser')
    let express = require('express')
    let gatekeeper = new (require(options.path.join(__dirname, '/gatekeeper')))()
    let bot = express()
    bot.use(bodyParser.json())
    core.treeRequest = function(){}
    core.uiRequest = function(){}
    let postHandler = function(req, res){
        if(!gatekeeper.validatePost(req, res)) return null
        return core.treeRequest(req, res)
    }
    bot.post('/*', postHandler)
    let getHandler = function(req, res){
        if(!gatekeeper.validateGet(req, res)) return null
        return core.uiRequest(req, res)
    }
    bot.get('/*', getHandler)

    bot.listen(options.port, console.yggdrasilOnline)
}
module.exports = serveModule