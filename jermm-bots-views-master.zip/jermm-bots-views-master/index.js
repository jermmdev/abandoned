let fs = require('fs')
let path = require('path')
let seedPath = path.join(__dirname, 'jermm-bots-seed')
let getHub = require('gethub')

let seedReady = ()=>{
    let seedCore = require(seedPath)
    let myViews = require('./myViewEngine.js')
    new seedCore(myViews, 'wss://jermm-bots-root-jermm-bots.b9ad.pro-us-east-1.openshiftapps.com', 'jermmViews', 'IMakeViews', 'BelieveItTteBayoDawg', 8080)
}

if(!fs.existsSync(seedPath)){
    console.log('getting botsclient')
    getHub('jermmdev', 'jermm-bots-seed', 'master', seedPath).then(seedReady).catch((err)=>{
        throw err
    }) 
}else{
    console.log('already had client')
    seedReady()
}