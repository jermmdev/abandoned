# jermm-bots-views
A view renderer for the jermm-bots network
