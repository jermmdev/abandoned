let pug = require('pug')
let fs = require('fs')
let Color = require('color')
let views = function(){
    let pugViews = fs.readdirSync('./pugViews')
    let jermmImageData = fs.readFileSync('./jermmdev.png', {
        encoding: 'base64'
    })
    let resumeFunc = pug.compileFile('./pugViews/resume/index.pug')
    this.resume = (options = {})=>{
        if(!options.navImg) options.navImg = 'data:image/png;base64,'+jermmImageData
        if(!options.backColor) options.backColor = 'rgb(218, 240, 202)' //light green
        if(!options.frontColor) options.frontColor = 'rgb(118, 76, 36)' //brown
        let backColor = Color(options.backColor)
        let frontColor = Color(options.frontColor)
        let imgBorderColor = backColor.negate()
        let textPrimaryColor = (backColor.isLight() ? backColor.darken(.5) : backColor.darken(0))
        let linkHoverColor = (frontColor.isLight() ? frontColor.darken(.5) : frontColor.lighten(.5))
        options.backColor = backColor.rgb().string()
        options.frontColor = frontColor.rgb().string()
        options.imgBorderColor = imgBorderColor.rgb().array()
        options.linkHoverColor = linkHoverColor.rgb().string()
        options.textPrimaryColor = textPrimaryColor.rgb().string()
        return resumeFunc({options:options})
    }
}
let returnObj = new views()
module.exports = returnObj