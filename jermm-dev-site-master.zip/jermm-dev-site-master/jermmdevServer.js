let express = require('express')
let fs = require('fs')
let jermmDevImg = fs.readFileSync('./jermmdev.png')
let personalPic = fs.readFileSync('./jermmdev.png')
let bot = new express()
let path = require('path')
let BSLDir = path.join(__dirname, '.well-known/acme-challenge/BSLqMp7LPFTSGkON0WFED19HZ1Dg1efMelQydPKHXS4')
let wwwchallenge = fs.readFileSync(BSLDir, 'utf8')
let QqEDir = path.join(__dirname, '.well-known/acme-challenge/QqEXWlMC0WSIeV62bVmT8EX0Pa3DYJeqacBER4gY7ZA')
let rootchallenge = fs.readFileSync(QqEDir, 'utf8')
bot.get('/.well-known/acme-challenge/BSLqMp7LPFTSGkON0WFED19HZ1Dg1efMelQydPKHXS4', (req, res)=>{
    res.status(200).send(wwwchallenge)
})
bot.get('/.well-known/acme-challenge/QqEXWlMC0WSIeV62bVmT8EX0Pa3DYJeqacBER4gY7ZA', (req, res)=>{
    res.status(200).send(rootchallenge)
})
bot.get('/img/jermmdev.png', (req, res) => {
    res.status(200).send(jermmDevImg)
})
bot.get('/img/personalPic.png', (req, res) => {
    res.status(200).send(personalPic)
})
bot.onGet = (req, res)=>{}
module.exports = bot