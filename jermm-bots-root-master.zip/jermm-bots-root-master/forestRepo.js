let njdb = require('node-json-db')
let forestDb = new njdb('forest')
forestDb.tryGet = (path) => {
    try{
        let dataResponse = forestDb.getData(path)
        return dataResponse
    }catch(err){
        console.error(err)
        return false
    }
}
forestDb.validateName = (path) => {
    if(
        typeof(path) != 'string'
        || path.indexOf('/') > -1
        || path.length == 0
    ){
        return false
    }else{
        return true
    }
}
forestDb.getCore = (name) => {
    if(!forestDb.validateName(name)) return false
    return forestDb.tryGet('/core/' + name)
}
forestDb.getClient = (name) => {
    if(!forestDb.validateName(name)) return false
    return forestDb.tryGet('/clients/' + name)
}
module.exports = forestDb