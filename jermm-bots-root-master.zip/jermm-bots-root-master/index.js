let fs = require('fs')
let path = require('path')
let express = require('express')
let getHub = require('gethub')
let wssPath = path.join(__dirname, 'jermm-wss')
let forest = require('./forestRepo.js')
let danger = require('./dangerRepo.js')
let bot = new express()
let http = require('http')
let pug = require('pug')
let displayPath = path.join(__dirname, 'display.pug')
let displayView = pug.compileFile(displayPath)
let wssIsReady = ()=>{
    let yggApi = {}
    let core = {}
    let corePreregister = {}
    let clients = {}
    let clientsPreregister = {}
    bot.get('/*', (req, res)=>{
        res.status(200).send(displayView({jermmBotsApi: yggApi, jermmBotsClients: clients}))
    })
    let server = http.createServer(bot)
    let wss = new (require(wssPath))(8080, server)
    let refreshApi = ()=>{
        for(let ind in clients){
            clients[ind].sendify({yggApi: yggApi})
        }
    }
    let registerCore = (coreLogin, coreData, wsId)=>{
        if(corePreregister[coreLogin.name]){
            console.log('Duplicate Core Registration: ', coreLogin.name)
            return false
        }
        corePreregister[coreLogin.name] = true
        let coreWs = {} 
        coreWs = wss.GetSocket(coreData.address)
        coreWs.on('open', ()=>{
            core[coreLogin.name] = coreWs
            if(corePreregister[coreLogin.name]) delete corePreregister[coreLogin.name]
            coreWs.sendify({
                yggLoginResponse: {
                    privateKey: coreData.privateKey
                    , token: coreLogin.token
                }
            })
            coreWs.sendify({
                jermmPing: 'pong'
            })
            setTimeout(()=>{
                if(!yggApi[coreLogin.name] && core[coreLogin.name]){
                    console.error('Core Never Checked In: ' + coreLogin.name)
                    core[coreLogin.name].close()
                }
            }, 10*1000)
        })
        coreWs.on('close', (closeCode)=>{
            if(core[coreLogin.name]) delete core[coreLogin.name]
            console.log('Core Offline: ' + coreLogin.name)
            if(yggApi[coreLogin.name]) delete yggApi[coreLogin.name]
            refreshApi()
        })
        coreWs.onMessage = (msg)=>{
            if(msg.jermmPing){
                setTimeout(()=>{
                    if(core[coreLogin.name]) core[coreLogin.name].sendify({jermmPing: 'pong'})
                }, 50*1000)
                return true
            }
            if(msg.coreApi){
                yggApi[coreLogin.name] = msg.coreApi
                refreshApi()
                return true
            }
            if(
                !msg.output
                || !msg.input
            ){
                if(msg.error){
                    if(core[coreLogin.name]) core[coreLogin.name].sendify({
                        error: msg.error
                        , token: msg.originalMsg.token
                        , input: msg.originalMsg.input
                    })
                }else console.error('Invalid Core Message', msg)
                return false
            }
            if(clients[msg.input.sender]){
                clients[msg.input.sender].sendify({
                    output: msg.output
                    , token: msg.input.token
                    , input: msg.input.input
                })
            }else console.error('Client Went Offline During Request: ' + msg.input.sender)
        }
        console.log('Core Online: ' + coreLogin.name)
        return true
    }
    let registerClient = (clientLogin, clientData, wsId)=>{
        if(clientsPreregister[clientLogin.name]){
            console.log('Duplicate Client Registration: ', clientLogin.name)
            return false
        }
        clientsPreregister[clientLogin.name] = true
        let clientWs = {}
        clientWs = wss.GetSocket(clientData.address)
        clientWs.on('open', ()=>{
            clients[clientLogin.name] = clientWs
            if(clientsPreregister[clientLogin.name]) delete clientsPreregister[clientLogin.name]
            clientWs.sendify({
                yggLoginResponse: {
                    privateKey: clientData.privateKey
                    , token: clientLogin.token
                    , yggApi: yggApi
                }
            })
            clientWs.sendify({
                jermmPing: 'pong'
            })
        })
        clientWs.on('close', (closeCode)=>{
            console.log('Client Offline: ' + clientLogin.name)
            if(clients[clientLogin.name]) delete clients[clientLogin.name]
            if(clientsPreregister[clientLogin.name]) delete clientsPreregister[clientLogin.name]
        })
        clientWs.onMessage = (msg)=>{
            if(msg.jermmPing){
                setTimeout(()=>{
                    if(wss.connected[wsId]) wss.connected[wsId].ws.sendify({jermmPing: 'pong'})
                }, 50*1000)
            }
            if(core[msg.core]){
                core[msg.core].sendify({
                    sender: clientLogin.name
                    , logic: msg.logic
                    , input: msg.input
                    , token: msg.token
                })
            }else{
                if(wss.connected[wsId]) wss.connected[wsId].ws.sendify({token: msg.token, response: {error: 'Core Not Ready', core: msg.core}})
            }
        }
        console.log('Client Online: ' + clientLogin.name)
        return true
    }
    wss.onConnect = ()=>{
    }
    wss.onMessage = (msg, wsId) => {
        if(msg.coreLogin){
            let coreData = forest.getCore(msg.coreLogin.name)
            if(!coreData){
                danger.log('Invalid Core Name Attempted', {msg: msg, req: wss.connected[wsId] ? wss.connected[wsId].req : null})
                if(wss.connected[wsId]) wss.connected[wsId].ws.close()
                return false
            }
            if(msg.coreLogin.publicKey === coreData.publicKey){
                if(core[msg.coreLogin.name]){
                    danger.log('Core Already Logged In', {msg: msg, req: wss.connected[wsId] ? wss.connected[wsId].req : null})
                    if(wss.connected[wsId]) wss.connected[wsId].ws.close()
                    return false
                }
                return registerCore(msg.coreLogin, coreData, wsId)
            }else{
                danger.log('Invalid Public Key', {msg: msg, req: wss.connected[wsId] ? wss.connected[wsId].req : null})
                if(wss.connected[wsId]) wss.connected[wsId].ws.close()
                return false
            }
        }
        if(msg.clientLogin){
            let clientData = forest.getClient(msg.clientLogin.name)
            if(!clientData){
                danger.log('Invalid Client Name Attempted', {msg: msg, req: wss.connected[wsId] ? wss.connected[wsId].req : null})
                if(wss.connected[wsId]) wss.connected[wsId].ws.close()
                return false
            }
            if(msg.clientLogin.publicKey === clientData.publicKey){
                if(clients[msg.clientLogin.name]){
                    danger.log('Client Already Logged In', {msg: msg, req: wss.connected[wsId] ? wss.connected[wsId].req : null})
                    if(wss.connected[wsId]) wss.connected[wsId].ws.close()
                    return false
                }
                return registerClient(msg.clientLogin, clientData, wsId)
            }else{
                danger.log('Invalid Public Key', {msg: msg, req: wss.connected[wsId] ? wss.connected[wsId].req : null})
                if(wss.connected[wsId]) wss.connected[wsId].ws.close()
                return false
            }
        }
        if(wss.connected[wsId]) wss.connected[wsId].ws.close()
    }
}
if(!fs.existsSync(wssPath)){
    getHub('jermmdev', 'jermm-wss', 'master', wssPath).then(wssIsReady).catch((err)=>{
        throw err
    })
}else{
    wssIsReady()
}