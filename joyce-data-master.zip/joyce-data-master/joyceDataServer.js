let express = require('express')
let bot = new express()
let fs = require('fs')
let path = require('path')
let BSLDir = path.join(__dirname, 'acme-challenge/9xhcgDt2Er8ZcuRSWaEpFQ160hFvKbDzGu7iVzmsiLY')
let wwwchallenge = fs.readFileSync(BSLDir, 'utf8')
let QqEDir = path.join(__dirname, 'acme-challenge/DDmriX2ASpd0I5eW8TwX0oGWsPDMpWI1GDu9jFoE0QY')
let rootchallenge = fs.readFileSync(QqEDir, 'utf8')
let joyceMouse = fs.readFileSync(path.join(__dirname, 'joycemouse.png'))
bot.get('/.well-known/acme-challenge/9xhcgDt2Er8ZcuRSWaEpFQ160hFvKbDzGu7iVzmsiLY', (req, res)=>{
    res.status(200).send(wwwchallenge)
})
bot.get('/.well-known/acme-challenge/DDmriX2ASpd0I5eW8TwX0oGWsPDMpWI1GDu9jFoE0QY', (req, res)=>{
    res.status(200).send(rootchallenge)
})
bot.get('/joycemouse.png', (req, res)=>{
    res.status(200).send(joyceMouse)
})
bot.onGet = (req, res)=>{}
module.exports = bot