
let fs = require('fs')
let path = require('path')
let http = require('http')
let pug = require('pug')
let getHub = require('gethub')
let jds = require('./joyceDataServer.js')
let notReadyView = pug.renderFile('./pugViews/notReady.pug')
let clientPath = path.join(__dirname, 'jermm-bots-client')
let myYgg = false

let resumeOptions = {
    title: "Joyce-Data"
    , author: "jermmdev"
    , desc: "An example of a jermm-bots network."
    , navTitle: "Joyce Data"
    , backColor: "pink"
    , frontColor: "black"
    , navImg: "/joycemouse.png"
    , sections: {
        aboutMe: {
            headLeft: "About"
            , headRight: "Me"
            , subHead: "Contact Me at <a href=\"mailto:joice624@gmail.com\">joice624@gmail.com</a>"
            , content: ""
        },
        skills: {
            headLeft: "Skills"
            , headRight: ""
            , subHead: "my skills"
            , content: ""
        },
        experience: {
            headLeft: "Experience"
            , headRight: ""
            , subHead: "my experience"
            , content: ""
        },
        demos: {
            headLeft: "Demos"
            , headRight: ""
            , subHead: "my demos"
            , content: ""
        }
    }
}

let server = http.createServer(jds)
jds.get('/*', (req, res)=>{
    if(!myYgg || !myYgg.jermmViews || !myYgg.jermmViews.resume){
        res.status(200).send(notReadyView)
    }else{
        myYgg.jermmViews.resume(resumeOptions).then((responseData)=>{
            res.status(200).send(responseData)
        }).catch((err)=>{
            res.status(503).send(err)
        })
    }
})

let clientReady = ()=>{
    let seedClient = require(clientPath)
    let sc = new seedClient('wss://jermm-bots-root-jermm-bots.b9ad.pro-us-east-1.openshiftapps.com'
    , 'joyceData'
    , 'CutiePieSauce'
    , 'HelloMyBabyHelloMyHoney'
    , 8080
    , server
    )
    sc.events.on('online', ()=>{
        console.log('am online ', sc.yggApi)
        myYgg = sc.yggApi
    })
    sc.events.on('offline', ()=>{
        console.log('am offline', sc.yggApi)
        myYgg = false
    })
    sc.events.on('apiUpdated', ()=>{
        console.log('am updated ', sc.yggApi)
        myYgg = sc.yggApi
    })
}


if(!fs.existsSync(clientPath)){
    console.log('getting botsclient')
    getHub('jermmdev', 'jermm-bots-client', 'master', clientPath).then(clientReady).catch((err)=>{
        throw err
    })
}else{
    console.log('already had client')
    clientReady()
}