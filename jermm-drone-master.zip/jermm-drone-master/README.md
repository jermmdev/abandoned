# jermm-drone
A learning agent for a jermm colony
