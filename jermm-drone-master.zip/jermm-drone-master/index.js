let path = require('path')
let fs = require('fs')
let http = require('http')
let jtls = require(path.join(__dirname, 'jermm-tls.js'))
let trainingPage = fs.readFileSync(path.join(__dirname, 'trainingPage.html'), 'utf8')
let socketio = require('socket.io')
let socketClient = fs.readFileSync(path.join(__dirname, 'node_modules/socket.io-client/dist/socket.io.js'), 'utf8')
let jermmDrone = function(inputBotName, stimergyPath, stimergyPort, uiPort = 4222){
    let stimergySocket = jtls.connect(stimergyPort, stimergyPath)
    let droneCore = this
    droneCore.training = false
    stimergySocket.on('secureConnect', ()=>{
        console.log('Stimergy Online')
        stimergySocket.write(JSON.stringify(inputBotName))
    })
    stimergySocket.on('error', err => {
        console.error('Stimergy Socket', err)
    })
    stimergySocket.on('close', closeCode => {
        console.log('Stimergy Link Broken')
        delete stimergySocket
    })
    stimergySocket.on('data', data => {
        data = JSON.parse(data)
        if(data.jermmPing){
            setTimeout(()=>{
                if(stimergySocket) stimergySocket.write(JSON.stringify({jermmPing: true}))
            }, 30000)
            return
        }
        droneCore.training = data.training
    })
    
    let uiServer = http.createServer((req, res) => {
        if(req.headers.host !== '127.0.0.1' && req.headers.host !== 'localhost' && req.headers.host !== 'localhost:'+uiPort){
            res.end()
            return
        }
        if(req.url === '/socket.io.js'){
            res.writeHead(200, {
                'Content-Type': 'application/javascript'
                , 'charset': 'utf-8'
            })
            res.write(socketClient)
            res.end()
            return
        }
        res.writeHead(200, {
            'charset': 'utf-8'
        })
        //res.write(trainingPage)
        res.write(fs.readFileSync(path.join(__dirname, 'trainingPage.html'), 'utf8'))
        res.end()
    })
    let io = socketio(uiServer)
    io.on('connection', uiSocket => {
        if(uiSocket.request.headers.host !== '127.0.0.1' && uiSocket.request.headers.host !== 'localhost' && uiSocket.request.headers.host !== 'localhost:'+uiPort){
            console.log('Non-Local UI Socket Attempt')
            uiSocket.disconnect()
            return
        }
        console.log('UI Client Online')
        uiSocket.on('disconnect', ()=>{
            console.log('UI Client Offline')
        })
        uiSocket.on('error', err =>{
            console.error('UI Socket', err)
        })
        uiSocket.on('jermmPing', ()=>{
            setTimeout(()=>{
                uiSocket.emit('jermmPing')
            }, 30000)
        })
        uiSocket.on('droneTraining', (newTraining)=>{
            stimergySocket.write(JSON.stringify({training: newTraining}))
        })
        uiSocket.emit('serverTraining', droneCore.training)
        stimergySocket.on('data', data=>{
            data = JSON.parse(data)
            uiSocket.emit('serverTraining', data.training)
        })
        uiSocket.emit('jermmPing')
    })
    uiServer.listen(uiPort, ()=>{
        console.log('UI Ready')
    })
}
let bleh = new jermmDrone('alpha', 'localhost', 4422, 4222)
//module.exports = jermmDrone