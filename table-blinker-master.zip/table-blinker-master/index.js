var path = require('path');
var express = require('express');

var app = express();

app.set('view engine', 'pug'); 
app.set('views', path.join(__dirname, 'views'));

var createVm = {
    cases: [
        ['Is Valid', 'Is Approved', 'Action']
        , ['True', 'True', 'Send to Billing']
        , ['False', 'False', 'Return Error']
        , ['True', 'False', 'Manual Processing']
        ],
    decisions: [
        ['1','2','3','4','5']
        , ['','','','','']
        , ['','','','','']
        , ['','','','','']
        , ['','','','','']
        , ['','','','','']
        , ['','','','','']
        , ['','','','','']
        , ['','','','','']
        , ['','','','','']
        ],
    scores: [
        ['Factor', 'Action', 'Score']
        , ['', '', '']
        , ['', '', '']
        , ['', '', '']
        , ['', '', '']
        , ['', '', '']
        , ['', '', '']
        ]
}
var enhancementVm = {
    currentClaim: {
        id: '1'
        , isValid: 'True'
        , isApproved: 'True'
        },
    cases: [
        ['Is Valid', 'Is Approved', 'Is Halted', 'Action']
        , ['True', 'True', 'False', 'Send to Billing']
        , ['False', 'False', 'False', 'Return Error']
        , ['True', 'False', 'False', 'Manual Processing']
        , ['True', 'True', 'True', 'Manual Processing']
        ],
    decisions: [
        ['1','2','3','4','5','6','7']
        , ['Is this claim valid?','','','','','','']
        , ['','Yes','','','','','']
        , ['','','Is this claim approved?','','','','']
        , ['','','','Yes','','','']
        , ['','','','','Send to Billing','','']
        , ['','','','No','','','']
        , ['','','','','Manual Processing','','']
        , ['','No','','','','','']
        , ['','','Return Error','','','','']
        , ['','','','','','','']
        , ['','','','','','','']
        ],
    scores: [
        ['Factor', 'Actions', 'Score']
        , ['Is Valid', 'Send to Billing, Manual Processing', .5]
        , ['Is Approved', 'Send to Billing', 1]
        , ['Is NOT Valid', 'Return Error', 1]
        , ['Is NOT Approved', 'Return Error, Manual Processing', .5]
        , ['', '', '']
        , ['', '', '']
        , ['', '', '']
        ]
}
var computationalVm = {
    currentClaim: {
        id: '1'
        , isValid: 'True'
        , isApproved: 'True'
        },
    cases: [
        ['Claim Id', 'Is Valid', 'Is Approved', 'Action']
        , [1, 'True', 'True', 'Send to Billing']
        , [2, 'False', 'False', 'Return Error']
        , [3, 'True', 'False', 'Manual Processing']
        ],
    decisions: [
        ['1','2','3','4','5']
        , ['Is this claim valid?','','','','']
        , ['','Yes','','','']
        , ['','','Is this claim approved?','','']
        , ['','','','Yes','']
        , ['','','','','Send to Billing']
        , ['','','','No','']
        , ['','','','','Manual Processing']
        , ['','No','','','']
        , ['','','Return Error','','']
        ],
    scores: [
        ['Factor', 'Action', 'Score']
        , ['Is Valid', 'Send to Billing', .5]
        , ['Is Valid', 'Manual Processing', .5]
        , ['Is Approved', 'Send to Billing', 1]
        , ['Is NOT Valid', 'Return Error', 1]
        , ['Is NOT Approved', 'Return Error', .5]
        , ['Is NOT Approved', 'Manual Processing', .5]
        ]
}
app.get('/', function (req, res) {
    var vm = computationalVm;
    return res.render('usingSolution/presentation', { vm: vm });
});
app.get('/use', function (req, res) {
    var vm = computationalVm;
    return res.render('usingSolution/presentation', { vm: vm });
});
app.get('/create', function (req, res) {
    var vm = createVm;
    return res.render('creatingSolution/creatingSolution', { vm: vm });
});

app.get('/enhance', function (req, res) {
    var vm = enhancementVm;
    return res.render('enhancingSolution/presentation', { vm: vm });
});

app.listen(3000);
console.log('listening');