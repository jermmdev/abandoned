# table-blinker
A simple html,bootstrap,jquery animated tables framework/example.
