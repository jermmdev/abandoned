var AnimationScripts = function(){
    var core = this;

    var tb = new TableBlinker();
    var moveRate = 1000;
    var firstWave = 1;

    var step = function(waveId){
        setTimeout(function(){
            if(eval('typeof(wave'+waveId+')') != 'undefined') tb.muteSingles();
            if(eval('wave'+waveId+'()')) {
                step((waveId+1))
            };
            }, moveRate);
    }

    this.start = function(){
        step(firstWave);
    }

    var wave1 = function(){
        tb.speak('Amy\'s approach is simple and universal.  The work is done at the data level.  Once the problem is defined, the machine takes over.');
        tb.yellow(1,1,2);
        tb.blue(1,2,1);
        return true;
    }

    var wave2 = function(){
        tb.greenOnce(3,2);
        tb.greenOnce(2,2,1);
        tb.switchText(2,2,1, "Is the claim approved?");
        tb.switchText(3,2,1, "Is Valid: True");
        tb.switchText(3,2,2, "Send To Billing");
        tb.switchText(3,2,3, "1");
        return true;
    }

    var wave3 = function(){
        tb.mute(1,2,1);
        tb.blueOnce(1,2,2);
        tb.greenOnce(3,3);
        tb.switchText(3,3,1, "Is Approved: True");
        tb.switchText(3,3,2, "Send to Billing");
        tb.switchText(3,3,3, "1");
        tb.greenOnce(2,3,2);
        tb.switchText(2,3,2,"Yes");
        tb.redOnce(2,9,2);
        tb.switchText(2,9,2,"No");
        return true;
    }

    var wave4 = function(){
        tb.blueOnce(1,3,1);
        tb.mute(1,1,2);
        tb.yellow(1,1,1);
        tb.greenOnce(3,4);
        tb.switchText(3,4,1, "Is Valid: False");
        tb.switchText(3,4,2, "Return Error");
        tb.switchText(3,4,3, "1");
        tb.greenOnce(2,4,3);
        tb.switchText(2,4,3, "Is the claim valid?");
        return true;
    }

    var wave5 = function(){
        tb.mute(1,3,1);
        tb.blueOnce(1,3,2);
        tb.greenOnce(3,5);
        tb.switchText(3,5,1, "Is Approved: False");
        tb.switchText(3,5,2, "Return Error");
        tb.switchText(3,5,3, "1");
        tb.greenOnce(3,5,3);
        tb.switchText(3,5,3,"1");
        tb.greenOnce(2,5,4);
        tb.switchText(2,5,4,"Yes");
        tb.redOnce(2,7,4);
        tb.switchText(2,7,4,"No");
        return true;
    }

    var wave6 = function(){
        tb.blueOnce(1,4,1);
        tb.mute(1,1,1);
        tb.yellow(1,1,3);
        tb.greenOnce(3,6);
        tb.switchText(3,6,1, "Is Valid: True");
        tb.switchText(3,6,2, "Manual Processing");
        tb.switchText(3,6,3, ".5");
        tb.redOnce(3,2,3);
        tb.switchText(3,2,3, ".5");
        tb.greenOnce(2,6,5);
        tb.switchText(2,6,5, "Send to Billing");
        return true;
    }

    var wave7 = function(){
        tb.blueOnce(1,4,2);
        tb.mute(1,1,1);
        tb.greenOnce(3,7);
        tb.switchText(3,7,1, "Is Approved: False");
        tb.switchText(3,7,2, "Manual Processing");
        tb.switchText(3,7,3, ".5");
        tb.redOnce(3,5,3);
        tb.switchText(3,5,3, ".5");
        tb.greenOnce(2,8,5);
        tb.switchText(2,8,5, "Manual Processing");
        $('#amyLabel').removeClass('alert-info');
        $('#amyLabel').addClass('alert-success');
        return true;
    }

    //AMY IS DONE!!!

    var wave8 = function(){
        tb.mute(1,1,3);
        tb.yellow(1,1,1);
        tb.greenOnce(2,10,3);
        tb.switchText(2,10,3, "Is the claim valid?");
        return true;
    }

    var wave9 = function(){
        tb.speak('Alice will catch up soon.');
        tb.mute(1,1,1);
        tb.redOnce(2);
        tb.clearText(2,2,1);
        tb.clearText(2,3,2);
        tb.clearText(2,4,3);
        tb.clearText(2,5,4);
        tb.clearText(2,6,5);
        tb.clearText(2,7,4);
        tb.clearText(2,8,5);
        tb.clearText(2,9,2);
        tb.clearText(2,10,3);
        return true;
    }

    var wave10 = function(){
        tb.yellow(1,1,1);
        tb.greenOnce(2,2,1);
        tb.switchText(2,2,1, 'Is the claim valid?');
        return true;
    }

    var wave11 = function(){
        tb.greenOnce(2,3,2);
        tb.redOnce(2,9,2);
        tb.switchText(2,3,2,'Yes');
        tb.switchText(2,9,2,'No');
        return true;
    }

    var wave12 = function(){
        tb.greenOnce(2,4,3);
        tb.switchText(2,4,3, 'Is the claim approved?');
        tb.mute(1,1,1);
        tb.yellow(1,1,2);
        return true;
    }

    var wave13 = function(){
        tb.greenOnce(2,5,4);
        tb.redOnce(2,7,4);
        tb.switchText(2,5,4,'Yes');
        tb.switchText(2,7,4,'No');
        return true;
    }
    
    var wave14 = function(){
        tb.mute(1,1,2);
        tb.yellow(1,1,3);
        tb.switchText(2,6,5, 'Send to Billing');
        tb.greenOnce(2,6,5);
        return true;
    }

    var wave15 = function(){
        tb.switchText(2,8,5, 'Manual Processing');
        tb.greenOnce(2,8,5);
        return true;
    }

    var wave16 = function(){
        tb.mute(1,1,3);
        tb.switchText(2,10,3, 'Return Error');
        tb.greenOnce(2,10,3);
        $('#aliceLabel').removeClass('alert-warning');
        $('#aliceLabel').addClass('alert-success');
        $('#claimsLabel').removeClass('alert-danger');
        $('#claimsLabel').addClass('alert-success');
        return true;
    }

    var wave17 = function(){return true;}
    var wave18 = function(){return true;}
    var wave19 = function(){return true;}
    var wave20 = function(){return true;}

    var wave21 = function(){
        $('#aliceLabel').addClass('alert-warning');
        $('#aliceLabel').removeClass('alert-success');
        $('#claimsLabel').addClass('alert-danger');
        $('#claimsLabel').removeClass('alert-success');
        $('#amyLabel').addClass('alert-info');
        $('#amyLabel').removeClass('alert-success');
        tb.clearText(2,2,1);
        tb.clearText(2,3,2);
        tb.clearText(2,4,3);
        tb.clearText(2,5,4);
        tb.clearText(2,6,5);
        tb.clearText(2,7,4);
        tb.clearText(2,8,5);
        tb.clearText(2,9,2);
        tb.clearText(2,10,3);
        tb.clearText(3,2,1);
        tb.clearText(3,2,2);
        tb.clearText(3,2,3);
        tb.clearText(3,3,1);
        tb.clearText(3,3,2);
        tb.clearText(3,3,3);
        tb.clearText(3,4,1);
        tb.clearText(3,4,2);
        tb.clearText(3,4,3);
        tb.clearText(3,5,1);
        tb.clearText(3,5,2);
        tb.clearText(3,5,3);
        tb.clearText(3,6,1);
        tb.clearText(3,6,2);
        tb.clearText(3,6,3);
        tb.clearText(3,7,1);
        tb.clearText(3,7,2);
        tb.clearText(3,7,3);
        core.start();
    }
}