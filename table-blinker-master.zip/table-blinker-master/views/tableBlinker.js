var TableBlinker = function(){
    var core = this;

    this.green = function(table, row, col){
        if(typeof(row)=='undefined'){
            $('.tTable'+table).addClass('alert-success');
            return;
        }
        if(typeof(col)=='undefined'){
            $('.tTable'+table+' .tRow'+row).addClass('alert-success');
            return;
        }
        $('.tTable'+table+' .tRow'+row+' .tCol'+col).addClass('alert-success');
        }
    this.red = function(table, row, col){
        if(typeof(row)=='undefined'){
            $('.tTable'+table).addClass('alert-danger');
            return;
        }
        if(typeof(col)=='undefined'){
            $('.tTable'+table+' .tRow'+row).addClass('alert-danger');
            return;
        }
        $('.tTable'+table+' .tRow'+row+' .tCol'+col).addClass('alert-danger');
        }
    this.greenOnce = function(table, row, col){
        if(typeof(row)=='undefined'){
            $('.tTable'+table).addClass('alert-success green-once');
            return;
        }
        if(typeof(col)=='undefined'){
            $('.tTable'+table+' .tRow'+row).addClass('alert-success green-once');
            return;
        }
        $('.tTable'+table+' .tRow'+row+' .tCol'+col).addClass('alert-success green-once');
        }
    this.redOnce = function(table, row, col){
        if(typeof(row)=='undefined'){
            $('.tTable'+table).addClass('alert-danger red-once');
            return;
        }
        if(typeof(col)=='undefined'){
            $('.tTable'+table+' .tRow'+row).addClass('alert-danger red-once');
            return;
        }
        $('.tTable'+table+' .tRow'+row+' .tCol'+col).addClass('alert-danger red-once');
        }
    this.blue = function(table, row, col){
        if(typeof(row)=='undefined'){
            $('.tTable'+table).addClass('alert-info');
            return;
        }
        if(typeof(col)=='undefined'){
            $('.tTable'+table+' .tRow'+row).addClass('alert-info');
            return;
        }
        $('.tTable'+table+' .tRow'+row+' .tCol'+col).addClass('alert-info');
        }
    this.yellow = function(table, row, col){
        if(typeof(row)=='undefined'){
            $('.tTable'+table).addClass('alert-warning');
            return;
        }
        if(typeof(col)=='undefined'){
            $('.tTable'+table+' .tRow'+row).addClass('alert-warning');
            return;
        }
        $('.tTable'+table+' .tRow'+row+' .tCol'+col).addClass('alert-warning');
        }
    this.blueOnce = function(table, row, col){
        if(typeof(row)=='undefined'){
            $('.tTable'+table).addClass('alert-info blue-once');
            return;
        }
        if(typeof(col)=='undefined'){
            $('.tTable'+table+' .tRow'+row).addClass('alert-info blue-once');
            return;
        }
        $('.tTable'+table+' .tRow'+row+' .tCol'+col).addClass('alert-info blue-once');
        }
    this.yellowOnce = function(table, row, col){
        if(typeof(row)=='undefined'){
            $('.tTable'+table).addClass('alert-warning yellow-once');
            return;
        }
        if(typeof(col)=='undefined'){
            $('.tTable'+table+' .tRow'+row).addClass('alert-warning yellow-once');
            return;
        }
        $('.tTable'+table+' .tRow'+row+' .tCol'+col).addClass('alert-warning yellow-once');
        }
    this.mute = function(table, row, col){
        if(typeof(row)=='undefined'){
            $('.tTable'+table).removeClass('alert-success alert-warning alert-info alert-danger');
            return;
        }
        if(typeof(col)=='undefined'){
            $('.tTable'+table+' .tRow'+row).removeClass('alert-success alert-warning alert-info alert-danger');
            return;
        }
        $('.tTable'+table+' .tRow'+row+' .tCol'+col).removeClass('alert-success alert-warning alert-info alert-danger');
        }

    this.muteSingles = function(){
        $('.green-once').removeClass('alert-success green-once');
        $('.red-once').removeClass('alert-danger red-once');
        $('.blue-once').removeClass('alert-info blue-once');
        $('.yellow-once').removeClass('alert-warning yellow-once');
        }
    this.speak = function(text){
        $('.convoBoxText').html(text);
        $('.convoBox').addClass('showBox');
        setTimeout(function(){$('.convoBox').removeClass('showBox'); setTimeout(function(){$('.convoBoxText').html('');}, 1000);},5000);
        }
    this.switchText = function(table, row, col, newText){
        $('.tTable'+table+' .tRow'+row+' .tCol'+col+' span').removeClass('text-show');
        setTimeout(function(){
            $('.tTable'+table+' .tRow'+row+' .tCol'+col+' span').html(newText);
            $('.tTable'+table+' .tRow'+row+' .tCol'+col+' span').addClass('text-show');
            }, 250);
        }
    this.clearText = function(table, row, col){
        $('.tTable'+table+' .tRow'+row+' .tCol'+col+' span').removeClass('text-show');
        setTimeout(function(){
            $('.tTable'+table+' .tRow'+row+' .tCol'+col+' span').html('&nbsp;');
            $('.tTable'+table+' .tRow'+row+' .tCol'+col+' span').addClass('text-show');
            }, 500);
        }
    }