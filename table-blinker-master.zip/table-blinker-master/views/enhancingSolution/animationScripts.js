var AnimationScripts = function(){
    var core = this;
    var tb = new TableBlinker();
    var moveRate = 1000;

    var claimsDisplay = $('#claimsDisplay');
    var currentClaim = $('#currentClaim')
    var isValid = $('#isValid')
    var isApproved = $('#isApproved')
    var claimsLabel = $('#claimsLabel');

    var aliceDisplay = $('#aliceDisplay');
    var bestMatchAlice = $('#bestMatchAlice');
    var currentStep = $('#currentStep');
    var aliceLabel = $('#aliceLabel');

    var amyDisplay = $('#amyDisplay');
    var sendToBillingScore = $('#sendToBillingScore');
    var manualProcessingScore = $('#manualProcessingScore');
    var returnErrorScore = $('#returnErrorScore');
    var bestMatchAmy = $('#bestMatchAmy');
    var amyLabel = $('#amyLabel');

    var firstWave = 1;

    var green = function(elem){
        elem.addClass('alert-success');
    }

    var mute = function(elem){
        elem.removeClass('alert-success');
    }

    var step = function(waveId){
        setTimeout(function(){
            if(eval('typeof(wave'+waveId+') != "undefined"')) tb.muteSingles();
            if(eval('wave'+waveId+'()')) step((waveId+1));
            }, moveRate);
    }

    this.start = function(){
        step(firstWave);
    }

    var resetDisplays = function(){
        aliceLabel.removeClass('alert-success');
        aliceLabel.addClass('alert-warning');
        amyLabel.removeClass('alert-success');
        amyLabel.addClass('alert-info');
        claimsLabel.removeClass('alert-success');
        claimsLabel.addClass('alert-danger');
    }

    var wave1 = function(){
        tb.greenOnce(1,5);
        tb.greenOnce(2,2,1);
        $('.computingSignal').addClass('showSignal')
        tb.speak('Upgrading Amy\'s system from a new data model is automatic.  The software is designed ready to learn.');
        return true;
    }

    var wave2 = function(){
        tb.blueOnce(1,5);
        tb.greenOnce(2,3,2);
        tb.redOnce(3,6);
        tb.switchText(3,6,1,'Is Valid');
        tb.switchText(3,6,2,'Manual Processing');
        tb.switchText(3,6,3,'.66');
        tb.redOnce(3,7);
        tb.switchText(3,7,1,'Is Approved');
        tb.switchText(3,7,2,'Manual Processing');
        tb.switchText(3,7,3,'.33');
        tb.greenOnce(3,8);
        tb.switchText(3,8,1,'Is Halted');
        tb.switchText(3,8,2,'Manual Processing');
        tb.switchText(3,8,3,'1');
        tb.redOnce(3,2,2);
        tb.switchText(3,2,2,'Send to Billing');
        tb.redOnce(3,2,3);
        tb.switchText(3,2,3,'.33');
        $('#amyLabel').removeClass('alert-info');
        $('#amyLabel').addClass('alert-success');
        return true;
    }

    var wave3 = function(){
        tb.greenOnce(2,4,3);
        $('.computingSignal').removeClass('showSignal')
        return true;
    }

    var wave4 = function(){
        tb.greenOnce(2,5,4);
        return true;
    }

    var wave5 = function(){
        tb.redOnce(2,6,5);
        tb.switchText(2,6,5,'Is this claim halted?');
        tb.redOnce(2,8,5);
        tb.clearText(2,8,5)
        tb.redOnce(2,7,4);
        tb.clearText(2,7,4)
        tb.redOnce(2,9,2);
        tb.clearText(2,9,2)
        tb.redOnce(2,10,3);
        tb.clearText(2,10,3)
        tb.greenOnce(2,11,2);
        tb.switchText(2,11,2,'No');
        tb.greenOnce(2,12,3);
        tb.switchText(2,12,3,'Return Error');
        tb.switchText(2,9,4,'No');
        tb.greenOnce(2,9,4);
        tb.switchText(2,10,5,'Manual Processing');
        tb.greenOnce(2,10,5)
        $('.computingSignal').removeClass('showSignal')
        return true;
    }

    var wave6 = function(){
        tb.greenOnce(2,7,6);
        tb.switchText(2,7,6,'Yes');
        tb.redOnce(2,9,6);
        tb.switchText(2,9,6,'No');
        tb.greenOnce(2,10,7);
        tb.switchText(2,10,7, 'Send to Billing');
        return true;
    }

    var wave7 = function(){
        tb.greenOnce(2,8,7);
        tb.switchText(2,8,7,'Manual');
        $('#aliceLabel').removeClass('alert-warning');
        $('#aliceLabel').addClass('alert-success');
        $('#claimsLabel').removeClass('alert-danger');
        $('#claimsLabel').addClass('alert-success');
        return true;
    }

    var wave8 = function(){ return true;}
    var wave9 = function(){return true;}
    var wave10 = function(){return true;}
    var wave11 = function(){return true;}

    var wave12 = function(){
        tb.switchText(2,6,5,'Send to Billing');
        tb.clearText(2,9,4);
        tb.switchText(2,7,4,'No');
        tb.clearText(2,10,5);
        tb.switchText(2,8,5,'Manual Processing');
        tb.clearText(2,11,2);
        tb.switchText(2,9,2,'No');
        tb.clearText(2,12,3);
        tb.switchText(2,10,3,'Return Error');
        tb.clearText(2,7,6);
        tb.clearText(2,8,7);
        tb.clearText(2,9,6);
        tb.clearText(2,10,7);
        tb.clearText(3,6,1);
        tb.clearText(3,6,2);
        tb.clearText(3,6,3);
        tb.clearText(3,7,1);
        tb.clearText(3,7,2);
        tb.clearText(3,7,3);
        tb.clearText(3,8,1);
        tb.clearText(3,8,2);
        tb.clearText(3,8,3);
        resetDisplays();
        core.start();
    }
}