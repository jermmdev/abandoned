var AnimationScripts = function(){
    var core = this;
    var tb = new TableBlinker();
    var moveRate = 1000;

    var claimsDisplay = $('#claimsDisplay');
    var currentClaim = $('#currentClaim')
    var isValid = $('#isValid')
    var isApproved = $('#isApproved')
    var claimsLabel = $('#claimsLabel');

    var aliceDisplay = $('#aliceDisplay');
    var bestMatchAlice = $('#bestMatchAlice');
    var currentStep = $('#currentStep');
    var aliceLabel = $('#aliceLabel');

    var amyDisplay = $('#amyDisplay');
    var sendToBillingScore = $('#sendToBillingScore');
    var manualProcessingScore = $('#manualProcessingScore');
    var returnErrorScore = $('#returnErrorScore');
    var bestMatchAmy = $('#bestMatchAmy');
    var amyLabel = $('#amyLabel');

    var firstWave = 1;

    var green = function(elem){
        elem.addClass('alert-success');
    }

    var mute = function(elem){
        elem.removeClass('alert-success');
    }

    var step = function(waveId){
        setTimeout(function(){
            if(eval('typeof(wave'+waveId+') != "undefined"')) tb.muteSingles();
            if(eval('wave'+waveId+'()')) step((waveId+1));
            }, moveRate);
    }

    this.start = function(){
        step(firstWave);
    }

    var resetDisplays = function(){
        claimsDisplay.removeClass('alert-success');
        aliceDisplay.removeClass('alert-success');
        amyDisplay.removeClass('alert-success');
        currentClaim.html('N/A');
        isValid.html('N/A');
        isApproved.html('N/A');
        bestMatchAlice.html('N/A');
        bestMatchAmy.html('N/A');
        currentStep.html('N/A');
        sendToBillingScore.html('N/A');
        manualProcessingScore.html('N/A');
        returnErrorScore.html('N/A');
        aliceLabel.removeClass('alert-success');
        aliceLabel.addClass('alert-warning');
        amyLabel.removeClass('alert-success');
        amyLabel.addClass('alert-info');
        claimsLabel.removeClass('alert-success');
        claimsLabel.addClass('alert-danger');
    }

    //START - claim 1
    var wave1 = function(){
        tb.speak('Here we have two solutions to our claim filing problem.  Alice\'s established deterministic design, and Amy\'s modern probabilistic design.');
        tb.greenOnce(1,2);
        return true;
    }

    var wave2 = function(){
        green(claimsDisplay);
        currentClaim.html('1');
        isValid.html('True');
        isApproved.html('True');
        return true;
    }

    var wave3 = function(){
        green(aliceDisplay);
        green(amyDisplay);
        bestMatchAlice.html('Searching...');
        bestMatchAmy.html('Searching...');
        currentStep.html('0');
        sendToBillingScore.html('0');
        manualProcessingScore.html('0');
        returnErrorScore.html('0');
        return true;
    }

    var wave4 = function(){
        sendToBillingScore.html('.5');
        currentStep.html('1');
        tb.greenOnce(2,2,1);
        tb.greenOnce(3,2);
        return true;
    }

    var wave5 = function(){
        manualProcessingScore.html('.5');
        currentStep.html('2');
        tb.greenOnce(2,3,2);
        tb.greenOnce(3,3);
        return true;
    }

    var wave6 = function(){
        tb.greenOnce(2,4,3);
        tb.greenOnce(3,4);
        currentStep.html('3');
        sendToBillingScore.html('1.5');
        return true;
    }

    var wave7 = function(){
        tb.greenOnce(2,5,4);
        tb.redOnce(3,5);
        currentStep.html('4');
        return true;
    }

    var wave8 = function(){
        tb.greenOnce(2,6,5);
        tb.redOnce(3,6);
        currentStep.html('5');
        bestMatchAlice.html('Send to Billing');
        aliceLabel.removeClass('alert-warning');
        aliceLabel.addClass('alert-success');
        return true;
    }

    var wave9 = function(){
        amyLabel.removeClass('alert-info');
        amyLabel.addClass('alert-success');
        claimsLabel.addClass('alert-success');
        claimsLabel.removeClass('alert-danger');
        tb.redOnce(3,7);
        bestMatchAmy.html('Send To Billing');
        tb.speak('Alice\'s style rapidly increases in complexity as we add more factors, while Amy\'s style is universally simple to create.');
        return true;
    }

    var wave10 = function(){ return true; }
    var wave11 = function(){ return true; }
    var wave12 = function(){ return true; }
    var wave13 = function(){ return true; }

    var wave14 = function(){
        resetDisplays();
        return true;
    }

    //END - Claim 1
    //START - Claim 2
    var wave15 = function(){
        tb.greenOnce(1,3);
        return true;
    }
    var wave16 = function(){
        green(claimsDisplay);
        currentClaim.html('2');
        isValid.html('False');
        isApproved.html('False');
        return true;
    }
    var wave17 = function(){
        green(aliceDisplay);
        green(amyDisplay);
        bestMatchAlice.html('Searching...');
        bestMatchAmy.html('Searching...');
        currentStep.html('0');
        sendToBillingScore.html('0');
        manualProcessingScore.html('0');
        returnErrorScore.html('0');
        return true;
    }
    var wave18 = function(){
        tb.greenOnce(2,2,1);
        tb.redOnce(3,2);
        currentStep.html('1');
        return true;
    }
    var wave19 = function(){
        tb.redOnce(2,9,2);
        tb.redOnce(3,3);
        currentStep.html('2');
        return true;
    }
    var wave20 = function(){
        currentStep.html('3');
        tb.greenOnce(2,10,3);
        tb.redOnce(3,4);
        bestMatchAlice.html('Return Error');
        aliceLabel.removeClass('alert-warning');
        aliceLabel.addClass('alert-success');
        return true;
    }
    var wave21 = function(){
        tb.greenOnce(3,5);
        returnErrorScore.html('1');
        return true;
    }
    var wave22 = function(){
        tb.greenOnce(3,6);
        returnErrorScore.html('1.5');
        return true;
    }
    var wave23 = function(){
        tb.greenOnce(3,7);
        bestMatchAmy.html('Return Error');
        manualProcessingScore.html('.5');
        amyLabel.removeClass('alert-info');
        amyLabel.addClass('alert-success');
        claimsLabel.removeClass('alert-danger');
        claimsLabel.addClass('alert-success');
        tb.speak('Amy\'s style does make the CPU work harder.  We originally began using Alice\'s style because we needed to save CPU cycles, as this case has demonstrated well.');
        return true;
    }

    var wave24 = function(){return true;}
    var wave25 = function(){return true;}
    var wave26 = function(){return true;}
    var wave27 = function(){return true;}

    var wave28 = function(){
        resetDisplays();
        return true;
    }

    //END - claim 2
    //START - claim 3
    var wave29 = function(){
        tb.greenOnce(1,4);
        return true;
    }
    var wave30 = function(){
        green(claimsDisplay);
        currentClaim.html('3');
        isValid.html('True');
        isApproved.html('False');
        return true;
    }
    var wave31 = function(){
        green(aliceDisplay);
        green(amyDisplay);
        bestMatchAlice.html('Searching...');
        bestMatchAmy.html('Searching...');
        currentStep.html('0');
        sendToBillingScore.html('0');
        manualProcessingScore.html('0');
        returnErrorScore.html('0');
        return true;
    }
    var wave32 = function(){
        tb.greenOnce(2,2,1);
        tb.greenOnce(3,2);
        sendToBillingScore.html('.5');
        currentStep.html('1');
        return true;
    }
    var wave33 = function(){
        tb.greenOnce(2,3,2);
        tb.greenOnce(3,3);
        currentStep.html('2');
        manualProcessingScore.html('.5');
        return true;
    }
    var wave34 = function(){
        tb.greenOnce(2,4,3);
        tb.redOnce(3,4);
        currentStep.html('3');
        return true;
    }
    var wave35 = function(){
        tb.redOnce(2,7,4);
        tb.redOnce(3,5);
        currentStep.html('4');
        return true;
    }
    var wave36 = function(){
        tb.greenOnce(3,6);
        tb.greenOnce(2,8,5);
        currentStep.html('5');
        bestMatchAlice.html('Manual Processing');
        returnErrorScore.html('.5');
        aliceLabel.removeClass('alert-warning');
        aliceLabel.addClass('alert-success');
        return true;
    }
    var wave37 = function(){
        tb.greenOnce(3,7);
        manualProcessingScore.html('1');
        bestMatchAmy.html('Manual Processing');
        amyLabel.removeClass('alert-info');
        amyLabel.addClass('alert-success');
        claimsLabel.removeClass('alert-danger');
        claimsLabel.addClass('alert-success');
        tb.speak('You can see that either will achieve perfect results when properly configured.  The development savings in Amy\'s technique eclipses the CPU savings in Alice\'s technique.');
        return true;
    }
    var wave38 = function(){return true;}
    var wave39 = function(){return true;}
    var wave40 = function(){return true;}
    var wave41 = function(){return true;}

    var wave42 = function(){
        resetDisplays();
        return true;
    }
    var wave43 = function(){core.start(); return true;}

    //END - claim 3
}