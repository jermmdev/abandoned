function endpointJermmBot(jermmBots, config){
    let pug = require('pug');
    let fs = require('fs');
    let defaultView = false;
    let defaultFile = __dirname+'/defaultGlobal.pug'
    let pugView = false;
    if(config.pugFile) pug.compileFile(config.pugFile);

    this.jermmBotName = config.jermmBotName
    this.apiHeader = ''
    let apiHeader = this.apiHeader
    this.parent = config.parent
    this.metaData = config.metaData
    this.css = config.css
    this.js = config.js
    this.pugFile = config.pugFile

    let parentCounter = 0;
    let topHtml = '';
    let pugFiles = [];
    let pugViews = [];
    let css = '';
    let js = '';
    let metaData = {
        title: ''
    }
    let updateMedataData = function(newData){
        for(let ind in metaData){
            if(ind == 'title'){
                metaData[ind] = newData[ind] + ((metaData[ind].length > 0) ? ' - ' : '') + metaData[ind]
            }
        }
    }
    let initializeViews = function(view){
        if(view.children) {
            for(let ind in view.children){
                initializeViews(view.children[ind]);
            }
        }
        if(view.pugFile){
            pugViews[parentCounter] = pug.compileFile(view.pugFile);
            pugFiles[parentCounter] = view.pugFile;
        } 
        if(view == 'default'){
            pugViews[parentCounter] = pug.compileFile(defaultFile);
            pugFiles[parentCounter] = defaultFile;
        } 
        parentCounter++

        if(view.metaData) updateMedataData(view.metaData);
        css = (view.css ? view.css : '') + css;
        js = (view.js ? view.js : '') + js;
        if(view.parent) initializeViews(view.parent)
    }
    initializeViews(config);

    let renderViews = function(view, req, res, previousOutput){
        let output = renderView(view, req, res, previousOutput);
        parentCounter++;

        if(view.parent) output = renderViews(view.parent, req, res, output);
        return output;
    }
    let renderView = function(view, req, res, input){
        let output = input;
        if(view.render) output = view.render(req, res, output);
        if(view.pugFile) {
            if(config.jermmDebug) output = pug.renderFile(pugFiles[parentCounter], output);
            else output = pugViews[parentCounter](output);
        }
        if(view == 'default'){
            return pugViews[parentCounter]({metaData: metaData, viewBody: topHtml + output, css: css, js: js})
        }
        return output
        }

    this.render = function(req, res, htmlInjection){
        parentCounter = 0;
        topHtml = htmlInjection;
        let response =  renderViews(config, req, res);
        topHtml = '';
        return response;
    }
}
module.exports = endpointJermmBot;