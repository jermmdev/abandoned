function jermmBotUtils(jermmBots, config){
    let jbUtilCore = this;
    this.stringHasData = function(inputString){
        if(!(typeof(inputString)=='string')) return false;
        if(!(inputString.length > 0)) return false;
        return true;
    }
    this.flattenArray = function(array){
        let newArray = [];
        for(let ind in array){
            let obj = array[ind]
            if(typeof(obj) == 'object' && obj.length >= 0){
                let child = jbUtilCore.flattenArray(obj);
                for(let cind in child){
                    newArray.push(child[cind]);
                }
            }else{
                newArray.push(obj);
            }
        }
        return newArray;
    }

    this.padNum = function(num, size){
        let s = num + '';
        while(s.length < size) s = "0" + s;
        return s;
    }

    this.isArray = function(inputObject){
        if(
            typeof(inputObject) == 'object'
            && inputObject.length >= 0
        ){
            return true;
        }
        return false;
    }

    let objectPropertyCount = function(inputObject){
        let numProperties = 0;
        for(let key in inputObject){
            if(inputObject.hasOwnProperty(key)){
                numProperties++;
            }
        }
        return numProperties;
    }

    this.findObjectMatch = function(firstObj, secondObj, matchAny, callback){
        let numProperties = objectPropertyCount(secondObj);
        for(let firstKey in firstObj){
            if(firstObj.hasOwnProperty(firstKey)){
                let matches = 0;
                for(let secondKey in secondObj){
                    if(secondObj.hasOwnProperty(secondKey)){
                        if(firstObj[firstKey] == secondObj[secondKey]){
                            if(matchAny){
                                if(callback) callback(firstObj[firstKey]);
                                return true;
                            }
                            matches++;
                        }
                    }
                }
                if(matches == numProperties){
                    if(callback) callback(firstObj[firstKey]);
                    return true;
                }
            }
        }
        return false;
    }
}
module.exports = jermmBotUtils;