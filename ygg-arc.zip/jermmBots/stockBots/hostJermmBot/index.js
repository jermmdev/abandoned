function hostJermmBot(jermmBots, config){
    let express = require('express')
    let bot = express();
    bot.use(express.json());
    bot.use(express.urlencoded());
    let cookieParser = require('cookie-parser');
    bot.use(cookieParser());

    for(let ind in config.apis){
        config.apis[ind].jermmBotLogic(bot);
    }
    bot.listen(config.port, function(){console.log('Host Listening: ' + config.jermmBotName)});
}

module.exports = hostJermmBot;