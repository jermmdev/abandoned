module.exports = function (jermmBots) {
    this.jermmBotName = 'adminData';
    this.jermmBotStockName = 'dataJermmBot';
    this.databaseFile = __dirname + '/db.json';
    this.repository = function (dataBot) {
        this.getProjects = function(){
            return dataBot.select('/projects');
            }
        this.getModel = function(modelName){
            let modResult = dataBot.select('/models/modules/'+modelName);
            if(modResult) return modResult;
            let funcresult = dataBot.select('/models/functions/'+modelName);
            if(funcresult) return funcresult;
            let dataResult = dataBot.select('/models/data/'+modelName)
            if(dataResult) return dataResult;
        }
    }
}