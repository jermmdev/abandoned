module.exports = function(jermmBots){
    this.jermmBotName = 'gameNightApi';
    this.jermmBotStockName = 'apiJermmBot';
    this.apiHeader = 'jbAdmin';
    this.enableSessions = true;
    this.enableNav = true;
    this.loginLogic = function(req, res){
        let userName = req.body.userName;
        let password = req.body.password;
        if(!userName || !password) return false;

        let user = jermmBots.adminData.first('/users/'+userName);
        if(!user) return false;

        let passwordHash = user.password
        if(password == passwordHash){
            return true;
        } 
        return false;
    }
    let modelEditor = jermmBots.jermmBotCreateStock(require('./endpoints/global/children/modelEditor/endpoint.js'))
    this.paths = {
        '/' : {
            navName: 'Projects'
            , mirrors: ['/projects']
            , endpoint: jermmBots.jermmBotCreateStock(require('./endpoints/global/children/projectManager/endpoint.js'))
            , children: {
                '/projects/edit': {
                    navName: 'Create Project'
                    , endpoint: jermmBots.jermmBotCreateStock(require('./endpoints/global/children/projectEditor/endpoint.js'))
                    }
                }
            }
        , '/bots': {
            navName: 'Bots'
            , endpoint: modelEditor
            , children: {
                '/bots/edit': {
                    navName: 'Create Bot'
                    , endpoint: modelEditor
                }
            }
            }
        }
    }