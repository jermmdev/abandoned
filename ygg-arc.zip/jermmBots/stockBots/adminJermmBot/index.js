let adminJermmBot = function(jermmBots, config){
    jermmBots.jermmBotCreateStock(require('./data/data.js'))
    return jermmBots.jermmBotCreateStock(function(jermmBots){
        this.jermmBotName = 'adminHostJermmBot';
        this.jermmBotStockName = 'hostJermmBot';
        this.port = 4422;
        this.apis = [jermmBots.jermmBotCreateStock(require('./api.js'))];
    });
}
module.exports = adminJermmBot;