let homepage = function(jermmBots){
    this.jermmBotStockName = 'endpointJermmBot'
    this.metaData = {
        title: 'jbAdmin'
    }
    this.jermmDebug = true;
    this.pugFile = __dirname+'/global.pug'
    this.parent = 'default'
    let projects = jermmBots.adminData.repository.getProjects();
    this.render = function(request, response, childData){
        return {childData: childData}
        }
}
module.exports = homepage