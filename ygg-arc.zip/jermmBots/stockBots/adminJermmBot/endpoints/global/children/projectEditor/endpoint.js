let createProject = function(jermmBots){
    let fs = require('fs');
    this.jermmBotStockName = 'endpointJermmBot'
    this.metaData = {
        title: 'Create Project'
        }
    this.css = ''
    this.js = fs.readFileSync(__dirname+'/projectEditor.js');
    this.jermmDebug = true;
    this.parent = new (require(__dirname+'/../../endpoint.js'))(jermmBots);
    this.pugFile = __dirname + '/projectEditor.pug'
    let projects = jermmBots.adminData.repository.getProjects();
    this.render = function(request, response, childData){
        return {projects: projects}
        }
}
module.exports = createProject