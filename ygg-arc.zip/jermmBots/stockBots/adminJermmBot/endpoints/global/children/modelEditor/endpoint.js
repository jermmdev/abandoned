let createProject = function(jermmBots){
    let fs = require('fs');
    this.jermmBotStockName = 'endpointJermmBot'
    this.metaData = {
        title: 'Model Editor'
        }
    this.css = ''
    this.js = fs.readFileSync(__dirname+'/modelEditor.js');
    this.jermmDebug = true;
    this.parent = new (require(__dirname+'/../../endpoint.js'))(jermmBots);
    this.pugFile = __dirname + '/modelEditor.pug'
    let modelName = 'apiJermmBot';
    let model = jermmBots.adminData.repository.getModel(modelName);
    this.render = function(request, response, childData){
        return {model: model, modelName: modelName};
        }
}
module.exports = createProject