/**
 * VM Structure: 
 *  index - name
 *  desc(string) - string description of bot/function/param
 *  inputs(var) -
 *      bot: initialization inputs
 *      function: input variables
 * 
 *      children(group:var) - params: for modeling parameters.  some params are complex objects.
 * 
 *  functions(func) - public functions
 *      code(code) - a function's code for editing
 *  properties(var) - public variable
 *      children(group:var) - params: for modeling parameters.  some params are complex objects.
 *          maybe this is where we enable step in / step out movement
 */