let createProject = function(jermmBots){
    let fs = require('fs');
    this.jermmBotStockName = 'endpointJermmBot'
    this.metaData = {
        title: 'Bot Editor'
        }
    this.css = ''
    this.js = fs.readFileSync(__dirname+'/botEditor.js');
    this.jermmDebug = true;
    this.parent = new (require(__dirname+'/../../endpoint.js'))(jermmBots);
    this.pugFile = __dirname + '/botEditor.pug'
    let projects = jermmBots.adminData.repository.getProjects();
    this.render = function(request, response, childData){
        request.body
        }
}
module.exports = createProject