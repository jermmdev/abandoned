let projectManager = function(jermmBots){
    this.jermmBotName = 'adminJermmBotProjectManager'
    this.jermmBotStockName = 'endpointJermmBot'
    this.metaData = {
        title: 'Project Manager'
        }
    this.css = []
    this.js = []
    this.jermmDebug = true;
    this.parent = new (require(__dirname+'/../../endpoint.js'))(jermmBots);
    this.pugFile = __dirname + '/projectManager.pug'
    let projects = jermmBots.adminData.repository.getProjects();
    this.render = function(request, response, childData){
        return {projects: projects}
        }
}
module.exports = projectManager