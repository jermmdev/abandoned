//Yggdrasil Branch
//Name: main
//Created: 1529074775169
let locals = {}

options = {}
locals["testbuddy"] = require("\\yggdrasil\\tree_modules\\testbuddy")
