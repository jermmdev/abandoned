//Yggdrasil Branch
//Name: main
//Created: 1529074752536
let locals = {}

options = {}
locals["testbuddy"] = require("\\yggdrasil\\tree_modules\\testbuddy")
