//Yggdrasil Branch
//Name: main
//Created: 1529074733042
let locals = {}

options = {}
locals["testbuddy"] = require("\\yggdrasil\\tree_modules\\testbuddy")
