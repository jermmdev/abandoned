//Yggdrasil Branch
//Name: main
//Created: 1527481003384
let locals = {}

options = {}
locals["testbuddy"] = require("\\yggdrasil\\tree_modules\\testbuddy")
