let yggEvents = function(options){
    let repo = options.repo
    let api = options.api
    process.on('message', function(data){
        let origin = data.origin
        let type = data.type
        let specialCommand = data.specialCommand
        if(
            !origin 
            || origin.length < 2 
            || type != forest 
            || !specialCommand
            ) {
                return
            }
        switch(specialCommand){
            case 'reloadData':
                try{
                    repo.reload()
                    return {success: true}
                }catch(error){
                    return repo.err('Unable to Reload Repository', 'events.reloadData')
                }
                break
        }
    })
}
module.exports = yggEvents