let cli = function(options){

    this.deactivate = function(){
        process.stdin.pause()
    }
    let headerText = '{Y}'
    let headerString = "\x1b[34m" + headerText + "\x1b[0m "
    let core = this
    let stream = require('stream')
    let api = options.api
    let commandObj = options.repo
    let apiDriller = function(apiSplit, dataInput, apiCommand){
        let thisCommand = commandObj
        for(let ind in apiSplit){
            apiSplit[ind] = apiSplit[ind].replace(/\"/gm, '')
            if(!thisCommand[apiSplit[ind]]){
                console.log('Invalid API Command\r\nCommand: ' + apiSplit[ind], 'CLI', true)
                return
            }
            thisCommand = thisCommand[apiSplit[ind]]
        }
        if(typeof(thisCommand) != 'function'){
            console.log(thisCommand, 'CLI: Response')
            return
        }
        try{
            console.log(thisCommand(dataInput), 'CLI: Response')
            return
        }catch(error){
            console.log(error + '\r\nCommand: ' + apiCommand, 'CLI', true)
            return
        }
    }
    let oldLog = console.log
    console.log = function(msg, header, err){
        oldLog(msg, header, err)
        process.stdout.write(headerString)
    }

    process.stdin.on('data', (data) => {
        let msg = '' + data
        msg = msg.trim()
        let delimiter = '||II{}II||'
        let delimited = msg.replace(
            /\s(?=([^"]*"[^"]*")*[^"]*$)/gm, 
            function(m, p1, p2, p3){ 
                return delimiter
            })
        let split = delimited.split(delimiter)
        if(split.length == 0) {
            console.log('Empty input provided.','CLI',true)
            return
        }
        if(split.length > 2) {
            console.log('Too many commands provided.', 'CLI', true)
            return
        }
        if(split[0].length == 0) {
            console.log('Empty API Command.', 'CLI', true)
            return
        }
        let apiCommand = split[0]
        delimited = apiCommand.replace(
            /\.(?=([^"]*"[^"]*")*[^"]*$)/gm, 
            function(m, p1, p2, p3){ 
                return delimiter
            })
        let apiSplit = delimited.split(delimiter)
        let dataInput = {}
        if(split.length == 2 && !split[1].length == 0){
            try{
                dataInput = JSON.parse(split[1])
            }catch(error){
                console.log('Invalid JSON input received.')
                return
            }
        }
        apiDriller(apiSplit, dataInput, apiCommand)
    })
    process.on('exit', function(code, signal){
        console.log = oldLog
    })
}
module.exports = cli