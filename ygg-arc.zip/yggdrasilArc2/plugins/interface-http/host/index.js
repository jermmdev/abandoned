let pugHost = function(options){
    let path = require('path')
    let fs = require('fs')
    let express = require('express')
    let pug = require('pug')
    let bubbler = require('jermm-html-bubbler')
    let cookieParser = require('cookie-parser')

    if(!options.viewsDir){
        throw('No view directory provided')
        return
    } 

    let viewsDir = options.viewsDir
    let repo = options.repo || {}
    let listener = options.listener || {}
    let port = options.port || 4422
    let rootPath = options.rootPath || '/'

    let bot = express()
        bot.use(cookieParser())
        bot.use(express.json())
        bot.use(express.urlencoded())

    let notFoundPageExists = fs.existsSync(path.join(viewsDir, '/404.pug'))
    let errorPageExists = fs.existsSync(path.join(viewsDir, '/503.pug'))

    let getListenerFunc = function(address, listenerObj = listener){
        if(!address.charAt(0) == '/') address = '/'+address
        address = address.trim()
        let split = address.split('/')
        split = split.slice(1)
        let newAddress = ''
        if(!listenerObj.hasOwnProperty(split[0])) return false
        if(split.length > 1){
            for(let ind=1; ind<split.length; ind++){
                newAddress += '/' + split[ind]
            }
            return getListenerFunc(newAddress, listenerObj[split[0]])
        }
        return listenerObj[split[0]]
    }

    let generateGetParams = function(req){
        let url = req.url
        if(url.charAt(0) != '/') url = url.substring(1, url.length)
        let getStart = url.indexOf('?') + 1
        let getString = url.substring(getStart, url.length)
        let getSplit = getString.split('&')
        let getParams = {}
        for(let ind in getSplit){
            let paramSplit = getSplit[ind].split('=')
            getParams[decodeURI(paramSplit[0])] = decodeURI(paramSplit[1])
            }
        req.getParams = getParams
        return req
        }
    let getHandler = function(req, res){
        req = generateGetParams(req)
        let response = ''
        let filePath = path.join(viewsDir, path.join(req.path, '/index.pug'))
        let pugInput = {repo: repo, req: req}
        if(fs.existsSync(filePath)){
            try{
                response = pug.renderFile(filePath, pugInput)
            }catch(error){
                if(errorPageExists){
                    response = pug.renderFile(path.join(viewsDir,'/503.pug'), pugInput)
                }else{
                    response = '<html><head><title>503: Error</title></head><body><h1>503: Oops, my bad.</h1></body></html>'
                }
                res.status(503).send(response)
                console.log(error, 'Web Interface Server', true)
                return;
            }
        } else {
            if(notFoundPageExists){
                response = pug.renderFile(path.join(viewsDir,'/404.pug'), pugInput)
            }else{
                response = '<html><head><title>404: Not Found</title></head><body><h1>404: Path not found. (' + req.path + ')</h1></body></html>'
            }
            res.status(404).send(response)
            return
        }
        response = bubbler.bubble(response)
        res.status(200).send(response)
        }
    let postHandler = function(req, res){
        let listenerFunc = getListenerFunc(req.path)
        if(!listenerFunc){
            res.status(404).send('404: Unknown Command (' + req.path + ')')
            return
            }
        try{
            res.status(200).send(listenerFunc(req.body))
            return
        }catch(error){
            console.log('Error in listener function: ' + req.path, 'Web Interface Server')
            if(console.logTrue) console.logTrue(error)
            console.log(error, 'Web Interface Server', true)
            res.status(503).send('503: Oops, my bad.')
            }
        }

    let listenPath = '/*'
    if(rootPath.length && rootPath.length > 1) listenPath = path.join(rootPath, '/*')
    bot.get(listenPath, getHandler)
    bot.post(listenPath, postHandler)
    this.bot = bot.listen(port, function(){
        console.log('Web Interface Listening on Port ' + port, 'Web Interface Server')
    })
}
module.exports = pugHost