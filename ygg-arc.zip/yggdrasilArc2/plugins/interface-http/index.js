let httpServer = function(options){
    let jph = require('./host')
    let port = 80
    let backEnd = {repo: options.repo, api: options.api}
    let viewsDir = backEnd.repo.path.join(backEnd.repo.root, '/yggdrasil_storage/pug/yggdrasil')
    this.bot = new jph({repo: backEnd, listener: backEnd, port: port, viewsDir: viewsDir, localOnly: true})
    hostBot = this.bot.bot
    this.deactivate = function(){
        hostBot.close()
        console.log('Deactivated Web Interface', 'Web Interface')
    }
}
module.exports = httpServer