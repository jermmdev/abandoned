let plugins = function(options){
    let core = this
    let repo = options.repo
    let branches = options.branches
    let forest = options.forest
    let path = require('path')
    core.running = {}
    let pluginPath = path.join(repo.root, '/plugins')
    console.log(repo.yggdrasil.plugins.raw, 'raw')
    for(let pluginName in options.repo.yggdrasil.plugins.raw){
        console.log('Loading Plugin: ' + pluginName, 'plugins.init')
        core.running[pluginName] = new (require(path.join(pluginPath, pluginName)))(options)
    }
}
module.exports = plugins