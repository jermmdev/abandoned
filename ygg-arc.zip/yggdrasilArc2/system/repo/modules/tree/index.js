let tree = function(options){
    let core = this
    let repo = options.repo
    let fs = options.fs
    let path = options.path
    let db = options.db
    let treeModulesPath = path.join(repo.root, '/tree_modules')
    let removeModule = function(options){
        let name = options.name
        if(!name || name.length < 2 || name.indexOf('/') != -1) return repo.err('Invalid Name: ' + name, 'repo.modules.tree.remove')
        let modulePath = path.join(treeModulesPath, name)
        if(!fs.existsSync(modulePath) || !core.files[name]) return repo.err('No Such Module: ' + name)
        try{
            fs.unlinkSync(modulePath)
            delete core.files[name]
            return {success: true}
        }catch(err){
            return repo.err(err, 'repo.modules.tree['+name+'].remove')
        }
    }
    core.add = function(options){
        if(core.files) delete core.files
        core.files = {}
        let name = options.name
        if(name == 'add' || name == 'refresh') return repo.err('"' + name + '" cannot be the name of a tree module.')
        let files = options.files
        if(!name || name.length < 2 || name.indexOf('/') != -1) return repo.err('Invalid Name', 'repo.modules.tree.add')
        if(core.files[name]) return repo.err('Already Exists: ' + name, 'repo.modules.tree.add')
        if(!files || typeof(files) != 'object') return repo.err('Invalid Files', 'repo.modules.tree.add')
        let newPath = path.join(treeModulesPath, name)
        repo.utils.writeFiles(newPath, files)
        core.files[name] = {}
        core.files[name].data = files
        core.files[name].remove = function(){
            removeModule({name: name})
        }
        return {success: true}
    }
    core.refresh = function(){
        if(core.files) delete core.files
        core.files = {}
        let treeModules = fs.readdirSync(treeModulesPath)
        for(let ind in treeModules){
            let moduleName = treeModules[ind]
            let modulePath = path.join(treeModulesPath, moduleName)
            core.files[moduleName] = {}
            core.files[moduleName].data = repo.utils.getFiles(modulePath)
            core.files[moduleName].remove = function(){
                removeModule({name: moduleName})
            }
        }
    }
    core.refresh()
}
module.exports = tree