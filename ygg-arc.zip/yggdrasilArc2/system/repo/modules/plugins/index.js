let plugins = function(options){
    let core = this
    let repo = options.repo
    let fs = options.fs
    let path = options.path
    let db = options.db
    let systemModulesPath = path.join(repo.root, '/plugins')
    let removeModule = function(options){
        let name = options.name
        if(!name || name.length < 2 || name.indexOf('/') != -1) return repo.err('Invalid Name: ' + name, 'repo.modules.plugins.remove')
        let modulePath = path.join(systemModulesPath, name)
        if(!fs.existsSync(modulePath) || !core.files[name]) return repo.err('No Such Module: ' + name, 'repo.modules.plugins.remove')
        try{
            fs.unlinkSync(modulePath)
            delete core.files[name]
            return {success: true}
        }catch(err){
            return repo.err(err, 'repo.modules.plugins['+name+'].remove')
        }
    }
    core.add = function(options){
        let name = options.name
        if(name == 'add' || name == 'refresh') return repo.err('"' + name + '" cannot be the name of a plugin.')
        let files = options.files
        if(!name || name.length < 2 || name.indexOf('/') != -1) return repo.err('Invalid Name', 'repo.modules.plugins.add')
        if(core.files[name]) return repo.err('Already Exists: ' + name, 'repo.modules.plugins.add')
        if(!files || typeof(files) != 'object') return repo.err('Invalid Files', 'repo.modules.plugins.add')
        let newPath = path.join(systemModulesPath, name)
        repo.utils.writeFiles(newPath, files)
        core.files[name] = {}
        core.files[name].files = files
        core.files[name].remove = function(){
            removeModule({name: name})
        }
        return {success: true}
    }
    core.refresh = function(){
        if(core.files) delete core.files
        core.files = {}
        let systemModules = fs.readdirSync(systemModulesPath)
        for(let ind in systemModules){
            let moduleName = systemModules[ind]
            let modulePath = path.join(systemModulesPath, moduleName)
            core.files[moduleName] = {}
            core.files[moduleName].data = repo.utils.getFiles(modulePath)
            core.files[moduleName].remove = function(){
                removeModule({name: moduleName})
            }
        }
    }
    core.refresh()
}
module.exports = plugins