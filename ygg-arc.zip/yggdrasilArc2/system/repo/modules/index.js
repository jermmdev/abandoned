let modules = function(options){
    let core = this
    let repo = options.repo
    let fs = options.fs
    let path = options.path
    let db = options.db

    core.npm = require('npm')

    let treeAddon = require(path.join(__dirname,'/tree'))
    let pluginAddon = require(path.join(__dirname,'/plugins'))
    core.refresh = function(){
        if(core.tree) delete core.tree
        if(core.system) delete core.system
        core.tree = new treeAddon(options)
        core.plugins = new pluginAddon(options)
    }
    core.refresh()
}
module.exports = modules