let system = function(options){
    let core = this
    let repo = options.repo
    let fs = options.fs
    let path = options.path
    let db = options.db
    let systemPath = path.join(repo.root, '/system')
    core.refresh = function(){
        if(core.files) delete core.files
        core.files = repo.utils.getFiles(systemPath)
    }
    core.refresh()
    core.add = function(options){
        let path = options.path
        let files = options.files
        if(!path || path.length < 2) return repo.err('Invalid Path: ' + path, 'repo.system.add')
        let realTarget = path.join(systemPath, path)
        if(!files || typeof(files) != 'object') return repo.err('Invalid Files', 'repo.system.add')
        return repo.utils.writeFiles(realTarget, files)
    }
    core.remove = function(options){
        let path = options.path
        if(!path || path.length < 2) return repo.err('Invalid Path: ' + path, 'repo.system.remove')
        let realTarget = path.join(systemPath, path)
        if(!fs.existsSync(realTarget)) return repo.err('No Such System Path: ' + path, 'repo.system.remove')
        return repo.utils.nukePath(realTarget)
    }
}
module.exports = system