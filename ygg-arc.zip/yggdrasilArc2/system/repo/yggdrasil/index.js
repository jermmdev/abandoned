let yggdrasil = function(options){
    let core = this
    let db = options.db
    let fs = options.fs
    let path = options.path
    let repo = options.repo
    let yggdrasilExport = {}
    let yggdrasilPath = path.join(repo.root, '/system/repo/yggdrasil')
    let forestAddon = require(__dirname+'/forest')
    let settingsAddon = require(__dirname+'/settings')
    let mainAddon = require(__dirname+'/main')
    let pluginAddon = require(__dirname+'/plugins')

    core.refresh = function(){
        if(core.forest) delete core.forest
        if(core.settings) delete core.settings
        if(core.main) delete core.main
        core.forest = new forestAddon(options)
        core.settings = new settingsAddon(options)
        core.main = new mainAddon(options)
        core.plugins = new pluginAddon(options)
    }
    core.refresh()
}
module.exports = yggdrasil