let forest = function(options){
    let core = this
    let repo = options.repo
    let db = options.db
    let fs = options.fs
    let path = options.path
    core.trees = {}
    core.refresh = function(){
        if(core.trees) delete core.trees
        core.trees = {}
        let forestObj = db.getData('/forest')
        core.raw = JSON.parse(JSON.stringify(forestObj))
        for(let originName in forestObj){
            core.trees[originName] = forestObj[originName]
            core.trees[originName].remove = function(){
                db.delete('/forest/'+originName)
            }
            core.trees[originName].editPath = function(newPath){
                db.push('/forest/'+originName+'/path', newPath)
            }
            core.trees[originName].editKey = function(newKey){
                db.push('/forest/'+originName+'/key', newKey)
            }
            core.trees[originName].editOrigin = function(newOrigin){
                if(
                    !newOrigin || newOrigin.length < 2 || newOrigin.indexOf('/') != -1
                    || newOrigin == 'remove' || newOrigin == 'editPath' 
                    || newOrigin == 'editKey' || newOrigin == 'editOrigin'
                    || newOrigin == 'addTree'
                    || !core.trees[originName] || core.trees[newOrigin]
                ){
                    return repo.err('Invalid Origin: ' + newOrigin, 'repo.yggdrasil.forest.editOrigin')
                }
                let oldData = db.getData('/forest/'+originName)
                db.delete('/forest/'+originName)
                db.push('/forest/'+newOrigin, oldData)
                core.trees[newOrigin] = core.trees[originName]
                delete core.trees[originName]
            }
        }
    }
    core.refresh()
    core.add = function(options){
        let origin = options.origin
        let path = options.path
        let key = options.key
        if(!origin || !path || !key 
            || typeof(origin) != 'string' || typeof(path) != 'string' || typeof(key) != 'string'
            || origin.length < 2 || path.length < 2 || key.length < 2
            || core.trees[origin]
        ){
            return repo.err('Invalid Forest Inputs', 'repo.yggdrasil.forest.add')
        }
        let treeObj = {
            path: path
            , key: key
        }
        db.push('/forest/'+origin, treeObj)
        core.refresh()
        return {success: true}
    }
}
module.exports = forest