let plugins = function(options){
    let core = this
    let repo = options.repo
    let db = options.db
    let fs = options.fs
    let path = options.path
    core.refresh = function(){
        let pluginData = db.getData('/plugins')
        core.raw = JSON.parse(JSON.stringify(pluginData))
        core.avail = {}
        for(let pluginName in pluginData){
            core.avail[pluginName] = pluginData
            core.avail[pluginName].remove = function(){
                db.delete('/plugins/'+pluginName)
                delete core.avail[pluginName]
            }
        }
        core.add = function(options){
            let name = options.name
            core.avail[name] = true
            core.avail[name].remove = function(){
                db.delete('/plugins/'+name)
                delete core.avail[name]
            }
            db.push('/plugins/'+name, true)
        }
    }
    core.refresh()
}
module.exports = plugins