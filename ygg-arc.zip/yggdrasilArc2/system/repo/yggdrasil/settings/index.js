let settings = function(options){
    let core = this
    let repo = options.repo
    let db = options.db
    let fs = options.fs
    let path = options.path
    core.refresh = function(){
        let settingsObj = db.getData('/settings')
        core.raw = JSON.parse(JSON.stringify(settingsObj))
        core.name = settingsObj.name
        core.key = settingsObj.key
        core.root = settingsObj.root
        core.port = settingsObj.port
        core.debug = settingsObj.debug
        settingsObj.enableDebug = function(){
            db.push('/settings/debug', true)
            core.debug = true
        }
        settingsObj.disableDebug = function(){
            db.push('/settings/debug', false)
            core.debug = false
        }
        settingsObj.editName = function(newName){
            db.push('/settings/name', newName)
            core.name = newName
        }
        settingsObj.editKey = function(newKey){
            db.push('/settings/key', newKey)
            core.key = newKey
        }
        settingsObj.editRoot = function(newRoot){
            db.push('/settings/root', newRoot)
            core.root = newRoot
        }
        settingsObj.editPort = function(newPort){
            db.push('/settings/port', newPort)
            core.port = newPort
        }
    }
    core.refresh()
}
module.exports = settings