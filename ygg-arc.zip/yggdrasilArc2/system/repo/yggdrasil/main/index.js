let main = function(options){
    let core = this
    let db = options.db
    let fs = options.fs
    let repo = options.repo
    let path = options.path

    core.refresh = function(){
        if(core.leaves) delete core.leaves
        core.leaves = {}
        let mainObj = db.getData('/main')
        core.raw = JSON.parse(JSON.stringify(mainObj))
        for(let leafName in mainObj){
            core.leaves[leafName] = mainObj[leafName]
            core.leaves[leafName].remove = function(){
                db.delete('/main/'+leafName)
                delete core.leaves[leafName]
            }
            core.leaves[leafName].editName = function(options){
                let newName = options.name
                let oldData = db.getData('/main/'+leafName)
                db.delete('/main/'+leafName)
                db.push('/main/'+newName, oldData)
                core.refresh()
            }
            core.leaves[leafName].editType = function(options){
                let newType = options.type
                db.push('/main/'+leafName+'/type/', newType)
                core.leaves[leafName].type = newType
            }
            core.leaves[leafName].clearInputs = function(){
                db.push('/main/'+leafName+'/inputs', {})
                core.leaves[leafName].inputs = {}
            }
            core.leaves[leafName].addLeaf = function(options){
                let name = options.name
                let val = options.val
                db.push('/main/'+leafName+'/leaves/'+name, val)
                core.refresh()
            }
            for(let inputName in core.leaves[leafName].inputs){
                core.leaves[branchName].inputs[inputName].remove = function(){
                    db.delete('/main/'+branchName+'/inputName/'+leafName)
                    delete core.branches[branchName].leaves[leafName]
                }
                core.branches[branchName].leaves[leafName].editName = function(options){
                    let newName = options.name
                    let oldLeaf = db.getData('/main/'+branchName+'/leaves/'+leafName)
                    db.delete('/main/'+branchName+'/leaves/'+leafName)
                    db.push('/main/'+branchName+'/leaves/'+newName, oldLeaf)
                    core.refresh()
                }
                core.branches[branchName].leaves[leafName].editValue = function(options){
                    let newVal = options.val
                    db.push('/tree/'+branchName+'/leaves/'+leafName, newVal)
                    core.branches[branchName].leaves[leafName] = newVal
                }
            }
        }
    }
    core.refresh()
}
module.exports = main