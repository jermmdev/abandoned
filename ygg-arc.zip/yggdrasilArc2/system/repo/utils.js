let utils = function(options){
    let core = this
    let repo = options.repo
    let fs = options.fs
    let path = options.path
    let db = options.db
    core.writeFiles = function(path, files){
        if(!fs.existsSync(path)) {
            try{
                fs.mkDirSync(path)
            }catch(error){
                repo.err('Error Creating Initial Dir', 'repo.utils.writeFiles')
            }
        }
        if(typeof(files)!='object') return repo.err('Invalid files Object\r\nPath: ' + path, 'repo.utils.writeFiles')
        for(let ind in files){
            let fileObj = files[ind]
            let newPath = path.join(path, ind)
            if(typeof(fileObj) == 'string'){
                fs.writeFileSync(newPath, fileObj)
            }else{
                if(!fs.existsSync(newPath)) fs.mkDirSync(newPath)
                core.writeFiles(newPath, fileObj)
            }
        }
        return {success: true}
    }
    core.getFiles = function(filePath){
        if(!fs.existsSync(filePath)) return repo.err('Invalid Path: ' + path, 'repo.utils.getFiles')
        if(fs.lstatSync(filePath).isDirectory()){
            let filesObj = {}
            let fileList = fs.readdirSync(filePath)
            for(let ind in fileList){
                let newPath = path.join(filePath, fileList[ind])
                filesObj[fileList[ind]] = core.getFiles(newPath)
            }
            return filesObj
        } 
        else {
            let fileContents = fs.readFileSync(filePath, 'utf-8')
            try{
                fileContents = JSON.parse(fileContents)
            }catch(err){
                fileContents = fileContents
            }
            return fileContents
        }
    }
    core.nukePath = function(filePath){
        if(fs.existsSync(filePath)) {
            let filesAndDirs = fs.readdirSync(filePath)
            for(let ind in filesAndDirs){
                let fileOrDirName = filesAndDirs[ind]
                var fileOrDirNamePath = filePath + "/" + fileOrDirName
                if (fs.lstatSync(fileOrDirNamePath).isDirectory()) { 
                    nukeSync(fileOrDirNamePath)
                } else { 
                    fs.unlinkSync(fileOrDirNamePath)
                }
            }
            if(fs.lstatSync(filePath).isDirectory()) fs.rmdirSync(filePath)
            else fs.unlinkSync(filePath)
            return true
        }
        return false
    }
}
module.exports = utils