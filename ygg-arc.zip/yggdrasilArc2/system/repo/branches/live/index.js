let live = function(options){
    let core = this
    let repo = options.repo
    let db = options.db
    let path = options.path
    let fs = options.fs
    let branches_path = path.join(repo.root, '/branches')
    let live_path = path.join(branches_path, '/live')
    let dead_path = path.join(branches_path, '/dead')
    core.refresh = function(){
        if(core.files) delete core.files
        core.files = {}
        if(!fs.existsSync(live_path)) fs.mkdirSync(live_path)
        let live = fs.readdirSync(live_path)
        for(let ind in live){
            let branchFile = live[ind]
            let branchFilePath = path.join(live_path, branchFile)
            core.files[branchFile] = {}
            core.files[branchFile].code = fs.readFileSync(branchFilePath, 'utf-8')
            core.files[branchFile].archive = function(){
                try{
                    fs.unlinkSync(branchFilePath)
                }catch(err){
                    repo.err(err, 'repo.branches.live')
                }
                try{
                    let outputPath = path.join(dead_path, Date.now() + ' ' + branchFile)
                    fs.writeFileSync(outputPath, core.files[branchFile].code)
                    return {success: true}
                }catch(err){
                    return repo.err(err, 'repo.branches.live[' + branchFile + '].archive')
                }
            } 
        }
    }
    core.refresh()
}
module.exports = live