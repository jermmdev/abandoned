let branches = function(options){
    let core = this
    let repo = options.repo
    let fs = options.fs
    let db = options.db
    let path = options.path

    let branches_path = path.join(repo.root, '/branches')
    let live_path = path.join(branches_path, '/live')
    let dead_path = path.join(branches_path, '/dead')
    let liveAddon = require(__dirname+'/live')
    let deadAddon = require(__dirname+'/dead')

    core.refresh = function(){
        if(core.live) delete core.live
        if(core.dead) delete core.dead
        core.live = new liveAddon(options)
        core.dead = new deadAddon(options)
    }
    core.refresh()
    core.clearDead = function(){
        if(fs.existsSync(dead_path)){
            try{
                repo.utils.nukePath(dead_path)
            }catch(error){
                repo.err(error, 'repo.branches.dead.removeAll')
            }
        }
        console.log('Dead Branches Removed', 'repo.branches.dead.removeAll')
        try{
            fs.mkdirSync(dead_path)
            core.dead.refresh()
            return {success: true}
        }catch(error){
            return repo.err(error, 'repo.branches.clearDead')
        }
    }
    core.clearLive = function(){
        if(fs.existsSync(live_path)){
            try{
                repo.utils.nukePath(live_path)
            }catch(error){
                repo.err(error, 'repo.branches.clearLive')
            }
        }
        console.log('Live Branches Removed', 'repo.branches.clearLive')
        try{
            fs.mkdirSync(live_path)
            core.dead.refresh()
            return {success: true}
        }catch(error){
            return repo.err(error, 'repo.branches.clearLive')
        }
    }
}
module.exports = branches