let dead = function(options){
    let core = this
    let repo = options.repo
    let db = options.db
    let path = options.path
    let fs = options.fs
    let branches_path = path.join(repo.root, '/branches')
    let dead_path = path.join(branches_path, '/dead')
    let branch_files = []
    core.files = {}
    core.refresh = function(){
        if(core.files) delete core.files
        core.files = {}
        if(!fs.existsSync(dead_path)) fs.mkdirSync(dead_path)
        let dead = fs.readdirSync(dead_path)
        for(let ind in dead){
            let branchFile = dead[ind]
            let branchFilePath = path.join(dead_path, branchFile)
            core.files[branchFile] = {}
            core.files[branchFile].code = fs.readFileSync(branchFilePath, 'utf-8')
            core.files[branchFile].remove = function(){
                try{
                    fs.unlinkSync(branchFilePath)
                    console.log('Dead Branch Clipped: ' + branchFile)
                    return {success: true}
                }catch(err){
                    return repo.err(err, 'repo.branches.dead[' + branchFile + '].remove')
                }
            } 
        }
    }
    core.refresh()
}
module.exports = dead