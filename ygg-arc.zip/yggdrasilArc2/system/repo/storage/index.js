let storage = function(options){
    let core = this
    let repo = options.repo
    let fs = options.fs
    let path = options.path
    let db = options.db
    let storagePath = path.join(repo.root, '/storage')
    core.refresh = function(){
        if(core.files) delete core.files
        core.files = repo.utils.getFiles(storagePath)
    }
    core.refresh()
    core.add = function(options){
        let path = options.path
        let files = options.files
        if(!path || path.length < 2) return repo.err('Invalid Path: ' + path, 'repo.storage.add')
        let realTarget = path.join(storagePath, path)
        if(!files || typeof(files) != 'object') return repo.err('Invalid Files', 'repo.storage.add')
        let fileWriteResponse = repo.utils.writeFiles(realTarget, files)
        if(!fileWriteResponse.error){
            core.refresh()
            return {success: true}
        }else{
            return fileWriteResponse
        }
    }
    core.remove = function(options){
        let path = options.path
        if(!path || path.length < 2) return repo.err('Invalid Path: ' + path, 'repo.storage.remove')
        let realTarget = path.join(storagePath, path)
        if(!fs.existsSync(realTarget)) return repo.err('No Such Storage Path: ' + path, 'repo.storage.remove')
        return repo.utils.nukePath(realTarget)
    }
}
module.exports = storage