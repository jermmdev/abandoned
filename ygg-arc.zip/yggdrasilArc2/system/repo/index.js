let repo = function(){
    let core = this
    let fs = require('fs')
    let path = require('path')
    let njdb = require('node-json-db')
    let dbLoc = path.join(__dirname, '../../yggdrasil.json')
    let db = new njdb(dbLoc, true, true)
    core.root = db.getData('/settings/root')
    core.err = function(msg, source='repo'){
        console.log(msg, source, true)
        return {error: msg, source: source}
    }

    let addonOptions = {repo: core, fs: fs, db: db, path: path}
    core.utils = new (require(path.join(core.root, '/system/repo/utils.js')))(addonOptions)
    
    let branchesAddon = require(__dirname+'/branches')
    let modulesAddon = require(__dirname+'/modules')
    let storageAddon = require(__dirname+'/storage')
    let systemAddon = require(__dirname+'/system')
    let yggdrasilAddon = require(__dirname+'/yggdrasil')

    core.refresh = function(){
        if(core.branches) delete core.branches
        if(core.modules) delete core.modules
        if(core.storage) delete core.storage
        if(core.system) delete core.system
        if(core.yggdrasil) delete core.yggdrasil
        core.branches = new branchesAddon(addonOptions)
        core.modules = new modulesAddon(addonOptions)
        core.storage = new storageAddon(addonOptions)
        core.system = new systemAddon(addonOptions)
        core.yggdrasil = new yggdrasilAddon(addonOptions)
    }
    core.refresh()
}
module.exports = new repo()