let injector = function(locals){
    let localFunctions = {}
    for(let ind in locals){
        let local = locals[ind]
        localFunctions[ind] = {}
        for(let lInd in local){
            if(typeof(local[lInd]) == 'function'){
                localFunctions[ind][lInd] = local[lInd]
            }
        }
    }
    process.on('message', function(options){
        if(
            options.acorn
            && options.branchId && options.local && options.function
            && localFunctions[options.local]
            && localFunctions[options.local][options.function] 
            && local == options.local
        ){
            process.send({original: options, response: inputFunctions[options.function](options.input)})
        }else{
            process.send({error: 'Invalid message received.', msg: options})
        }
    })
}
module.exports = injector