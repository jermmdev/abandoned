let compiler = function(options){
    let core = this
    let codeString = require(__dirname+'/code-string.js')
    let repo = options.repo
    let fs = options.fs
    let path = options.path
    let root = repo.root
    let livePath = path.join(root, '/branches/live')

    core.compile = function(options){
        let name = options.name
        let branch = options.branch
        let code = new codeString()
        code.addCode('//Yggdrasil Branch')
        code.addCode('//Name: '+name)
        code.addCode('//Created: '+Date.now())
        code.addCode('let locals = {}')

        for(let leafName in branch){
            code.addCode()
            code.addCode('options = {}')

            let leaf = branch[leafName]
            let type = leaf.type
            let inputs = leaf.inputs
            let injectorPath = path.join(root, '/system/branches/compiler/injector.js')

            let hasInputs = false
            for(let inputName in inputs){
                hasInputs = true
                let input = inputs[inputName]
                let inputSplit = input.split('/')
                if(inputSplit[0] != 'locals' && inputSplit[0] != 'basic') {
                    return repo.err('Invalid Local Type', 'compiler.compile')
                }
                if(inputSplit[0] == 'local') code.addCode('options["'+inputName+'"] = locals["' + input + '"]')
                if(inputSplit[0] == 'string') code.addCode('options["'+inputName+'"] = "' + input + '"')
            }

            let typeSplit = type.split('/')
            if(typeSplit[1] != 'tree_modules' && typeSplit[1] != 'node_modules'){
                return repo.err('Invalid Module Type: ' + typeSplit[1], 'compiler.compile')
            }
            let modulePath = path.join(path.join(root, type))
            if(!fs.existsSync(modulePath)){
                return repo.err('No Such Module: ' + modulePath)
            }
            modulePath = modulePath.replace(/\\/gm, '\\\\')
            if(!hasInputs){
                code.addCode('locals["'+leafName+'"] = require("'+modulePath+'")')
            }else{
                code.addCode('locals["'+leafName+'"] = new (require("'+modulePath+'"))(options)')
            }
        }
        code.addCode('let injector = require(\'' + injectorPath + '\')')
        code.addCode('injector(locals)')
        let newFilePath = path.join(livePath, Date.now() + ' ' + name+'.js')
        fs.writeFileSync(newFilePath, code.code)
        return newFilePath
    }
}
module.exports = compiler