let codeString = function(){
    let core = this
    core.code = ''
    let indentCount = 0
    core.addCode = function(newCode = ''){
        let tabString = ''
        for(let i=0; i<indentCount; i++){
            tabString += '\t'
        }
        core.code += tabString + newCode.replace(/\r?\n|\r/g, '\r\n' + tabString) + '\r\n'
    }
    core.indent = function(){
        indentCount++
    }
    core.dedent = function(){
        indentCount--
    }
}
module.exports = codeString