let branches = function(options){
    let core = this
    let repo = options.repo
    let events = require('events')
    core.emitter = new events.EventEmitter()
    let fs = require('fs')
    let path = require('path')
    let {fork} = require('child_process')
    let compiler = new (require(__dirname+'/compiler'))({path: path, repo: repo, fs: fs})
    core.running = {}

    core.grow = function(options){
        let name = options.name
        let branchData = options.branch
        let filePath = compiler.compile({name: name, branch: branchData})
        core.running[name] = fork(filePath, {silent: true})
        core.running[name].name = name
        core.running[name].filePath = filePath
        core.running[name].on('message', function(data){
            core.emitter.emit('branchMessage', {branchOrigin: name, data: data})
        })
        core.running[name].stdout.on('data', function(data){
            console.log(`${data}`, 'branches.'+name)
        })
        core.running[name].stderr.on('data', function(data){
            console.log(`${data}`, 'branches.'+name, 1)
        })
        process.stdin.pipe(core.running[name].stdin)
    }

    core.shutdown = function(){
        console.log('Shutting Down '+repo.settings.name, 'branches.shutdown')
        for(let branchName in core.running){
            core.running[branchName].kill('SIGKILL')
        }
        process.exit()
    }
    core.restart = function(){
        console.log('Restarting '+repo.settings.name, 'branches.restart')
        for(let branchName in core.running){
            core.running[branchName].kill('SIGKILL')
        }
        process.exit(4422)
    }
    process.on('exit', function(code, signal){
        repo.branches.live.refresh()
        for(let branchName in repo.branches.live.files){
            repo.branches.live.files[branchName].archive()
        }
    })
}
module.exports = branches