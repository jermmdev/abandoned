let river = function(options){
    let received = Date.now()
    let core = this
    let wolves = options.wolves
    let repo = options.inputs.repo
    let events = require('events')
    core.emitter = new events.EventEmitter()
    let branches = options.inputs.branches
    let express = require('express')
    let riverServer = new express()
    let request = require('request')
    let treeData = repo.yggdrasil.forest.trees
    core.trees = {} 
    core.growTree = function(options){
        let scent = options.scent
        let treeName = options.treeName
        if(core.trees[treeName]) return repo.err('Tree already exists: ' + treeName, 'forest.river.growTree')
        let ip = options.ip
        core.trees[treeName] = {
            scent: scent
            , send: function(options){
                if(!core.trees[req.body.treeOrigin].scent) return repo.err('Cannot send message before login is complete: '+req.body.treeOrigin, 'forest.river.trees["'+req.body.treeOrigin+'"].send')
                let reqUrl = repo.forest.trees[req.body.treeOrigin].path
                request.post({
                        url: reqUrl,
                        headers: {
                          "Content-Type": "application/json"
                        },
                        json: options
                    }, function(error, response, body){
                        if(error) return repo.err('Failed to Send Request\r\nUrl: ' + reqUrl +'\r\nTree: ' + req.body.treeOrigin, 'forest.river.trees["'+req.body.treeOrigin+'"].send')
                        else return {success: true}
                    })
                return null
            }, ip: ip
        }
    }
    let postHandler = function(req, res){
        if(req.body.smellMe){
            if(core.trees[req.body.treeOrigin]) return null
            let loginResult = wolves.login({ip: req.connection.remoteAddress, treeOrigin: req.body.treeOrigin, key: req.body.smellMe})
            if(loginResult.error) return null
            core.growTree({ip: req.connection.remoteAddress, scent: loginResult.scent, treeName: req.body.treeOrigin})
            res.status(200).send(loginResult)
            return true
        }
        if(wolves.validate({ip: req.connection.remoteAddress, treeOrigin: req.body.treeOrigin, scent: req.body.scent})){
            //Handle branch logic here and return response.
            ratatoskr.sendForestResponse({reponse: res, data: req.body})
            //emitter.emit('riverUpstream', {treeOrigin: req.body.treeOrigin, ip: req.connection.remoteAddress, received: received, data: req.body})
            //res.status(200).send({success: true})
            return true
        }else{
            return null
        }
    }
    riverServer.post('/*', postHandler)
    riverServer.get('/*', function(req, res){return null})
    riverServer.listen(repo.yggdrasil.settings.port, () => console.log('River is Flowing'))

    //Attempt to connect to forest.
    for(let treeName in treeData){
        console.log('tree: ' + treeName, 'tester')
        if(!core.trees[treeName]) {
            console.log(treeData[treeName], 'lets check guts')
            request.post({
                url: treeData[treeName].path,
                headers: {
                  "Content-Type": "application/json"
                },
                json: {smellMe: repo.yggdrasil.settings.key, treeOrigin: repo.yggdrasil.settings.name}
            }, function(error, response, body){
                if(error) return repo.err('Failed to Send Request\r\nUrl: ' + treeData[treeName].path +'\r\nTree: ' + treeName, 'forest.river.initialize')
                wolves.scents.friendly[body.scent] = {treeOrigin: treeName, ip: response.connection.remoteAddress, created: Date.now()}
                core.growTree({ip: response.connection.remoteAddress, scent: body.scent, treeName: treeName})
            })
        }else{
            continue
        }
    }
}
module.exports = river