let wolves = function(options){
    let core = this
    let bcrypt = require('bcrypt')
    let salt = bcrypt.genSaltSync(10)
    let forest = options.forestData
    let repo = options.inputs.repo
    core.scents = {friendly: {}, foul: {sessions: {}, logins: {}}} //sessions, invalid transmissions
    let invalidSessionLimit = 30
    let invalidLoginLimit = 30

    let badLogin = function(options){
        let ip = options.ip
        let treeOrigin = options.treeOrigin
        let key = options.key
        if(!core.scents.foul.logins[ip]) core.scents.foul.logins[ip] = []
        core.scents.foul.logins[ip].push({created: Date.now(), treeOrigin: treeOrigin, badKey: key})
        return repo.err('Bad Login Attempt:\r\nOrigin: ' + treeOrigin + '\r\nIp: ' + ip, 'forest.wolves.badLogin')
    }
    let goodLogin = function(options){
        let ip = options.ip
        let treeOrigin = options.treeOrigin
        let key = options.key
        let sessionId = bcrypt.hashSync(key+'SessionId', salt)
        core.scents.friendly[sessionId] = {treeOrigin: treeOrigin, ip: ip, created: Date.now()}
        return {scent: sessionId}
    }
    core.login = function(options){
        let ip = options.ip
        if(scents.foul.logins[ip] && scents.foul.logins[ip].length > invalidLoginLimit) return badLogin(options)
        let treeOrigin = options.treeOrigin
        if(!forest[treeOrigin]) return badLogin(options)
        let key = options.key
        let keyHole = forest[treeOrigin].keyHole
        if(bcrypt.compareSync(key, keyHole)){
            return goodLogin(options)
        }else{
            return badLogin(options)
        }
    }
    core.logout = function(options){
        let scent = options.scent
    }
    core.validate = function(options){j
        let ip = options.ip
        if(scents.foul.sessions[ip] && scents.foul.sessions[ip].length > invalidSessionLimit) return false
        let treeOrigin = options.treeOrigin
        let scent = options.scent
        if(!scents.friendly[scent] || !scents.friendly[scent].treeOrigin == treeOrigin){
            if(!scents.foul.sessions[ip]) scents.foul.sessions[ip] = []
            scents.foul.sessions[ip].push({treeOrigin: treeOrigin, created: Date.now(), scent: scent})
            repo.err('Scent Rejected: ' + scent + '\r\nOrigin: ' + treeOrigin + '\r\nIp: ' + ip, 'forest.wolves.validate')
            return false
        }else{
            return true
        }
    }
}
module.exports = wolves