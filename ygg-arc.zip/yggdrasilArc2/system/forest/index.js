let forest = function(options){
    let repo = options.repo
    let api = options.api
    let core = this
    
    let path = require('path')
    core.forestData = repo.yggdrasil.forest.raw
    core.inputs = options
    core.wolves = new (require(path.join(__dirname, '/wolves')))(core)
    core.river = new (require(path.join(__dirname, '/river')))(core)
}
module.exports = forest