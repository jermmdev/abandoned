let logger = function(){
    
}
//string limits
let charLimit = 500
let lineLimit = 10

//object limits
let depthLimit = 3
let breadthLimit = 10

let oldLog = console.log


log = function(msg = '', header, error = false){
    let wasTrimmed = false
    let origMsg = msg
    process.stdout.clearLine()
    process.stdout.cursorTo(0)
    let headerColor = '\x1b[36m'
    if(error) headerColor = '\x1b[31m'
    let green = '\x1b[32m'
    let reset = '\x1b[0m'
    let cyanbg = '\x1b[46m'
    let functionHighlight = cyanbg
    let yggdrasilTag = green + '{Yggdrasil}'
    let closingTag = '}'+reset
    if(header){
        yggdrasilTag += headerColor + ' {' + header + '} {' + reset
        closingTag = headerColor + closingTag
    }else{
        yggdrasilTag += '{' + reset
        closingTag = green + closingTag
    }
    let functionCleanup = function(functionString){
        let newString = ''
        let codeReadCount = 40
        newString = functionString.replace(/(\\\r\\\n)+|\s+/gm,' ')
        let codeBegin = newString.indexOf('{')
        if(codeBegin == -1) return newString
        let functionBit = newString.substring(0,codeBegin).replace(' ','')
        let codeBit = ''
        if(newString.length > (codeBegin+codeReadCount)) codeBit = newString.substring(codeBegin, codeReadCount) + '... }'
        else codeBit = newString.substring(codeBegin,(newString.length - codeBegin)) + ' ...}'
        return functionBit + codeBit
    }
    let trimIfString = function(msg){
        if(!msg) return false
        let origMsg = msg
        if(msg.toString){
            msg = msg.toString()
            msg = msg.trim()
            if(msg.length > charLimit){
                msg = msg.substring(0, charLimit) + ' ...{trim}'
                wasTrimmed = true
            }
            msg = msg.trim().replace(/(\\\r\\\n)+|\s+/gm,' ')
            if(!wasTrimmed) return origMsg
            else return msg
        }
        return false
    }
    msg = trimIfString(msg)
    if(typeof(origMsg)=='function') msg = functionCleanup(msg)
    let objectTrimmer = function(object, depth = 0){
        if(depth > depthLimit) return '{trim}'
        let newObj = {}
        let breadth = 0
        for(let ind in object){
            if(object.hasOwnProperty(ind)){
                breadth++
                if(typeof(object[ind])=='object'){
                    newObj[ind] = objectTrimmer(object[ind], depth + 1)
                }else{
                    if(breadth > breadthLimit){
                        newObj[ind] = '{trim}'
                        return newObj
                    }
                    newObj[ind] = trimIfString(object[ind])
                    if(typeof(object[ind])=='function'){
                        if(newObj[ind].toString) newObj[ind] = newObj[ind].toString()
                        newObj[ind] = functionCleanup(newObj[ind])
                    } 
                }
            }
        }
        return newObj
    }
    oldLog(yggdrasilTag)
    console.group()
    if(typeof(msg)=='object'){
        msg = objectTrimmer(msg)
    }
    oldLog(msg)
    console.groupEnd()
    oldLog(closingTag)
}
//hook stderr
function hookErr() {
    var old_write = process.stderr.write

    process.stderr.write = (function(write) {
        return function(string, encoding, fd) {
            log(string, 'ERR', true)
        }
    })(process.stderr.write)

    return function() {
        process.stderr.write = old_write
    }
}
hookErr()
console.logTrue = console.log
console.log = log
//end: hook stderr
module.exports = log