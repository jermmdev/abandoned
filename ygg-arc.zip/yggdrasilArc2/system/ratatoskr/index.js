let ratatoskr = function(inputs){
    let core = this
    let repo = inputs.repo
    let uuid = require('uuid');
    let branchIncoming = function(options){
        //should only be responses...
    }
    inputs.branches.emitter.on('branchMessage', branchIncoming)
    core.send = function(options){
        let response = options.response
        let input = {

        }
    }
}
module.exports = ratatoskr