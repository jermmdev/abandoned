let datasetMiner = function(inputs){
    let core = this
    let njdb = require('node-json-db')
    let db = new njdb('db.json', true, true)
    let searchResults = db.getData('/searchResults')
    let cropped = {}
    for(let ind in searchResults){
        cropped[searchResults[ind].title] = {url: searchResults[ind].url, desc: searchResults[ind].selftext}
    }
    db.push('/croppedResults', cropped)
    console.log('fin')
    //----------------
    // let rb = require('./../reddit-bot')
    // let searchResults = rb.search({
    //     query: 'flair:dataset'
    //     , time: 'all'
    //     , subreddit: 'datasets'
    //     , sort: 'new'
    // }).fetchAll()
    // console.log('sent for results')
    // searchResults.then(function(results){
    //     console.log('got results: ' + results.length)
    //     db.push('/searchResults', results)
    // })
}
//module.exports = webMiner
let tester = datasetMiner()