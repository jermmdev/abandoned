//loveYou
let beepcount = 0
let beeper = function(){
    process.on('message', function(data){
        console.log('testbuddy got a message!')
        console.log(data)
    })
    let core = this
    core.beep = function(){
        beepcount++
        process.send({branchTarget: {global: true}, data: 'Beep Message: ' + beepcount})
        console.log('Beep: ' + beepcount)
        setTimeout(core.beep, 3000)
    }
    core.beep()
}
module.exports = new beeper()