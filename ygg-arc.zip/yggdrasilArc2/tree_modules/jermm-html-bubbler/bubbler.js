let htmlBubbler = function(options){
    let cheerio = require('cheerio')
    let $ = null
    let harvestCss = function(){
        let styles = $('body').find('style')
        styles.each(function(key, value){
            let style = $(value)
            style.remove().appendTo('head')
            })
        }
    let harvestJs = function(htmlBody){
        let headerScripts = $('body').find('script.headerScript')
        let allTheRest = $('body').find('script:not(.inlineScript):not(.headerScript)')
        let footerScripts = $('body').find('script.footerScript')
        headerScripts.each(function(key, value){
            let script = $(value)
            script = script.remove()
            $('head').append(script)
            })
        allTheRest.each(function(key, value){
            let script = $(value)
            script.remove()
            $('body').append(script)
            })
        footerScripts.each(function(key, value){
            let script = $(value)
            script.remove()
            $('body').append(script)
            })
        }
    this.bubble = function(htmlBody){
        $ = cheerio.load(htmlBody)
        harvestCss()
        harvestJs()
        return $.html()
        }
}
module.exports = new htmlBubbler()