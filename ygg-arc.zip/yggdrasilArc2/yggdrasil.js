let mainProcessConsoleColor = '\x1b[33m' //yellow
let { spawn } = require('child_process')
let yggdrasil = function(){
    console.log(mainProcessConsoleColor+'Yggdrasil Planted\x1b[0m')
    require('./system/logger')
    let repo = require('./system/repo')
    let branches = new (require('./system/branches'))({repo: repo})
    let ratatoskr = new (require('./system/ratatoskr'))({repo: repo, branches: branches})
    let forest = new (require('./system/forest'))({repo: repo, branches: branches})
    let plugins = new (require('./system/plugins'))({repo: repo, branches: branches, forest: forest, ratatoskr: ratatoskr})
    branches.grow({name: 'main', branch: repo.yggdrasil.main.raw})
    console.log(mainProcessConsoleColor+'Yggdrasil Grown\x1b[0m')
}
if(process.env.generate_yggdrasil){
    new yggdrasil()
}else{
    let yggdrasilProcess = {}
    let spawnProcess = function(){
        return spawn(process.argv[0], process.argv.slice(1), {
                stdio: ['inherit', 'inherit', 'inherit', 'ipc']
                , env: { 
                    generate_yggdrasil: 1
                }
            })}
    console.log(mainProcessConsoleColor+'Yggdrasil Being Planted\x1b[0m')
    yggdrasilProcess = spawnProcess()
    let restartYggdrasil = function(code, signal){
        console.log(mainProcessConsoleColor+'Yggdrasil Unplanted\x1b[0m')
        if(code == 4422){
            console.log(mainProcessConsoleColor+'Yggdrasil replanting in 3...\x1b[0m')
            setTimeout(function(){console.log(mainProcessConsoleColor+'Yggdrasil replanting in 2...\x1b[0m')}, 1000)
            setTimeout(function(){console.log(mainProcessConsoleColor+'Yggdrasil replanting in 1...\x1b[0m')}, 2000)
            setTimeout(function(){
                console.log(mainProcessConsoleColor+'Yggdrasil Being Replanted\x1b[0m')
                yggdrasilProcess = spawnProcess()
                yggdrasilProcess.on('exit', restartYggdrasil)
            }, 3000)}}
    yggdrasilProcess.on('exit', restartYggdrasil)
}