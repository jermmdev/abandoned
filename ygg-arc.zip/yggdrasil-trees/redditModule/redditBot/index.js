'use strict';
const snoowrap = require('snoowrap');
const r = new snoowrap({
    userAgent: '',
    clientId: '',
    clientSecret: '',  
    username: '',
    password: ''
  })
module.exports = r