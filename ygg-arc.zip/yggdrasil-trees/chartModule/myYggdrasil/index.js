let yggdrasil = require('./../../../yggdrasil')
let myModule = new (require('./../'))()
let myYggdrasil = new yggdrasil({
    name: 'ChartMaker'
    , key: 'ChartMeUp'
    , port: 4422
    , modules: myModule
})
myYggdrasil.events.on('treeOnline', function(data){
    if(myYggdrasil.trees[data].modules.getData) myYggdrasil.trees[data].modules.getData().then(function(dataReply){
        console.log('Data Reply: ' + dataReply)
    }).catch(function(err){
        console.error('error getting data')
    })
})