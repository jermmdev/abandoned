let mattMod = function(options){
    let pug = require('pug')
    let path = require('path')
    let chart = pug.compileFile(path.join(__dirname, '/charts/chart.pug'))
    this.renderChart = function(options){
        return chart(options)
    }
}
module.exports = mattMod