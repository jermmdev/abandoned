let marketModule = function(options){
    let path = require('path')
    let csvName = 'fmli161x'
    let csvPath = path.join(__dirname, '/' + csvName + '.csv')
    let jsonPath = path.join(__dirname, '/' + csvName + '.json')
    let fs = require('fs')
    let njdb = require('node-json-db')


    let fmldb = new njdb(jsonPath, true, true)
    console.log(fmldb.getData('/fml'))


    // let csvtojson = require('csvtojson')
    // csvtojson().fromFile(csvPath).then((json)=>{
    //     let newdb = {fml: json}
    //     fs.writeFileSync(jsonPath, JSON.stringify(newdb))
    // })
}
//module.exports = marketModule
new marketModule()