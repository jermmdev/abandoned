let joyceMod = function(options){
    let core = this
    let njdb = require('node-json-db')
    let path = require('path')
    let dataSet = new njdb(path.join(__dirname,'/dataSet'))
    core.getData = function(){
        try{
            return dataSet.getData('/joyce')
        }catch(error){
            return {}
        }
    }
}
module.exports = joyceMod