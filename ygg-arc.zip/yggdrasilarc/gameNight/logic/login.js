let loginLogic = function(jermmBots){
    this.jermmBotLogic = function(userInput){
        let email = userInput.email;
        let password = userInput.password;
        if(!email || !password) return false;

        let user = jermmBots.gameNightData.first('/users', {email: userInput.email});
        if(!user) return false;

        let passwordHash = user.password
        if(password == passwordHash){
            return true;
        } 
        return false;
    }
}
module.exports = loginLogic