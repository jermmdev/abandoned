module.exports = function(jermmBots){
    this.jermmBotName = 'loginPageView'
    this.jermmBotStockName = 'viewJermmBot'
    this.jermmBotViewHead = {
        title: 'Game Night Login'
    }
    this.jermmDebug = true;
    this.jermmBotLogic = function(input, path){
        return [
            {type: 'jermmHeader', text: 'Game Night' }
            , {type: 'jermmNav' }
            , {type: 'jermmLogin', path: '/loginListener'}
            ];
        }
    }