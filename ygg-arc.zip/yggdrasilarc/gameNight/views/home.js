let homepage = function(jermmBots){
    this.jermmBotName = 'homePageView'
    this.jermmBotStockName = 'viewJermmBot'
    this.jermmBotViewHead = {
        title: 'Game Night Home'
    }
    this.jermmDebug = true;
    this.jermmBotLogic = function(input, path){
        return [
            {type: 'jermmHeader', text: 'Access Success' }
            ];
        }
}
module.exports = homepage