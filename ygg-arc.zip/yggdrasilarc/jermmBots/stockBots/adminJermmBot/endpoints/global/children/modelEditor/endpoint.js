let createProject = function(jermmBots){
    let fs = require('fs');
    this.jermmBotStockName = 'endpointJermmBot'
    this.metaData = {
        title: 'Model Editor'
        }
    this.css = fs.readFileSync(__dirname+'/modelEditor.css');
    this.js = fs.readFileSync(__dirname+'/modelEditor.js');
    this.jermmDebug = true;
    this.parent = new (require(__dirname+'/../../endpoint.js'))(jermmBots);
    this.pugFile = __dirname + '/modelEditor.pug'
    this.render = function(request, response, childData){
        let testModel = jermmBots.adminData.repository.getTestModel();
        let modelSource = jermmBots.adminData.repository.getModels();
        return {model: testModel, modelName: 'apiJermmBot', modelSource: modelSource, modelType: 'Module'}
        }
}
module.exports = createProject