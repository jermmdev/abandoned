let genBloodhoundModel = function(inputObj, modelType){
    let newArray = [];
    for(let ind in inputObj){
        newArray.push({
            modelName: ind
            , modelType: modelType
            , modelVal: inputObj[ind]
        })
    }
    return newArray
}
let basic = new Bloodhound({
    datumTokenizer: (datum)=>(datum.modelName)
    , queryTokenizer: (query)=>(query)
    , local: genBloodhoundModel(modelSource.basic, 'basic')
  });
let data = new Bloodhound({
    datumTokenizer: (datum)=>(datum.modelName)
    , queryTokenizer: (query)=>(query)
    , local: genBloodhoundModel(modelSource.data, 'data')
    });
let modules = new Bloodhound({
    datumTokenizer: (datum)=>(datum.modelName)
    , queryTokenizer: (query)=>(query)
    , local: genBloodhoundModel(modelSource.modules, 'modules')
    });
let functions = new Bloodhound({
    datumTokenizer: (datum)=>(datum.modelName)
    , queryTokenizer: (query)=>(query)
    , local: genBloodhoundModel(modelSource.functions, 'functions')
    });

let typeaheadObjs = $('.modelTypeTypeahead');
let generateTypeAhead = function(typeaheadObj){
    let modelString = $('#initial'+typeaheadObj.attr('id')).val();

    let modelArr = modelString.split(':');
    modelArr[0] = modelArr[0] ? modelArr[0] : 'No Model'
    modelArr[1] = modelArr[1] ? modelArr[1] : 'No Model'

    let lastSelection = {
        modelName: modelArr[1] || 'null'
        , modelType: modelArr[0] || 'null'
        , modelVal: modelSource[modelArr[0]] ? modelSource[modelArr[0]][modelArr[1]] : 'No Model'
    };

    typeaheadObj.val(lastSelection.modelName);
    typeaheadObj.typeahead(
        {
            minLength: 0
        },{
            name: 'basicModel',
            source: basic,
            display: 'modelName',
            templates: {
                header: '<span class="lead">Basic</span>'
                }
        },{
            name: 'modulesModel',
            source: modules,
            display: 'modelName',
            templates: {
                header: '<span class="lead">Modules</span>'
                }
        },{
            name: 'dataModel',
            source: data,
            display: 'modelName',
            templates: {
                header: '<span class="lead">Data</span>'
                }
        },{
            name: 'functionsModel',
            source: functions,
            display: 'modelName',
            templates: {
                header: '<span class="lead">Functions</span>'
                }
        }
    )
    typeaheadObj.bind('typeahead:change', function(ev, newVal){
        typeaheadObj.val(lastSelection.modelName);
    });
    
    typeaheadObj.bind('typeahead:select', function(ev, selection){
        lastSelection = selection;
    });
    typeaheadObj.bind('typeahead:autocomplete', function(ev, selection){
        lastSelection = selection;
    });
}
$.each(typeaheadObjs, function(ind, typeaheadObj){
    generateTypeAhead($(typeaheadObj))
})


let mainTypeSelector = function(newType){
    $('#modelTypeDropdownButton').text(newType);
}