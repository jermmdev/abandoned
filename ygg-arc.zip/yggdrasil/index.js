let yggdrasil = function(options){
    let core = this
    let path = require('path')

    if(!options.name || typeof(options.name) != 'string') throw new Error("Invalid Yggdrasil Name")
    if(!options.key || typeof(options.key) != 'string') throw new Error("Invalid Yggdrasil Key")
    if(!options.port || !(options.port >= 0)) throw new Error("Invalid Yggdrasil Port")
    new (require(path.join(__dirname, '/logger')))(options)
    core.modules = options.modules
    core.events = new (require('events'))()

    let loadModule = function(name, inputs = {}){
        inputs.name = options.name
        inputs.modules = options.modules
        inputs.key = options.key
        inputs.events = core.events
        inputs.path = path
        inputs.port = options.port
        if(core.repo) inputs.repo = core.repo
        if(core.sendRequestAsync) inputs.sendRequestAsync = core.sendRequestAsync
        if(core.trees) inputs.trees = core.trees
        return new (require(path.join(__dirname, name)))(inputs)
    }

    core.repo = loadModule('repo')
    let requester = loadModule('requester')
    core.sendRequestAsync = requester.sendRequestAsync
    let treeApi = loadModule('treeApi')
    core.trees = treeApi.trees
    let yggUi = loadModule('yggUi')
    let server = loadModule('server')
    server.treeRequest = treeApi.receiveRequest
    server.uiRequest = yggUi.receiveRequest

    for(let ind in core.trees){
        core.trees[ind].sendLoginRequestAsync()
    }
}
module.exports = yggdrasil