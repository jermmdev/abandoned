let repo = function(options){
    let core = this
    let njdb = require('node-json-db')
    let forestDb = false
    let errorDb = false
    let uuid = require('uuid')
    let fs = require('fs')
    try{
        let forestPath = options.path.join(process.cwd(), '/forest.json')
        if(!fs.existsSync(forestPath)) fs.writeFileSync(forestPath, '{}')
        forestDb = new njdb(forestPath, true, true)
    }catch(error){
        console.error('Unable to Load Forest\r\n    Script must be run from same location as forest.json.  \r\n    (It does not have to be located there, though.)')
    }

    try{
        let threatsPath = options.path.join(process.cwd(), '/threats.json')
        if(!fs.existsSync(threatsPath)) fs.writeFileSync(threatsPath, '{}')
        errorDb = new njdb(threatsPath, true, true)
    }catch(error){
        console.error('Unable to Load Threats\r\n    Script must be run from same location as threats.json.  \r\n    (It does not have to be located there, though.)')
    }

    core.getTrees = function(){
        try{
            return forestDb.getData('/trees')
        }catch(error){
            return {}
        }
    }
    core.badLogin = function(badLogin){
        if(typeof(badLogin.ip) != 'string') throw new Error("Yggdrasil Repo - " + options.name + ' - ' + "BadLogins must have an IP associated.")
        errorDb.push('/' + options.name + '/badLogins/' + badLogin.ip + '/'+ Date.now() + '/' + uuid.v1(), badLogin)
    }
    core.getBadLoginsByIp = function(ip){
        if(typeof(ip) != 'string') throw new Error("Yggdrasil Repo - " + options.name + ' - Cannot retrieve bad login without ip string.')
        try{
            return errorDb.getData('/'+options.name+'/badLogins/'+ip)
        }catch(error){
            return false
        }
    }
    core.badSignal = function(badSignal){
        if(typeof(badSignal.ip) != 'string') throw new Error("Yggdrasil Repo - " + options.name + ' - ' + "BadSignals must have an IP associated.")
        errorDb.push('/' + options.name + '/badSignals/' + badSignal.ip + '/'+ Date.now() + '/' + uuid.v1(), badSignal)
    }
    core.getBadSignalsByIp = function(ip){
        if(typeof(ip) != 'string') throw new Error("Yggdrasil Repo - " + options.name + ' - Cannot retrieve bad login without ip string.')
        try{
            return errorDb.getData('/'+options.name+'/badSignals/'+ip)
        }catch(error){
            return false
        }
    }
}
module.exports = repo