let badLoginLimits = function(options){
    let core = this
    let invalidSignalQuantityLimit = 100
    let invalidSignalForgivenessTimer = 1000*60*60*24
    let invalidLoginQuantityLimit = 10
    let invalidLoginForgivenessTimer = 1000*60*60*24*7

    core.overBadLoginLimit = function(ip){
        let badLogins = options.repo.getBadLoginsByIp(ip)
        let minTime = Date.now() - invalidLoginForgivenessTimer
        let invalidCounter = 0
        for(let ind in badLogins){
            if(parseInt(ind, 10) >= minTime){
                invalidCounter++
            }
        }
        if(invalidCounter >= invalidLoginQuantityLimit){
            return true
        }else{
            return false
        }
    }
    core.overBadSignalLimit = function(ip){
        let badSignals = options.repo.getBadSignalsByIp(ip)
        let minTime = Date.now() - invalidSignalForgivenessTimer
        let invalidCounter = 0
        for(let ind in badSignals){
            if(parseInt(ind, 10) >= minTime){
                invalidCounter++
            }
        }
        if(invalidCounter >= invalidSignalQuantityLimit){
            return true
        }else{
            return false
        }
    }
}
module.exports = badLoginLimits