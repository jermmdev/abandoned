let gatekeeper = function(){
    let core = this
    let spammers = {}
    let spamLimit = 60
    let forgivenessTimer = 1000*60
    core.validatePost = function(req, res){
        if(!spammers[req.connection.remoteAddress]) spammers[req.connection.remoteAddress] = []
        let rightNow = Date.now()
        spammers[req.connection.remoteAddress].push(rightNow)
        setTimeout(function(){
            spammers[req.connection.remoteAddress].splice(0,1)
        }, forgivenessTimer)
        if(spammers[req.connection.remoteAddress].length >= spamLimit) return false
        return true
    }
    core.validateGet = function(req, res){
        if(!spammers[req.connection.remoteAddress]) spammers[req.connection.remoteAddress] = []
        let rightNow = Date.now()
        spammers[req.connection.remoteAddress].push(rightNow)
        setTimeout(function(){
            spammers[req.connection.remoteAddress].splice(0,1)
        }, forgivenessTimer)
        if(spammers[req.connection.remoteAddress].length >= spamLimit) return false
        return true
    }
}
module.exports = gatekeeper