let fs = require('fs')
let path = require('path')
let tls = require('tls')
let serverOptions = {
    key: fs.readFileSync('key.pem')
    , cert: fs.readFileSync('cert.pem')
    , dhparam: fs.readFileSync('dhparam.pem')
    , ca: []
    , requestCert: true
    , rejectUnauthorized: true
}
let droneCertsDir = path.join(__dirname, '/droneCerts')
let droneCerts = fs.readdirSync(droneCertsDir)
for(let certInd in droneCerts){
    serverOptions.ca.push(fs.readFileSync(path.join(droneCertsDir, droneCerts[certInd])))
}
let server = tls.createServer(serverOptions)
module.exports = server