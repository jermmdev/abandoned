let fs = require('fs')
let path = require('path')
let tls = require('tls')
let serverOptions = {
    key: fs.readFileSync('key.pem')
    , cert: fs.readFileSync('cert.pem')
    , dhparam: fs.readFileSync('dhparam.pem')
    , ca: []
    , requestCert: true
    , rejectUnauthorized: true
}
let workerCertsDir = path.join(__dirname, '/workerCerts')
let workerCerts = fs.readdirSync(workerCertsDir)
for(let certInd in workerCerts){
    serverOptions.ca.push(fs.readFileSync(path.join(workerCertsDir, workerCerts[certInd])))
}
let server = tls.createServer(serverOptions)
module.exports = server