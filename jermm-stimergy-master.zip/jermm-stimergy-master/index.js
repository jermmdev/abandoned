let path = require('path')
let droneServer = require(path.join(__dirname, 'tls-drones.js'))
let workerServer = require(path.join(__dirname, 'tls-workers.js'))
let njdb = require('node-json-db')

let stimergyDb = new njdb(path.join(__dirname, 'stimergy.json'), true, true)
droneServer.on('secureConnection', droneSocket => {
    console.log('Drone Connected')
    droneSocket.write(JSON.stringify({jermmPing: true}))
    droneSocket.on('error', err=>{
        console.log('Drone Error', err)
    })
    droneSocket.on('close', closeCode => {
        console.log('Drone Offline')
        delete droneSocket
    })
    droneSocket.on('data', data => {
        data = JSON.parse(data)
        if(!droneSocket.botName){
            droneSocket.botName = data
            let botTraining = {}
            try{
                botTraining = stimergyDb.getData('/'+data+'/training')
            }catch(err){
                stimergyDb.push('/'+data, {training: {}, brain: {}})
                console.log('New Bot', data)
            }
            droneSocket.write(JSON.stringify({training: botTraining}))
            return
        }
        if(data.jermmPing){
            setTimeout(()=>{
                if(droneSocket) droneSocket.write(JSON.stringify({jermmPing: true}))
            }, 30000)
            return
        }
        if(data.training){
            let botData = {training: {}, brain: {}}
            try{
                botData = stimergyDb.getData('/'+droneSocket.botName)
            }catch(err){
                stimergyDb.push('/'+droneSocket.botName, botData)
                console.log('New Bot', droneSocket.botName)
            }
            for(let inputName in data.training){
                for(let outcomeName in data.training[inputName]){
                    let oldCount = 0
                    if(botData.training[inputName] && botData.training[inputName][outcomeName]) oldCount = botData.training[inputName][outcomeName]
                    let newResult = oldCount + parseInt(data.training[inputName][outcomeName])
                    if(newResult <= 0){
                        if(botData.training[inputName] && botData.training[inputName][outcomeName]) delete botData.training[inputName][outcomeName]
                        if(botData.training[inputName] && Object.keys(botData.training[inputName]).length === 0) delete botData.training[inputName]
                    }else{
                        if(!botData.training[inputName]) botData.training[inputName] = {}
                        botData.training[inputName][outcomeName] = newResult
                    }
                }
            }
            let totals = {inputs: {}, outcomes: {}, inputOutcome: {}, grand: 0}
            for(let inputName in botData.training){
                totals.inputs[inputName] = 0
                for(let outcomeName in botData.training[inputName]){
                    if(!totals.outcomes[outcomeName]) totals.outcomes[outcomeName] = 0
                    let outcomeCount = parseInt(botData.training[inputName][outcomeName])
                    totals.inputs[inputName] += outcomeCount
                    totals.outcomes[outcomeName] += outcomeCount
                    totals.grand += outcomeCount
                }
            }
            if(totals.grand === 0){
                stimergyDb.delete('/'+droneSocket.botName)
                console.log('Bot Removed', droneSocket.botName)
                return
            }
            let botMap = {}
            for(let inputName in botData.training){
                botMap[inputName] = {}
                let inputTotal = totals.inputs[inputName]
                for(let outcomeName in botData.training[inputName]){
                    let outcomeCount = parseInt(botData.training[inputName][outcomeName])
                    let outcomeTotal = totals.outcomes[outcomeName]
                    let grandTotal = totals.grand
                    let probBoth = parseFloat(outcomeCount / outcomeTotal)
                    let probInput = parseFloat(inputTotal / grandTotal)
                    let probOutcome = parseFloat(outcomeTotal / grandTotal)
                    botMap[inputName][outcomeName] = parseFloat(probBoth * probInput / probOutcome)
                }
            }
            botData.brain = botMap
            droneSocket.write(JSON.stringify({training: botData.training}))
            stimergyDb.push('/' + droneSocket.botName, botData)
            return
        }
    })
})
workerServer.on('secureConnection', workerSocket => {
    console.log('Worker Connected')
    workerSocket.on('error', err=>{
        console.log('Worker Error', err)
    })
    workerSocket.on('close', closeCode=>{
        console.log('Worker Offline')
        delete workerSocket
    })
    workerSocket.on('data', data=>{
        data = JSON.parse(data)
        try{
            let botBrain = stimergyDb.getData('/'+data+'/brain')
            workerSocket.write(JSON.stringify(botBrain))
        }catch(err){
            console.error('Worker Socket', err)
        }
        workerSocket.close()
        return
    })
})
droneServer.listen(4422, ()=>{
    console.log('Drone Server Online', 4422)
})
workerServer.listen(4242, ()=>{
    console.log('Worker Server Online', 4242)
})