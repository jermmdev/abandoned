# jermm-stimergy
The central intelligence of a jermm colony
