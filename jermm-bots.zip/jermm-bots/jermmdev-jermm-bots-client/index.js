let fs = require('fs')
let path = require('path')
let clientPath = path.join(__dirname, 'jermm-bots-client')
let getHub = require('gethub')


let clientReady = ()=>{
    let seedClient = require(clientPath)
    let sc = new seedClient('wss://jermm-bots-root-jermm-dev.1d35.starter-us-east-1.openshiftapps.com/:8080'
    , 'jermmDev'
    , 'ImJermmDev'
    , 'IDontWriteNoCodeIMakeDataMove'
    , 4422
    )
    sc.events.on('online', ()=>{
        console.log('am online ', sc.yggApi)
        myYgg = sc.yggApi
    })
    sc.events.on('offline', ()=>{
        console.log('am offline', sc.yggApi)
        myYgg = false
    })
    sc.events.on('apiUpdated', ()=>{
        console.log('am updated ', sc.yggApi)
        myYgg = sc.yggApi
    })
}


if(!fs.existsSync(clientPath)){
    console.log('getting botsclient')
    getHub('jermmdev', 'jermm-bots-client', 'master', clientPath).then(clientReady).catch((err)=>{
        throw err
    })
}else{
    console.log('already had client')
    clientReady()
}