let getHub = require('gethub')
let path = require('path')
let crypto = require('crypto')
let Events = require('events')
let fs = require('fs')
let JermmBot = require(path.join(__dirname, 'jermm-bot'))
let wssPath = path.join(__dirname, 'jermm-wss')
let seedClient = function(rootAddress, myName, myPublicKey, myPrivateKey, port, server){
    let mySeedClient = this
    mySeedClient.events = new Events()
    mySeedClient.jermmBots = {}
    mySeedClient.rootBots = {}
    let wssIsReady = ()=>{
        //send learning
        //receive learning
        let wss = new (require(wssPath))(port, server)
        let loginToken = ''
        let rootSocket = false
        let requestLogin = ()=>{
            if(rootSocket) return false
            console.log('Sending Root Login Request')
            let loginWs = wss.GetSocket(rootAddress)
            loginToken = crypto.createHash('md5').update(myPublicKey+Date.now()).digest('hex')
            loginAttempt = loginWs
            loginWs.on('open', ()=>{
                loginWs.sendify({
                    jermmLogin: {
                        name: myName
                        , publicKey: myPublicKey
                        , token: loginToken
                    }
                })
                loginWs.close()
            })
            setTimeout(requestLogin, 10*1000)
        }
        wss.onConnect = (wsId)=>{
            if(rootSocket || !loginToken) {
                wss.connected[wsId].ws.close()
                return false
            }
            wss.connected[wsId].ws.msgParse = (msg) =>{
                if(
                    msg.jermmLogin
                    && msg.jermmLogin.privateKey === myPrivateKey
                    && msg.jermmLogin.token === loginToken
                ){
                    loginToken = false
                    rootSocket = wsId
                    for(let botName in msg.jermmLogin.botList){
                        mySeedClient.rootBots[botName].get = ()=>{
                            wss.connected[wsId].ws.sendify({ getMap: botName })
                            delete mySeedClient.rootBots[botName].get
                        }
                        if(msg.jermmLogin.isTrainer){
                            mySeedClient.rootBots[botName].give = ()=>{
                                wss.connected[wsId].ws.sendify({ giveMap: {name: botName, botMap: mySeedClient.jermmBots[botName].botMap }})
                            }
                        }
                    }
                    wss.connected[wsId].ws.msgParse = (msg) =>{
                        if(msg.botMap){
                            mySeedClient.jermmBots = new JermmBot(msg.botMap.map)
                            mySeedClient.events.emit('botBuilt', msg.botMap.name)
                        }
                        if(msg.newBot){
                            botList[msg.newBot] = true
                            mySeedClient.events.emit('newRoot', msg.newBot)
                        }
                        if(msg.jermmPing){
                            setTimeout(()=>{
                                if(wss.connected[wsId]) wss.connected[wsId].ws.sendify({jermmPing: true})
                            }, 30*1000)
                        }
                    }
                    wss.connected[wsId].ws.on('close', ()=>{
                        delete mySeedClient.giveMap
                        if(rootSocket === wsId) rootSocket = false
                        console.log('Root Offline.  Attempting reconnect.')
                        mySeedClient.events.emit('rootOffline')
                        requestLogin()
                    })
                    wss.connected[wsId].ws.sendify({
                        jermmPing: true
                    })
                    mySeedClient.events.emit('rootOnline')
                    console.log('Root Online')
                }else{
                    wss.connected[wsId].ws.close()
                    console.log('Bad Login Attempted')
                }
            }
            setTimeout(()=>{
                if(rootSocket != wsId && wss.connected[wsId]) wss.connected[wsId].ws.close()
            }, 10*1000)
        }
        requestLogin()
    }
    if(!fs.existsSync(wssPath)){
        getHub('jermmdev', 'jermm-wss', 'master', wssPath).then(wssIsReady).catch((err)=>{
            throw err
        })
    }else{
        wssIsReady()
    }
}
module.exports = seedClient