let jermmBot = function(botMap){
    let core = this
    core.botMap = botMap
    core.search = (searchInput)=>{
        let results = {}
        for(let inputName in searchInput){
            if(botMap.inputs[inputName]){
                for(let outputName in botMap.inputs[inputName]){
                    if(!results[outputName]) results[outputName] = 0
                    results[outputName] += botMap.inputs[inputName][outputName]
                }
            }
        }
        let sortedResultKeys = Object.keys(results).sort((outputA,outputB)=>{return (results[outputA]-results[outputB])})
        let finalResults = {}
        let resultsCounter = 0
        for(let sortInd in sortedResultKeys){
            resultsCounter++
            let outputName = sortedResultKeys[sortInd]
            finalResults[outputName] = results[outputName]
            if(resultsCounter > core.botMap.resultLimit) break
        }
        return finalResults
    }
}
module.exports = jermmBot