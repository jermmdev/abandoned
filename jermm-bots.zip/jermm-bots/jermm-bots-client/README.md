# jermm-bots-client
A client for connecting to the jermm-bots network.
