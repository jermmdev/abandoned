let crypto = require('crypto')
let WebSocket = require('ws')
let jermmWss = function(port, server) {
    let core = this
    core.wss = {}
    if(server){
        core.wss = new WebSocket.Server({server: server})
    }
    else {
        console.log('Jermm Wss Online')
        core.wss = new WebSocket.Server({port: port})
    }

    core.GetSocket = (address)=>{
        let newWs = new WebSocket(address)
        newWs.sendify = (msg)=>{
            try{
                msg = JSON.stringify(msg)
            }catch(err){
                console.error(err)
                return false
            }
            newWs.send(msg)
        }
        newWs.on('error', (err)=>{
            return null
        })
        newWs.msgParse = (msg)=>{}
        newWs.on('message', (msg) => {
            try{
                let parsed = JSON.parse(msg)
                ws.msgParse(parsed)
            }catch(err){
                console.error(err)
            }
            return msg
        })
        return newWs 
    }

    core.connected = {}
    core.history = {}
    core.onConnect = (wsId) => {}
    core.wss.on('connection', (ws, req) => {
        let created = Date.now()
        let wsId = crypto
            .createHash('md5')
            .update(
                req.headers['x-forwarded-for'] 
                + req.connection.remoteAddress 
                + req.headers['user-agent']
                + created
            ).digest('hex')
        ws.sendify = (msg) => {
            try{
                msg = JSON.stringify(msg)
            }catch(err){
                console.error(err)
                return false
            }
            ws.send(msg)
        }
        ws.msgParse = (msg)=>{}
        ws.on('message', (msg) => {
            try{
                let parsed = JSON.parse(msg)
                ws.msgParse(parsed)
            }catch(err){
                console.error(err)
            }
            return msg
        })
        ws.on('close', (closeCode) => {
            core.history[wsId] = core.connected[wsId]
            delete core.connected[wsId]
        })
        ws.on('error', (err)=>{
            return null
        })
        core.connected[wsId] = {
            ws: ws
            , req: {
                headers: req.headers
                , body: req.body
                , remoteAddress: req.connection.remoteAddress
            }
            , created: created
        }
        core.onConnect(wsId)
    })
    if(server) {
        server.listen(port, ()=>{
            console.log('Jermm Wss Online: Custom Server')
        })
    }
}
module.exports = jermmWss