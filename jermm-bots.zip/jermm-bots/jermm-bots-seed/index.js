let path = require('path')
let fs = require('fs')
let crypto = require('crypto')
let http = require('http')
let express = require('express')
let pug = require('pug')
let getHub = require('gethub')
let expressApp = new express()
let server = http.createServer(expressApp)
let wssPath = path.join(__dirname, 'jermm-wss')
let displayPath = path.join(__dirname, 'display.pug')
let displayView = pug.compileFile(displayPath)
let seedCore = function(jermmMod, botMap, rootAddress, myName, myPublicKey, myPrivateKey, port){
    let wssIsReady = ()=>{
        let jermmBot = (new (require(path.join(__dirname, 'jermm-bot.js'))))(botMap, jermmMod)
        expressApp.get('/*', (req, res)=>{
            res.status(200).send(displayView({inputs: jermmBot.inputs, outputs: jermmBot.outputs}))
        })
        let wss = new (require(wssPath))(port, server)
        let loginToken = ''
        let rootSocket = false
        let requestLogin = ()=>{
            if(rootSocket) {
                if(loginToken) loginToken = false
                return false
            }
            console.log('Sending Root Login Request')
            let loginWs = wss.GetSocket(rootAddress)
            loginToken = crypto.createHash('md5').update(myPublicKey+Date.now()).digest('hex')
            loginAttempt = loginWs
            loginWs.on('open', ()=>{
                loginWs.sendify({
                    jermmClientLogin: {
                        name: myName
                        , publicKey: myPublicKey
                        , token: loginToken
                    }
                })
                loginWs.close()
            })
            setTimeout(requestLogin, 10*1000)
        }
        wss.onConnect = (wsId)=>{
            if(rootSocket || !loginToken) {
                wss.connected[wsId].ws.close()
                return false
            }
            wss.connected[wsId].ws.msgParse = (msg) =>{
                if(
                    msg.jermmLogin
                    && msg.jermmLogin.privateKey === myPrivateKey
                    && msg.jermmLogin.token === loginToken
                ){
                    loginToken = false
                    rootSocket = wsId
                    wss.connected[wsId].ws.msgParse = (msg) =>{
                        if(msg.search){
                            try{
                                let searchResult = jermmBot.search(msg.search.searchInput)
                                if(wss.connected[wsId]) wss.connected[wsId].ws.sendify({
                                    clientResponse: {
                                        sender: msg.search.sender
                                        , searchInput: msg.search.searchInput
                                        , searchToken: msg.search.searchToken
                                        , searchResult: searchResult
                                    }
                                })
                                return true
                            }catch(err){
                                if(wss.connected[wsId]) wss.connected[wsId].ws.sendify({
                                    clientResponse: {
                                        sender: msg.search.sender
                                        , searchInput: msg.search.searchInput
                                        , searchToken: msg.search.searchToken
                                        , errorResult: err
                                    }
                                })
                                console.err('Search Failure', err)
                                return false
                            }
                        }
                        if(msg.jermmPing){
                            setTimeout(()=>{
                                if(wss.connected[wsId]) wss.connected[wsId].ws.sendify({jermmPing: true})
                            }, 30*1000)
                            return true
                        }
                        if(msg.replaceBotMap){
                            jermmBot.replaceBotMap(msg.replaceBotMap)
                        }
                    }
                    wss.connected[wsId].ws.on('close', ()=>{
                        if(rootSocket === wsId) rootSocket = false
                        console.log('Root Offline.  Attempting reconnect.')
                        requestLogin()
                    })
                    wss.connected[wsId].ws.sendify({
                        jermmBotContents: {inputs: jermmBot.inputs, outputs: jermmBot.outputs}
                    })
                    wss.connected[wsId].ws.sendify({
                        jermmPing: true
                    })
                    console.log('Root Online')
                }else{
                    wss.connected[wsId].ws.close()
                    console.log('Bad Login Attempted')
                }
            }
            setTimeout(()=>{
                if(rootSocket != wsId && wss.connected[wsId]) wss.connected[wsId].ws.close()
            }, 10*1000)
        }
        requestLogin()
    }
    if(!fs.existsSync(wssPath)){
        getHub('jermmdev', 'jermm-wss', 'master', wssPath).then(wssIsReady).catch((err)=>{
            throw err
        })
    }else{
        wssIsReady()
    }
}
module.exports = seedCore