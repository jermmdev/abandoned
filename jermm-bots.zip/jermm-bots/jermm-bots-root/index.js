//core components
//  trainer
//  bot
//  data

//(no more trainer, root trains.)
let net = require('net')
