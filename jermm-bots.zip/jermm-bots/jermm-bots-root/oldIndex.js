let fs = require('fs')
let path = require('path')
let forest = JSON.parse(fs.readFileSync(path.join(__dirname, 'forest.json', 'utf-8')))
let botMaps = JSON.parse(fs.readFileSync(path.join(__dirname, 'botMaps.json', 'utf-8')))
let botList = {}
for(let ind in botMaps){botList[ind] = true}
let http = require('http')
let express = require('express')
let pug = require('pug')
let getHub = require('gethub')
let expressApp = new express()
let displayPath = path.join(__dirname, 'display.pug')
let displayView = pug.compileFile(displayPath)
let wssPath = path.join(__dirname, 'jermm-wss')
let jermmBots = {}
let trainers = {}
let server = http.createServer(expressApp)
let wssIsReady = ()=>{
    //send learning
    //receive learning
    expressApp.get('/*', (req, res)=>{
        res.status(200).send(displayView({botMaps: botMaps, jermmBots: jermmBots}))
    })
    let wss = new (require(wssPath))(8080, server)
    let botLogin = (loginMsg, botData) =>{
        botWs = wss.GetSocket(botData.address)
        botWs.on('open', ()=>{
            botWs.sendify({
                jermmLogin: {
                    privateKey: botData.privateKey
                    , token: loginMsg.token
                    , botList: botList
                    , isTrainer = forest.trainers[botData.name]
                }
            })
        })
        botWs.on('close', ()=>{
            delete jermmBots[botData.name]
        })
        botWs.msgParse = (msg)=>{
            if(msg.jermmPing){
                setTimeout(()=>{
                    if(botWs) botWs.sendify({jermmPing: true})
                }, 30*1000)
                return true
            }
            if(msg.getMap){
                botWs.sendify({botMap: {name: msg.getMap, map: botMaps[msg.getMap]}})
                return true
            }
            if(forest.trainers[botData.name]){
                if(msg.giveMap){
                    botMaps[msg.giveMap.name] = msg.giveMap.botMap
                    for(let ind in jermmBots){
                        let theBot = jermmBots[ind]
                        if(theBot.sendify){
                            theBot.sendify({newBot: msg.giveMap.name})
                        }
                    }
                }
            }
        }
    }
    wss.onConnect = (wsId)=>{
        wss.connected[wsId].ws.msgParse = (msg)=>{
            wss.connected[wsId].ws.close()
            if(msg.jermmLogin){
                if(
                    !forest.jermmBots[msg.jermmLogin.name]
                    || msg.jermmLogin.publicKey !== forest.jermmBots[msg.jermmLogin.name].publicKey
                    || jermmBots[msg.jermmLogin.name]
                ){
                    return false
                }else{
                    jermmBots[msg.jermmLogin.name] = true
                    return botLogin(msg.jermmLogin, forest.jermmBots[msg.jermmLogin.name])
                }
            }
        }
        setTimeout(()=>{
            if(wss.connected[wsId]) wss.connected[wsId].ws.close()
        }, 10*1000)
    }
}
if(!fs.existsSync(wssPath)){
    getHub('jermmdev', 'jermm-wss', 'master', wssPath).then(wssIsReady).catch((err)=>{
        throw err
    })
}else{
    wssIsReady()
}