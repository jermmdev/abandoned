# jermm-bot
The final node in a jermm-bot network
