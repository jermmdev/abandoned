let fs = require('fs')
let path = require('path')
let tls = require('tls')
let requestOptions = {
    key: fs.readFileSync(path.join(__dirname, 'myKey.pem'))
    , cert: fs.readFileSync(path.join(__dirname, 'myCert.pem'))
    , ca: []
}
let trainerCertsDir = path.join(__dirname, '/trainerCerts')
let trainerCerts = fs.readdirSync(trainerCertsDir)
for(let certInd in trainerCerts){
    serverOptions.ca.push(fs.readFileSync(path.join(trainerCertsDir, trainerCerts[certInd])))
}
let repoCertsDir = path.join(__dirname, '/repoCerts')
let repoCerts = fs.readdirSync(repoCertsDir)
for(let certInd in repoCerts){
    serverOptions.ca.push(fs.readFileSync(path.join(repoCertsDir, repoCerts[certInd])))
}
let request = path => {
    return tls.connect(path, requestOptions)
}
module.exports = request