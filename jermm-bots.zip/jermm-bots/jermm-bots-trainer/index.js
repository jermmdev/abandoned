let path = require('path')
let fs = require('fs')
let jermmTls = require(path.join(__dirname, 'jermm-tls.js'))
let njdb = require('node-json-db')
let botsDb = new njdb(path.join(__dirname, 'jermm-bots.json'), true, true)
let botList = JSON.parse(fs.readFileSync(path.join(__dirname, 'jermm-bots-list.json'), 'utf8'))
let trainer = require(path.join(__dirname, 'trainingEngine.js'))
let repoPaths = JSON.parse(fs.readFileSync(path.join(__dirname, 'jermm-repos.json'), 'utf8'))
let repos = {}
let Events = require('events')
let events = new Events()
for(let repoName in repoPaths){
    let repoPath = repoPaths[repoName]
    let newRepo = jermmTls.request(repoPath)
    let awaitingData = {}
    newRepo.on('open', ()=>{
        repos[repoName] = {
            getData: async function(dataPath){
                return new Promise((resolve, reject)=>{
                    awaitingData[dataPath] = true
                    let receiveData = dataIn => {
                        resolve(dataIn)
                        events.removeListener('')
                    }
                })
            }
        }
    })
    newRepo.on('data', data => {
        events.emit('dataReceived')
    })
}
jermmTls.server.on('secureConnection', socket => {
    socket.setEncoding('utf8')
    let clientName = socket.getPeerCertificate().subject.CN
    socketData.on('open', ()=>{
        socket.write({botList: botList})
    })
    socket.on('data', data=>{
        if(data.jermmPing){
            if(socket) setTimeout(()=>{
                if(socket) socket.write({jermmPing: true})
            }, 30000)
        }
        if(data.brain){
            let brain = {}
            brain = botsDb.getData('/'+data.brain+'/brain')
            botName = data.brain
            socket.write({brain: brain, botName: botName})
            return
        }
        if(data.train){
            let oldTraining = false
            oldTraining = botsDb.getData('/'+data.train.botName+'/training')
            let newTraining = trainer.mergeTraining(oldTraining, data.train.newTraining)
            botsDb.push('/'+data.train.botName+'/training', newTraining)
            let newBrain = trainer.getBrain(newTraining)
            botsDb.push('/'+data.train.botName+'/brain', newBrain)
            return
        }
    })
    socket.on('error', ()=>{
        console.error('Bot Socket Error')
    })
    socket.on('close', closeCode=>{
        delete socket
    })
})
jermmTls.server.listen(4422, ()=>{console.log('jermm-trainer online', 4422)})

let localUi = require(path.join(__dirname, 'trainerUi/index.js'))
localUi.botList = botList
