# jermm-bots-trainer
A trainer for a jermm-bot
