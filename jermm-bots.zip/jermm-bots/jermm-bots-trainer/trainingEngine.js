module.exports = {
    mergeTraining: (trainingDataOne, trainingDataTwo) => {
        for(let input in trainingDataOne){
            if(!trainingDataTwo[input]) trainingDataTwo[input] = {}
            for(let outcome in trainingDataOne){
                if(!trainingDataTwo[input][outcome]) trainingDataTwo[input][outcome] = trainingDataOne[input][outcome]
                else trainingDataTwo[input][outcome] = parseInt(trainingDataTwo[input][outcome]) + parseInt(trainingDataOne[input][outcome])
            }
        }
        return trainingDataTwo
    }
    , getBrain = (trainingData)=>{
        let inputTotals = {}
        let outcomeTotals = {}
        let grandTotal = 0
        for(let input in trainingData){
            if(!inputTotals[input]) inputTotals[input] = 0
            for(let outcome in trainingData[input]){
                let outcomeCount = trainingData[input][outcome]
                if(!outcomeTotals[outcome]) outcomeTotals[outcome] = 0
                outcomeTotals[outcome] += outcomeCount
                inputTotals[input] += outcomeCount
                grandTotal += outcomeCount
            }
        }
        let newBrain = {}
        for(let inputName in trainingData.inputs){
            let input = trainingData.inputs[inputName]
            let inputTotal = inputTotals[inputName]
            newBrain[inputName] = {}
            for(let outcomeName in input.outcomes){
                let outcomeCount = parseInt(input.outcomes[outcomeName])
                let outcomeTotal = outcomeTotals[outcomeName]
                let probBoth = outcomeTotal > 0 ? parseFloat(outcomeCount / outcomeTotal) : 0
                let probInput = grandTotal > 0 ? parseFloat(inputTotal / grandTotal) : 0
                let probOutcome = grandTotal > 0 ? parseFloat(outcomeTotal / grandTotal) : 0
                newBrain[inputName][outcomeName] = probOutcome > 0 ? probBoth * probInput / probOutcome : 0
            }
        }
        return newBrain
    }
}