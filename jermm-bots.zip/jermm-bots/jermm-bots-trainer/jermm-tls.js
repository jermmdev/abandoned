let fs = require('fs')
let path = require('path')
let tls = require('tls')
let serverOptions = {
    key: fs.readFileSync('server-key.pem')
    , cert: fs.readFileSync('server-cert.pen')
    , ca: []
    , requestCert: true
    , rejectUnauthorized: true
}
let botCertsDir = path.join(__dirname, '/botCerts')
let botCerts = fs.readdirSync(botCertsDir)
for(let certInd in botCerts){
    serverOptions.ca.push(fs.readFileSync(path.join(botCertsDir, botCerts[certInd])))
}
let server = tls.createServer(tlsOptions)

let requestOptions = {
    key: fs.readFileSync(path.join(__dirname, 'myKey.pem'))
    , cert: fs.readFileSync(path.join(__dirname, 'myCert.pem'))
    , ca: []
}
let repoCertsDir = path.join(__dirname, '/repoCerts')
let repoCerts = fs.readdirSync(repoCertsDir)
for(let certInd in repoCerts){
    serverOptions.ca.push(fs.readFileSync(path.join(repoCertsDir, repoCerts[certInd])))
}
let request = path => {
    return tls.connect(path, requestOptions)
}
module.exports = request
module.exports = {
    server: server
    , request: request
}