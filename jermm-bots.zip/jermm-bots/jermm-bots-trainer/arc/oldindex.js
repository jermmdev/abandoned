let path = require('path')
let njdb = require('node-json-database')
let rawDataDb = new njdb(path.join(__dirname, 'rawData.json'))
let outputRepoDb = new njdb(path.join(__dirname, 'outputRepo.json'))
let trainingDataDb = new njdb(path.join(__dirname, 'trainingData.json'))

//purpose > making new maps from any starting point
//if no raw data > build database (ui only)
//  functions
//      buildDatabase (jsonCreator UI)
//      convertToJSON (for taking in csv and stuff)
//if no training Data > build training data from raw data
//  functions
//      createRepo (outcome to datapath index for raw data)
//          provide as file
//          UI
//      createInputs
//          provide as file
//          UI
//      train (create input)
//          provide as file
//          UI
//      
//that's really the last step, now just makeBotMap()

//training data includes
//  input > output mappings
//  implied > 
//      input > output count
//      input total count
//      output total count
//      input+output total count 
let botMap = "result of training data db run through engine"
//botmap includes
//  input > output > score mappings