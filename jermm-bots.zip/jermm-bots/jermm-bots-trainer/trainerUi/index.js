let express = require('express')
let pug = require('pug')
let app = new express()
app.get('/*', (req, res)=>{

})
app.listen(4242, 'localhost', ()=>{ console.log('local trainer online') })
//localhost only