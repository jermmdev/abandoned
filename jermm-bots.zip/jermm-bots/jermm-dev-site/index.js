
let fs = require('fs')
let path = require('path')
let http = require('http')
let pug = require('pug')
let getHub = require('gethub')
let jds = require('./jermmdevServer.js')
let notReadyView = pug.renderFile('./pugViews/notReady.pug')
let clientPath = path.join(__dirname, 'jermm-bots-client')
let myYgg = false

let resumeOptions = {
    title: "Jermm-Dev"
    , author: "jermmdev"
    , desc: "An example of a jermm-bots network."
    , navTitle: "Jermm-Dev"
    , sections: {
        hireMe: {
            headLeft: "Hire"
            , headRight: "Me"
            , subHead: "Contact Me at <a href=\"mailto:jermmdev@gmail.com\">jermmdev@gmail.com</a>"
            , content: pug.renderFile('./pugViews/forHire.pug')
        },
        jermmBots: {
            headLeft: "Jermm"
            , headRight: "Bots"
            , subHead: "How I'm hosting this site"
            , content: pug.renderFile('./pugViews/jermmBots.pug')
        },
        skills: {
            headLeft: "Tech"
            , headRight: "Skills"
            , subHead: "professional skillset"
            , content: pug.renderFile('./pugViews/skills.pug')
        },
        experience: {
            headLeft: "Past"
            , headRight: "Work"
            , subHead: "Bachelor of Science in Mathematics and Education"
            , content: pug.renderFile('./pugViews/experience.pug')
        }
    }
}

let server = http.createServer(jds)
jds.get('/*', (req, res)=>{
    if(!myYgg || !myYgg.jermmViews || !myYgg.jermmViews.resume){
        res.status(200).send(notReadyView)
    }else{
        myYgg.jermmViews.resume(resumeOptions).then((responseData)=>{
            res.status(200).send(responseData)
        }).catch((err)=>{
            res.status(503).send(err)
        })
    }
})

let clientReady = ()=>{
    let seedClient = require(clientPath)
    let sc = new seedClient('wss://jermm-bots-root-jermm-bots.b9ad.pro-us-east-1.openshiftapps.com'
    , 'jermmDevSite'
    , 'ImaWebSiteForJermmDev'
    , 'IDontWriteNoCodeIMakeDataDance'
    , 8080
    , server
    )
    sc.events.on('online', ()=>{
        console.log('am online ', sc.yggApi)
        myYgg = sc.yggApi
    })
    sc.events.on('offline', ()=>{
        console.log('am offline', sc.yggApi)
        myYgg = false
    })
    sc.events.on('apiUpdated', ()=>{
        console.log('am updated ', sc.yggApi)
        myYgg = sc.yggApi
    })
}


if(!fs.existsSync(clientPath)){
    console.log('getting botsclient')
    getHub('jermmdev', 'jermm-bots-client', 'master', clientPath).then(clientReady).catch((err)=>{
        throw err
    })
}else{
    console.log('already had client')
    clientReady()
}