var jermmBots = function(){
    //An instance of jermmBots can itself be a bot.  This is how grouping/namespaces work.
    let jermmBots = this;

    let botCounter = 1;
    let stock = [];
    let attemptNew = function(inputBot, isRegister){
        let newBot = {};
        if(!isRegister) newBot = new inputBot(jermmBots);
        else newBot = inputBot;
        let botName = newBot.jermmBotName || 'jermmBot' + botCounter;
        if(jermmBots[botName]) throw('jermmBot already running at: ' + botName);
        botCounter++;
        newBot.jermmBotName = botName;
        console.log('Bot Registered: ' + newBot.jermmBotName);
        return newBot;
    }
    this.jermmBotCreate = function(inputBot){
        var newBot = attemptNew(inputBot);
        jermmBots[newBot.jermmBotName] = newBot;
        return jermmBots[newBot.jermmBotName];
    }
    //note: when compiled, create system to attach event to object access in jermmBots during compile.  report these links.  cease the event for performance afterward.
    this.jermmBotCreateStock = function(inputBot){
        var newBot = attemptNew(inputBot);
        if(!stock[newBot.jermmBotStockName]) stock[newBot.jermmBotStockName] = require('./stockBots/'+newBot.jermmBotStockName);
        if(!stock[newBot.jermmBotStockName]) throw('Stock jermmBot not found: ' + newBot.jermmBotStockName);
        jermmBots[newBot.jermmBotName] = new stock[newBot.jermmBotStockName](jermmBots, newBot);
        return jermmBots[newBot.jermmBotName];
    }
    this.jermmBotRegister = function(inputBot){
        var newBot = attemptNew(inputBot, true);
        jermmBots[botName] = newBot;
        return jermmBots[botName];
    }
}
module.exports = (new jermmBots());