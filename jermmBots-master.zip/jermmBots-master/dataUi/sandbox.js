let oldPathContainer = $("#'+ tiId + 'SavePath"); 
let oldPath = oldPathContainer.val(); 
let oldSplit = oldPath.split("/"); 
let oldName = oldSplit[oldSplit.length - 1]; 
let newPath = oldPath.replace(oldName, newName); 
oldPathContainer.val(newPath); 
$("#' + ccId + 'Title").text(newVal);