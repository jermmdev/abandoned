let pug = require('pug')
let path = require('path')
let fs = require('fs')

let express = require('express')
let bot = express();
let cookieParser = require('cookie-parser');
bot.use(cookieParser());
bot.use(express.json());
bot.use(express.urlencoded());

let repo = require(__dirname+'/repo.js')

let bubbler = require(__dirname+'/scriptBubbler.js')

let generateJermmReq = function(jermmReq){
    let lastSlash = jermmReq.url.lastIndexOf('/')
    let getStart = jermmReq.url.indexOf('?', lastSlash) + 1
    let getString = jermmReq.url.substring(getStart, jermmReq.url.length)
    let getSplit = getString.split('&')
    let getParams = {}
    for(let ind in getSplit){
        let paramSplit = getSplit[ind].split('=')
        getParams[decodeURI(paramSplit[0])] = decodeURI(paramSplit[1])
        }
    jermmReq.getParams = getParams
    return jermmReq
}

let getHandler = function(req, res){
    let jermmReq = generateJermmReq(req)
    let response = ''
    let filePath = path.join(__dirname, path.join('/views',path.join(req.path, '/index.pug')))
    let pugInput = {jermmRepo: repo, jermmReq: jermmReq}
    if(fs.existsSync(filePath)) response = pug.renderFile(filePath, pugInput)
    else response = pug.renderFile(__dirname+'/views/404.pug', pugInput)
    let bubbles = bubbler.bubble(response)
    res.send(pug.renderFile(__dirname+'/views/global.pug', {viewBubbles: bubbles}))
    }

let postHandler = function(req, res){
    res.status(200)
    let jermmReq = generateJermmReq(req)
    let secondSlash = req.path.indexOf('/', 1)
    if(secondSlash == -1) secondSlash = req.path.length
    let command = req.path.substring(1,secondSlash)
    console.log('post command: ' + command)
    let address = req.path.substring(secondSlash, req.path.length)
    if(secondSlash == req.path.length) address = '/'
    console.log('post address: ' + address)
    jermmReq.postAddress = address;
    console.log('post contents: ')
    console.log(req.body)
    console.log('isRepo: ' + repo.hasOwnProperty(command))
    if(repo.hasOwnProperty(command)) res.send(repo[command](jermmReq, res))
    else res.status(503).send('Unknown command: ' + command)
    }

bot.get('/*', getHandler)
bot.post('/*', postHandler)
    console.log(repo)
    bot.listen(3000, function(){console.log('listening')})