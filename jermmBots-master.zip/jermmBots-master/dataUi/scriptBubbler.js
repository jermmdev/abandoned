let scriptBubbler = function(){
    let harvestCss = function(htmlBody){
        let harvestCss = htmlBody.match(/<style\b[^>]*>([\s\S]*?)<\/style>/gm)
        let newCss = ''
        for(let ind in harvestCss){
            htmlBody = htmlBody.replace(harvestCss[ind], '')
            harvestCss[ind] = harvestCss[ind].replace('<style>', '')
            harvestCss[ind] = harvestCss[ind].replace('</style>', '')
            harvestCss[ind] = '\r\n' + harvestCss[ind] + '\r\n'
            newCss += harvestCss[ind]
            }
        return {
            newBody: htmlBody
            , newCss: newCss
            }
        }
    let harvestJs = function(htmlBody){
        let harvestJs = htmlBody.match(/<script\b[^>]*>([\s\S]*?)<\/script>/gm)
        let newJs = ''
        for(let ind in harvestJs){
            htmlBody = htmlBody.replace(harvestJs[ind], '')
            harvestJs[ind] = harvestJs[ind].replace('<script>', '')
            harvestJs[ind] = harvestJs[ind].replace('</script>', '')
            harvestJs[ind] = '\r\nrunHarvestedScript = function(){' + harvestJs[ind] + '\r\n}; \r\nrunHarvestedScript();\r\n'
            newJs += harvestJs[ind]
            }
        return {
            newBody: htmlBody
            , newJs: newJs
            }
        }
    let bubbleScripts = function(htmlBody){
        let newCss = harvestCss(htmlBody)
        let newJs = harvestJs(newCss.newBody)
        return {
            html: newJs.newBody
            , css: newCss.newCss
            , js: newJs.newJs
            }
        }
    this.bubble = function(htmlBody){
        return bubbleScripts(htmlBody);
    }
}
module.exports = (new scriptBubbler())