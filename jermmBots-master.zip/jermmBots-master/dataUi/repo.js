let repo = function(){
    let JsonDB = require('node-json-db')
    let db = new JsonDB(__dirname+'/db.json', false, true)
    let core = this;
    let getData = function(address){
        db.reload()
        let dataResponse = {};
        try{
            dataResponse = db.getData(address)
        }catch(error){
            console.log('Error fetching data at: ' + address);
        }
        return JSON.parse(JSON.stringify(dataResponse))
        }
    let deleteData = function(address){
        try{
            db.delete(address)
            db.save()
            }
        catch(error){
            console.log('Error deleting data at: ' + address)
            }
        }
    let pushData = function(address, data){
        db.push(address, data)
        db.save()
        }
    let moveData = function(oldAddress, newAddress){
        let theData = getData(oldAddress)
        if(!theData) {
            theData = {}
            console.log('No original data found at: ' + oldAddress)
        }
        deleteData(oldAddress)
        pushData(newAddress, theData, false)
        db.save()
        }
    this.save = function(jermmReq, res){
        pushData(jermmReq.postAddress, jermmReq.body.jermmValue)
        console.log('Saved data to: ' + jermmReq.postAddress)
        return 'Saved data to: ' + jermmReq.postAddress
    }
    this.rename = function(jermmReq){
        let newName = jermmReq.body.jermmValue
        let oldAddress = jermmReq.postAddress
        let oldSplit = oldAddress.split('/')
        let oldName = oldSplit[(oldSplit.length - 1)]
        let newAddress = oldAddress.replace(oldName, newName)
        moveData(oldAddress, newAddress)
        console.log('Data moved from ('+oldAddress+') to ('+newAddress+')')
        return 'Data moved from ('+oldAddress+') to ('+newAddress+')'
    }
    this.getModule = function(jermmReq){
        return getData('/models/modules/'+jermmReq.getParams.n)
        }
    this.getData = getData;
    this.deleteData = function(jermmReq){
        deleteData(jermmReq.postAddress)
        console.log('Data deleted at: ' + jermmReq.postAddress)
    }
}
module.exports = (new repo())