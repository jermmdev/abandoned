let repository = function(){
    let JsonDB = require('node-json-db')
    let db = new JsonDB(__dirname+'/db.json', false, true)
    let core = this;

    let pushData = function(path, data){
        db.push(path, data, false)
        db.save()
    }
    this.pushData = pushData

    let getData = function(path){
        try{
            return db.getData(path)
        }catch(error){ 
            console.log('JermmData: No data found at ('+path+')')
            return null;
        }
    }
    this.getData = getData

    let deleteData = function(path){
        db.delete(path);
        db.save()
    }

    let moveData = function(oldPath, newPath){
        let theData = getData(oldPath);
        deleteData(oldPath);
        console.log('moving ('+oldPath+') (' + newPath + ')')
        pushData(newPath, theData);
    }
    this.moveData = moveData
}
module.exports = (new repository())