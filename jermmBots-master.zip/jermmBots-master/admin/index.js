let pug = require('pug')

let path = require('path')

let fs = require('fs')

let repo = require(__dirname+'/repository.js')

let express = require('express')
let bot = express();
bot.use(express.json());
bot.use(express.urlencoded());
let cookieParser = require('cookie-parser');
bot.use(cookieParser());

let harvestCss = function(htmlBody){
    let harvestCss = htmlBody.match(/<style\b[^>]*>([\s\S]*?)<\/style>/gm)
    let newCss = ''
    for(let ind in harvestCss){
        htmlBody = htmlBody.replace(harvestCss[ind], '')
        harvestCss[ind] = harvestCss[ind].replace('<style>', '')
        harvestCss[ind] = harvestCss[ind].replace('</style>', '')
        harvestCss[ind] = '\r\n' + harvestCss[ind] + ';\r\n'
        newCss += harvestCss[ind]
    }
    return {
        newBody: htmlBody
        , newCss: newCss
    }
}
let harvestJs = function(htmlBody){
    let harvestJs = htmlBody.match(/<script\b[^>]*>([\s\S]*?)<\/script>/gm)
    let newJs = ''
    for(let ind in harvestJs){
        htmlBody = htmlBody.replace(harvestJs[ind], '')
        harvestJs[ind] = harvestJs[ind].replace('<script>', '')
        harvestJs[ind] = harvestJs[ind].replace('</script>', '')
        harvestJs[ind] = '\r\nrunHarvestedScript = function(){' + harvestJs[ind] + '}; runHarvestedScript();\r\n'
        newJs += harvestJs[ind]
    }
    return {
        newBody: htmlBody
        , newJs: newJs
    }
}

bot.get('/*', function(req, res){
    let secondSlash = req.path.indexOf('/', 1)
    let command = req.path.substring(0,secondSlash)
    let address = req.path.substring(secondSlash, req.path.length)
    let status = 200;
    let response = '';

    switch(command){
        case '/editModel':
            let editModel = repo.getData('/models'+address)
            let allModels = repo.getData('/models')

            if(address.charAt(address.length-1) == '/') address = address.substring(0, address.length-1)
            let modelPaths = address.split('/');
            let modelName = modelPaths[modelPaths.length-1];
            let modelType = modelPaths[1]

            let viewModel = {
                model: editModel
                , modelName: modelName
                , modelSource: allModels
                , modelType: modelType
            }
            response = pug.renderFile(__dirname+'/modelEditor/editModule.pug', viewModel)
            break
        default:
            response = pug.renderFile(__dirname+'/404.pug')
            status = 404;
            break
    }
    let newCss = harvestCss(response)
    let newJs = harvestJs(newCss.newBody)
    res.status(status).send(pug.renderFile(__dirname+'/jermmViews/jermmGlobal.pug', {title: 'jermmBots Admin', viewBody: newJs.newBody, css: newCss.newCss, js: newJs.newJs}))
})
bot.post('/*', function(req, res){
    let secondSlash = req.path.indexOf('/', 1)
    let command = req.path.substring(0,secondSlash)
    let address = req.path.substring(secondSlash, req.path.length)
    let status = 200;
    switch(command){
        case '/pushData':
            console.log('pushing data ('+address+') ('+req.body.jermmData+')')
            repo.pushData(address, req.body.jermmData)
            res.status(status).send("JermmData Success")
            break
        case '/getData':
            res.status(status).send(repo.getData(address))
            break
        case '/moveData':
            if(address.charAt(address.length-1) == '/') address = address.substring(0, address.length-1)
            let splitAddress = address.split('/')
            let moveAddress = ''
            for(let ind in splitAddress){
                if(ind < (splitAddress.length - 1) && splitAddress[ind] != '') moveAddress += '/'+splitAddress[ind]
            }
            console.log('moving ('+address+') to ('+moveAddress+'/'+req.body.jermmData+')')
            repo.moveData(address, moveAddress+'/'+req.body.jermmData)
            res.status(status).send("JermmData Success")
            break
        default:
            status = 503
            res.status(status).send("JermmData Failure")
        }
})
bot.listen(3000, function(){console.log('listening')})