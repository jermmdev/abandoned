function viewJermmBot(jermmBots, config){
    this.jermmBotName = config.jermmBotName
    let debug = config.jermmDebug
    let views = {}
    let pug = require('pug');
    let fs = require('fs');
    let viewPath = __dirname+'/views/jermm';
    
    this.pugFiles = {};
    fs.readdirSync(__dirname+'/views').forEach(file => {
        let newInd = file.replace('.pug','')
        newInd = newInd.replace('jermm', '');
        viewFiles[newInd] = __dirname+'/views/'+file;
    })

    let harvestCss = function(htmlBody){
        let harvestCss = htmlBody.match(/<style\b[^>]*>([\s\S]*?)<\/style>/gm)
        let newCss = ''
        for(let ind in harvestCss){
            htmlBody = htmlBody.replace(harvestCss[ind], '')
            harvestCss[ind] = harvestCss[ind].replace('<style>', '')
            harvestCss[ind] = harvestCss[ind].replace('</style>', '')
            harvestCss[ind] = '\r\n' + harvestCss[ind] + ';\r\n'
            newCss += harvestCss[ind]
        }
        return {
            newBody: htmlBody
            , newCss: newCss
        }
    }
    let harvestJs = function(htmlBody){
        let harvestJs = output.match(/<script\b[^>]*>([\s\S]*?)<\/script>/gm)
        let newJs = ''
        for(let ind in harvestJs){
            htmlBody = htmlBody.replace(harvestJs[ind], '')
            harvestJs[ind] = harvestJs[ind].replace('<script>', '')
            harvestJs[ind] = harvestJs[ind].replace('</script>', '')
            harvestJs[ind] = '\r\nrunHarvestedScript = function(){' + harvestJs[ind] + '}; runHarvestedScript();\r\n'
            newJs += harvestJs[ind]
        }
        return {
            newBody: htmlBody
            , newJs: newCss
        }
    }

    let returnStockView = function(viewName, viewInput){
        let returnHtml = ""
        if(debug) return pug.renderFile(viewPath+viewName+'.pug', viewInput)
        if(!views[viewName]) views[viewName] = pug.compileFile(viewPath+viewName+'.pug')
        return views[viewName](viewInput);
    }

    this.renderStock = function(viewName, viewInput){
        if(viewName != "Global") return returnStockView(viewName, viewInput)

        let htmlBody = viewInput.viewBody
        let harvestedCss = harvestCss(htmlBody);
        let harvestedJs = harvestJs(harvestCss.newBody);
        viewInput.viewBody = harvestedJs.newBody;
        if(!viewInput.css) viewInput.css = '';
        if(!viewInput.js) viewInput.js = '';
        viewInput.css += harvestedCss.newCss;
        viewInput.js += ';'+harvestedJs.newJs;
        return returnStockView(viewName, viewInput);
    }

    let customViews = {};
    this.renderPug = function(viewName, pugFile, viewInput){
        if(debug) return pug.renderFile(pugFile)
        if(!customViews[viewName]) customViews[viewName] = pug.compileFile(pugFile)
        return customViews[viewName](viewInput)
    }
}
module.exports = viewJermmBot;