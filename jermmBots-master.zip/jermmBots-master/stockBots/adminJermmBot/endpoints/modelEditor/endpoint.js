let createProject = function(jermmBots){
    let fs = require('fs');
    let viewBot = jermmBots.adminViewBot
    this.jermmBotStockName = 'endpointJermmBot'
    this.render = function(request, response){
        let testModel = jermmBots.adminData.repository.getTestModel();
        let modelSource = jermmBots.adminData.repository.getModels();
        let thisView = viewBot.renderPug('the local')
        let actualReturn = viewBot.renderGlobal(
            
        )
        return {model: testModel, modelName: 'apiJermmBot', modelSource: modelSource, modelType: 'Module'}
        }
}
module.exports = createProject