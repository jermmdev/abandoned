module.exports = function(jermmBots){
    this.jermmBotName = 'gameNightApi';
    this.jermmBotStockName = 'apiJermmBot';
    this.apiHeader = 'jbAdmin';
    this.enableSessions = true;
    this.enableNav = true;
    this.loginLogic = function(req, res){
        let userName = req.body.userName;
        let password = req.body.password;
        if(!userName || !password) return false;

        let user = jermmBots.adminData.first('/users/'+userName);
        if(!user) return false;

        let passwordHash = user.password
        if(password == passwordHash){
            return true;
        } 
        return false;
    }
    let botEditor = jermmBots.jermmBotCreateStock(require('./endpoints/modelEditor/endpoint.js'))
    this.paths = {
        '/' : {
            navName: 'Projects'
            , mirrors: ['/projects']
            , endpoint: botEditor
            , children: {
                '/projects/edit': {
                    navName: 'Create Project'
                    , endpoint: botEditor
                    }
                }
            }
        , '/bots': {
            navName: 'Bots'
            , endpoint: botEditor
            , children: {
                '/bots/edit': {
                    navName: 'Create Bot'
                    , endpoint: botEditor
                }
            }
            }
        }
    }