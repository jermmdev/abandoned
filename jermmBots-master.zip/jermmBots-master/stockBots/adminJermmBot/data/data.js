module.exports = function (jermmBots) {
    this.jermmBotName = 'adminData';
    this.jermmBotStockName = 'dataJermmBot';
    this.databaseFile = __dirname + '/db.json';
    this.repository = function (dataBot) {
        this.getProjects = function(){
            return dataBot.select('/projects');
            }
        this.getTestModel = function(){
            return dataBot.select('/models/modules/apiJermmBot');
            }
        this.getModels = function(){
            return dataBot.select('/models');
            }
        }
}