//connect hostJermmBot TO logicJermmBot
function sessionJermmBot(jermmBots, config){
    let sessions = [];
    let sessionTimer = config.jermmBotSessionTimer; //minutes
    let lastActionTimer = config.jermmBotLastActionTimer; //minutes
    let sessionRestricted = config.jermmBotSessionRestricted || [];
    this.jermmCookieName = 'jermmSessionCookie'+config.jermmBotName;
    let jermmCookieName = this.jermmCookieName;
    let redirMsg = [];

    let crypto = require('crypto');
    let genRandomString = function(length){
        return crypto.randomBytes(Math.ceil(length/2))
                .toString('hex') /** convert to hexadecimal format */
                .slice(0,length);   /** return required number of characters */
    };
    let salt = genRandomString(16);

    let sha512 = function(password, salt){
        let hash = crypto.createHmac('sha512', salt); /** Hashing algorithm sha512 */
        hash.update(password);
        let value = hash.digest('hex');
        return {
            salt:salt,
            passwordHash:value
        };
    };

    let addMinutes = function(date, minutes){
        return new Date(date.getTime() + minutes*60000);
    }
    let clearSession = function(token){
        if(sessions[token]) delete sessions[token];
        return false;
    }
    let sessionIsValid = function(token, ip){
        let session = sessions[token];
        if(!session) return clearSession(token);
        if(session.ip != ip) return clearSession(token);
        if(!sessionTimer) return true;
        if(session.created < addMinutes(new Date(), sessionTimer)) return clearSession(token);
        if(!actionTimer) return true;
        if(session.lastAction < addMinutes(new Date(), lastActionTimer)) return clearSession(token);
        return true;
    }
    this.createSession = function(req, res){
        let newToken = sha512(req.connection.remoteAddress,genRandomString(16));
        let newSession = {};
        newSession.created = new Date();
        newSession.lastAction = new Date();
        newSession.ip = req.connection.remoteAddress;
        sessions[newToken] = newSession;
        res.cookie(jermmCookieName, newToken)
        return newToken;
    }
    this.eraseSession = function(req){
        let ip = req.connection.remoteAddress
        let token = req.cookies[jermmCookieName]
        return clearSession(token);
    }
    this.checkRequestSession =function(request){
        let currentToken = request.cookies[jermmCookieName];
        let validSesh = sessionIsValid(currentToken, request.connection.remoteAddress);
        return validSesh;
    }
    this.setRedirMsg = function(ip, path){
        redirMsg[ip]= path;
        setTimeout(function(){
            if(redirMsg[ip]) delete redirMsg[ip];
        }, (30*1000));
    }
    this.getRedirMsg = function(ip){
        let msg = redirMsg[ip];
        if(redirMsg[ip]) delete redirMsg[ip];
        return msg;
    }
}
module.exports = sessionJermmBot;