let navBot = function(jermmBots){
    let pug = require('pug');
    let navBarView = pug.compileFile(__dirname+'/navBar.pug');
    let navDrill = function(paths, inputPath, forbidden){
        let newSet = [];
        for(let path in paths){
            let pathObj = paths[path];
            let forbiddenPath = false;
            for(let ind in forbidden){
                if(path == forbidden[ind]) forbiddenPath = true;
            }
            if(path != forbiddenPath && pathObj.navName){
                let newObj = {};
                newObj.fullPath = path;
                newObj.active = path == inputPath ? true : false;
                for(let ind in pathObj.mirrors){
                    let mirror = pathObj.mirrors[ind]
                    if(mirror == inputPath) newObj.active = true;
                }
                newObj.navName = pathObj.navName;
                let theChildren = [];
                theChildren = navDrill(pathObj.children, inputPath, forbidden);
                if(theChildren.length > 0) {
                    newObj.children = theChildren
                    for(let cind in theChildren){
                        let cobj = theChildren[cind];
                        if(cobj.active) newObj.active = true;
                    }
                };
                newSet.push(newObj);
            }
        }
        return newSet;
    }
    this.render = function(paths, inputPath, forbidden){
        let newSet = navDrill(paths, inputPath, forbidden)
        if(newSet.length > 0) return navBarView({apiData:{navOptions: newSet}});
        else return '';
    }
}
module.exports = navBot;