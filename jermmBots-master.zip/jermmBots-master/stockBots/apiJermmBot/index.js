function apiJermmBot(jermmBots, config){
    let paths = config.paths;
    let apiHeader = config.apiHeader;
    let apiHeaderHtml = '<h3 class="text-center">'+apiHeader+'</h3>'
    let sessionBot = config.enableSessions ? jermmBots.jermmBotCreateStock(function(jermmBots){this.jermmBotStockName = 'sessionJermmBot'}) : false;
    let navBot = config.enableNav ? jermmBots.jermmBotCreateStock(function(jermmBots){this.jermmBotStockName = 'navJermmBot'}) : false;
    let loginPath = config.loginViewPath || '/jermmApiLogin'
    let listenerPath = config.loginListenerPath || '/jermmApiLoginListener'
    let loginSuccessPath = config.loginSuccessPath || '/'
    let loginUserLabel = config.loginUserLabel || 'User'
    let rootPath = config.rootPath || ''
    
    if(config.enableSessions){
        paths[loginPath] = {
            navName: 'Logout'
            , endpoint: jermmBots.jermmBotCreateStock(function(jermmBots){
                this.jermmBotStockName = 'endpointJermmBot'
                this.jermmDebug = true
                this.parent = 'default'
                this.render = function(req, res){
                    let redirMessage = sessionBot.getRedirMsg(req.connection.remoteAddress);
                    return {listenerPath: listenerPath, redirMessage: redirMessage}
                    }
                })
            }
        paths[listenerPath] = {
            endpoint: {
                render: function(req, res){
                    if(config.loginLogic(req, res)){
                        sessionBot.createSession(req, res);
                        res.send({loginSuccessUrl: loginSuccessPath});
                        }
                    else{
                        res.send({loginFailMessage: 'Login failed.'});
                        }
                    }
                }
            }
        }

    let listenAtPaths = config.listenAtPaths ? config.listenAtPath : function(inputPaths, bot){
        for(let path in inputPaths){
            let pathObj = inputPaths[path];
            if(pathObj.children){
                listenAtPaths(pathObj.children, bot);
            }
            listenAtPath(path, pathObj, bot);
            }
        }
        
    let listenAtPath = config.listenAtPath ? config.listenAtPath : function(path, pathObj, bot){
        let navHtml = path!=loginPath && config.enableNav ? navBot.render(paths, path) : '';
        let answerRequest = config.answerRequest ? config.answerRequest : function(req, res){
            res.__defineGetter__('headerSent', function(){
                return this._header;
                });
            let ip = req.connection.remoteAddress;
            if(path != loginPath && path != listenerPath && !sessionBot.checkRequestSession(req)){
                sessionBot.setRedirMsg(ip, path);
                res.redirect(loginPath)
                return;
                }
            if(path == loginPath) sessionBot.eraseSession(req);
            
            let viewResponse = '';
            if(pathObj.endpoint) viewResponse = pathObj.endpoint.render(req, res, apiHeaderHtml+navHtml);
            if(!res.headerSent) res.send(viewResponse);
            return;
        }
        console.log('Listening: ' + path)
        bot.get(path, answerRequest);
        bot.post(path, answerRequest);
        for(let ind in pathObj.mirrors){
            console.log('Listening: ' + pathObj.mirrors[ind])
            bot.post(pathObj.mirrors[ind], answerRequest)
            bot.get(pathObj.mirrors[ind], answerRequest)
            }
        }
    
    this.jermmBotLogic = function(bot){
        listenAtPaths(paths, bot, [listenerPath]);
        let notFoundViewBot = jermmBots.jermmBotCreateStock(function(jermmBots){
            this.jermmBotStockName = 'endpointJermmBot'
            this.jermmBotViewHead = {
                title: '404'
                }
            this.jermmDebug = true
            this.parent = "default"
            this.render = function(req, res){
                return '<h3>404: '+req.path+'</h3><h4>This api is not serving this address.</h4>'
                }
            })
        bot.get(rootPath+'/*', function(req, res){
            let navHtml = navBot.render(paths, req.path);
            let ip = req.connection.remoteAddress;
            if(config.enableSessions && !sessionBot.checkRequestSession(req)){
                sessionBot.setRedirMsg(ip, req.path);
                res.redirect(loginPath)
                } 
            else{
                let viewResponse = notFoundViewBot.render(req, res, apiHeaderHtml+navHtml);
                res.status(404).send(viewResponse);            
                } 
            })
        }
    }

module.exports = apiJermmBot;