function dataJermmBot(jermmBots, config){
    let jbDataCore = this;
    let jbUtil = new (require('./../utilJermmBot/index.js'))(jermmBots);
    let JsonDB = require('node-json-db');
    let db = new JsonDB(config.databaseFile, false, false);

    let getDataResponse = function(address){
        try{
            return db.getData(address);
        }catch(error){
            console.log('--dataJermmBot Error')
            console.log('Error fetching data at: ' + address);
            console.log(error.message);
            console.log('--');
            return null
        }
    }

    this.first = function(address, matchObj, matchAny){
        var dataResponse = getDataResponse(address);
        if(!matchObj) return dataResponse
        for(let ind in dataResponse){
            let data = dataResponse[ind];
            if(jbUtil.findObjectMatch(data, matchObj, matchAny)) return data;
        }
        return null;
    }

    this.select = function(address, matchObj, matchAny){
        var dataResponse = getDataResponse(address);
        if(!matchObj) return dataResponse;
        let matches = {}
        for(let ind in dataResponse){
            let data = dataResponse[ind];
            if(jbUtil.findObjectMatch(data, matchObj, matchAny)) matches[ind]=dataResponse[ind];
        }
        return matchResponse;
    }
    this.delete = function(address){
        db.delete(address);
        db.save();
    }
    this.upsert = function(address, upsertObj){
        let result = db.push(address, upsertObj, false);
        db.save();
        return result;
    }

    this.repository = new config.repository(jbDataCore);
}
module.exports = dataJermmBot;