function endpointJermmBot(jermmBots, config){
    this.jermmBotName = config.jermmBotName

    this.render = function(req, res){
        config.render(req, res)
    }
}
module.exports = endpointJermmBot;