let pm = require('./processManager.js')

let express = require('express')
let bot = express()
bot.use(express.json())
bot.use(express.urlencoded())

let pug = require('pug')

bot.get('/*', function(req, res){
    try{
        res.status(200).send(pug.renderFile('./views/yggdrasil.pug', {pm: pm}))
        return
    }catch(error){
        res.status(503).send('Error loading page... big one...')
    }
})
bot.post('/*', function(req, res){
    if(req.body.loadScript){
        try{
            pm.loadScript(req.body.loadScript)
            res.status(200).send('Script Loaded')
            return
        }catch(error){
            res.status(503).send('Error loading script.')
            return
        }
    }
    if(req.body.killScript){
        try{
            pm.killScript(req.body.killScript)
            res.status(200).send('Script Killed')
            return
        }catch(error){
            res.status(503).send('Error loading script.')
            return
        }
    }
    res.status(404).send('Post command not found.')
})
bot.listen(4422, function(){
    console.log('Yggdrasil listening.')
})