let JsonDB = options.jsonDb
let db = new JsonDB(options.database, false, true)

let getData = function(address){
    db.reload()
    let dataResponse = {};
    try{
        dataResponse = db.getData(address)
    }catch(error){
        console.log('Error fetching data at: ' + address);
    }
    return JSON.parse(JSON.stringify(dataResponse))
    }
this.getData = getData

let deleteData = function(address){
    try{
        db.delete(address)
        db.save()
        }
    catch(error){
        console.log('Error deleting data at: ' + address)
        }
    }
this.deleteData = deleteData

let pushData = function(address, data){
    db.push(address, data)
    db.save()
    }
this.pushData = pushData
this.moveData = function(oldAddress, newAddress){
    let theData = getData(oldAddress)
    if(!theData) {
        theData = {}
        console.log('No original data found at: ' + oldAddress)
        }
    deleteData(oldAddress)
    pushData(newAddress, theData, false)
    db.save()
    }