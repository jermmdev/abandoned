let path = options.path
let fs = options.fs
let express = options.express
let pug = options.pug
let bubbler = options.htmlBubbler

let viewsDir = options.viewsDir || '/'
let repo = options.repo || {}
let listener = options.listener || {}
let port = options.port || 3000
let rootPath = options.rootPath || '/'

let bot = express()
    bot.use(options.cookieParser())
    bot.use(express.json())
    bot.use(express.urlencoded())

let notFoundPageExists = fs.existsSync(path.join(viewsDir, '/404.pug'))
let errorPageExists = fs.existsSync(path.join(viewsDir, '/503.pug'))

let generateGetParams = function(req){
    let url = req.url
    if(url.charAt(0) != '/') url = url.substring(1, url.length)
    let getStart = url.indexOf('?') + 1
    let getString = url.substring(getStart, url.length)
    let getSplit = getString.split('&')
    let getParams = {}
    for(let ind in getSplit){
        let paramSplit = getSplit[ind].split('=')
        getParams[decodeURI(paramSplit[0])] = decodeURI(paramSplit[1])
        }
    req.getParams = getParams
    return req
    }
let getHandler = function(req, res){
    req = generateGetParams(req)
    let response = ''
    let filePath = path.join(viewsDir, path.join(req.path, '/index.pug'))
    let pugInput = {repo: repo, req: req}
    if(fs.existsSync(filePath)){
        try{
            response = pug.renderFile(filePath, pugInput)
        }catch(error){
            console.log('--start: error rendering pug file--')
            console.log(error)
            console.log('--end: error rendering pug file--')
            res.status(503)
            if(errorPageExists){
                response = pug.renderFile(path.join(viewsDir,'/503.pug'), pugInput)
            }else{
                response = '<html><head><title>503: Error</title></head><body><h1>503: Oops, my bad.</h1></body></html>'
            }
            res.send(response)
            return;
        }
    } else {
        res.status(404)
        if(notFoundPageExists){
            response = pug.renderFile(path.join(viewsDir,'/404.pug'), pugInput)
        }else{
            response = '<html><head><title>404: Not Found</title></head><body><h1>404: Path not found. (' + req.path + ')</h1></body></html>'
        }
        res.send(response)
        return
    }
    response = bubbler.bubble(response)
    res.status(200).send(response)
    }

let postHandler = function(req, res){
    req = generateGetParams(req)
    let secondSlash = req.path.indexOf('/', 1)
    if(secondSlash == -1) secondSlash = req.path.length
    let command = req.path.substring(1,secondSlash)
    if(listener.hasOwnProperty(command)){
        let response = null;
        try{
            console.log('trying listener at: ' + command)
            response = listener[command](req)
        }catch(error){
            res.status(503).send('503: Oops, my bad.')
            return;
        }
        res.status(200).send(response)
        return
    }else{
        res.status(404).send('404: Unknown Command (' + command + ')')
        return
    } 
    }

let listenPath = '/*'
if(rootPath.length && rootPath.length > 1) listenPath = path.join(rootPath, '/*')
bot.get(listenPath, getHandler)
bot.post(listenPath, postHandler)
bot.listen(port, function(){
    console.log('pugHost listening on port: ' + port)
})