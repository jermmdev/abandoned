let processManager = function(){
    const { spawn } = require('child_process');
    let scripts = {}
    this.scripts = scripts

    let overloadTimer = 60000
    let overloadCounter = 0
    this.loadScript = function(scriptName){
        if(scripts[scriptName]){
            throw('Already running script. (' + scriptName + ')')
            return
        }
        let loadTime = Date.now()
        let newScript = spawn('node', ['loadScript', scriptName]);
        newScript.stdout.on('data', (data) => {
            console.log('== CONSOLE: ' + scriptName + ' ==')
            console.log(`${data}`);
        });
        
        newScript.stderr.on('data', (data) => {
            console.log('== ERROR: ' + scriptName + ' ==')
            console.log(`${data}`);
        });
        
        newScript.on('close', (code) => {
            console.log('== CLOSE: ' + scriptName + ' ==')
            console.log(`Exit code: ${code}`);
            if(`${code}`=='4242' && overloadCounter < 3) {
                let dateNow = Date.now()
                let timeDiff = dateNow - loadTime
                if( timeDiff < overloadTimer ){
                    overloadCounter++
                    setTimeout(function(){overloadCounter--}, (overloadTimer - timeDiff))
                }
                loadScript(scriptName, dateNow)
            }
        });
        scripts[scriptName] = newScript
    }
    this.killScript = function(scriptName){
        if(!scripts[scriptName]){
            throw('No script running. (' + scriptName + ')')
            return
        }
        scripts[scriptName].kill('SIGKILL')
        delete scripts[scriptName]
    }
}
module.exports = new processManager()