let scriptName = process.argv[(process.argv.length-1)]
if(!scriptName || !(typeof(scriptName) == 'string')){
    throw("Script path invalid. (" + scriptName + ")")
    process.exit()
}
let njdb = require('node-json-db')
let locals = {}
let db = new njdb(__dirname+'/db.json', false, true)
let scriptObj = db.getData('/scripts/'+scriptName)

let loadBasic = function(basicName, basicValue){
    if(basicName == 'int') return parseInt(basicValue)
    if(basicName == 'float') return parseFloat(basicValue)
    if(basicName == 'date') return new Date(basicValue)
    if(basicName == 'string') return basicValue
    if(basicName == 'json') return JSON.parse(basicValue)
}
let loadLogic = function(dataPath = false, logiName = false, inputs = false, dependencies = false, code = ''){
    let options = {}
    console.log('logiloading: '+logiName)
    let logiFunction = function(){}
    let logiData = {}

    if(logiName) logiData = db.getData(dataPath+logiName)
    if(logiName) dependencies = logiData.dependencies

    for(let inputInd in inputs){
        let inputText = inputs[inputInd]
        let inputSplit = inputText.split('/')
        let inputType = inputSplit[0]
        let inputName = inputSplit.length > 0 ? inputSplit[1] : false
        let inputValue = inputSplit.length > 1 ? inputSplit[2] : false
        for(let splitInd = 3; splitInd < inputSplit.length; splitInd++){
            inputValue += '/' + inputSplit[splitInd]
        }
        console.log('inputType: ' + inputType)
        switch(inputType){
            case "basic":
                console.log('basicLoaded: ' + inputInd)
                options[inputInd] = loadBasic(inputName, inputValue)
                break
            case "locals":
                console.log('localLoaded: ' + inputInd + '/' + inputName)
                options[inputInd] = locals[inputName]
                break
        }
    }
    for(let depInd in dependencies){
        let dependencyObj = dependencies[depInd]
        let dependency = dependencyObj.model
        let depSplit = typeof(dependency) == 'string' ? dependency.split('/') : []
        let depType = depSplit[0]
        let depName = depSplit.length > 0 ? depSplit[1] : false
        switch(depType){
            case "npm":
            case "node":
                console.log('npmloaded: '+depName)
                options[depInd] = require(depName)
                break
            case "modules":
                options[depInd] = loadLogic('/models/modules/', depName)
                break
        }
    }

    let logiFunc = function(){}
    if(logiName && logiData.code) logiFunc = Function('options', logiData.code)
    if(!logiName && code) logiFunc = Function(code)
    return new logiFunc(options)
}

let scripts = scriptObj
for(let scriptInd in scripts){
    let script = scripts[scriptInd]

    let fullModel = script.model
    let modelSplit = fullModel.split('/')
    let modelType = modelSplit[0]
    let modelName = modelSplit.length > 0 ? modelSplit[1] : false
    let modelValue = modelSplit.length > 1 ? modelSplit[2] : false

    switch(modelType){
        case 'basic':
            locals[scriptInd] = loadBasic(modelName, modelValue)
            break
        case 'npm':
        case 'node':
            locals[scriptInd] = require(modelName)
            break
        case 'modules':
            locals[scriptInd] = loadLogic('/models/modules/', modelName, {}, script.dependencies, script.code)
            break
        case 'bots':
            locals[scriptInd] = loadLogic('/models/bots/', modelName, script.inputs, script.dependencies, script.code)
            break
    }
}