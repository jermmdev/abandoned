let fs = require('fs')
let path = require('path')
let thanosPic = fs.readFileSync(path.join(__dirname, 'thanos.jpg'))
let express = require('express')
let pug = require('pug')
let bodyParser = require('body-parser')
let askThanos = pug.compileFile(path.join(__dirname, 'askThanos.pug'))
let app = new express()
app.use(bodyParser())
let thanosQuotes = {
    "Daughter...": {}
    , "Yes.": {}
    , "...Everything.": {}
    , "The Tesseract? Or your brother's head? I assume you have a preference?": {}
    , "You should have gone for the head.": {}
    , "Insect!": {}
    , "I saved you.": {}
    , "You were going to bed hungry, scrounging for scraps. Your planet was on the brink of collapse. I'm the one who stopped that. You know what's happened since then? The children born have known nothing but full bellies and clear skies. It's a paradise.": {}
    , "A small price to pay for salvation.": {}
    , "Little one, it's a simple calculus. This universe is finite, its resources, finite. If life is left unchecked, life will cease to exist. It needs correcting.": {}
    , "I'm the only one who knows that. At least, I'm the only one with the will to act on it.": {}
    , "Well, if you consider failure experience.": {}
    , "Fun isn't something one considers when balancing the universe. But this... does put a smile on my face.": {}
    , "In time, you will know what it's like to lose. To feel so desperately that you're right. Yet to fail all the same. Dread it. Run from it. Destiny still arrives." : {}
    , "You're strong... but I could snap my fingers... and you'd all cease to exist.": {}
    , "You have my respect, Stark. When I'm done, half of humanity will still be alive. I hope they remember you.": {}
    , "Stark.": {}
    , "I do. You're not the only cursed with knowledge.": {}
    , "I know what it's like to lose. To feel so desperately that you're right, yet to fail nonetheless. It's frightening, turns the legs to jelly. I ask you to what end? Dread it. Run from it. Destiny arrives all the same. And now it's here. Or should I say, I am.": {}
    , "Titan was like most planets. Too many mounds, not enough to go around. And when we faced extinction I offered a solution.": {}
    , "At random. Dispassionate, fair to rich and poor alike. And they called me a mad man. And what I predicted came to pass.": {}
    , "I'm a survivor.": {}
    , "With all the six stones, I could simply snap my fingers, and they would all cease to exist. I call that... mercy.": {}
    , "I finally rest, and watch the sunrise on an ungrateful universe. The hardest choices require the strongest wills.": {}
    , "Our?": {}
    , "When I'm done, half of humanity will still exist. Perfectly balanced, as all things should be... I hope they remember you.": {}
    , "No resurrections this time.": {}
    , "How is it you know this place so well?": {}
    , "Today I lost more than you could know, but now is no time to mourn. Now, is no time at all.": {}
    , "What's this?": {}
    , "Tell me what it needs.": {}
    , "Of what?": {}
    , "So I've been told.": {}
    , "The hardest choices require the strongest will.": {}
    , "All this, just for a drop of blood.": {}
    , "I know what it's like to lose. To feel so desperately that you're right, yet to fail none the less.": {}
    , "Frightening. Turns the legs to jelly. I ask you to what end? Dread it? Run from it? Destiny arrives all the same, and now it's here. Or should I say: I am.": {}
    , "The Tesseract or, your brother's head. I assume you have a preference.": {}
    , "Your optimism is misplaced, Asgardian.": {}
    , "That was a mistake": {}
    , "There are two more stones on Earth. Find them my children, bring them to me on time.": {}
    , "Undying? You should chose your words more carefully.": {}
    , "No resurrections this time.": {}
    , "You're full of tricks, wizard.": {}
    , "What's wrong little one?": {}
    , "What's your name?": {}
    , "You're quite the fighter Gamora. Come, let me help you.": {}
    , "Look.": {}
    , "Pretty, isn't it?": {}
    , "Perfectly balanced, as all things should be. Too much to one side and the other...": {}
    , "Here, you try.": {}
    , "Uh-uh, concentrate. There, you got it.": {}
    , "I take it the Maw's dead. This day extracts a heavy toll, still he accomplished his mission.": {}
    , "Where do you think he brought you?": {}
    , "With all six stones I can simply snap my fingers and it'll all cease to exist. I call that, mercy.": {}
    , "I finally rest, and watch the sunrise on a grateful universe. The hardest choices require the strongest will.": {}
    , "You know us?": {}
    , "Where is the Soul Stone?": {}
    , "I am prepared.": {}
    , "Oh, daughter. You expect too much from him.": {}
    , "She's asked, hasn't she?": {}
    , "Do it!": {}
    , "Well, well.": {}
    , "Would have been a waste of parts.": {}
    , "You're strong. Me, the generous... me. But I never taught you to lie. That's why you're so bad at it.": {}
    , "You have my respect Stark. When I'm done, half of humanity will still be alive. I hope They remember you.": {}
    , "Today I lost more than you could know, but now is no time to mourn. Now, is no time at all.": {}
    , "Ah, the boyfriend.": {}
    , "I ignored my destiny once. I cannot do that again. Even for you. I'm sorry, Gamora.": {}
}
let getRandomQuote = ()=>{
    let quotes = Object.keys(thanosQuotes)
    let top = quotes.length
    let bottom = 0
    let random = Math.floor(Math.random() * (top - bottom + 1)) + bottom
    return quotes[random]
}
app.get('/thanos.jpg', (req, res)=>{
    res.send(thanosPic)
})
app.get('/brain', (req, res)=>{
    res.send(thanosQuotes)
})
app.get('/*', (req, res)=>{
    askThanos = pug.compileFile(path.join(__dirname, 'askThanos.pug'))
    res.send(askThanos({quote: getRandomQuote()}))
})
app.post('/search', (req, res)=>{
    res.type('json')
    let query = req.body.query
    let results = {}
    let firstMatch = "Placeholder Match"
    for(let thanosQuote in thanosQuotes){
        if(firstMatch==="Placeholder Match") firstMatch = thanosQuote
        let quoteData = thanosQuotes[thanosQuote]
        for(let searchTerm in quoteData){
            if(query.includes(searchTerm)){
                if(!results[thanosQuote]) results[thanosQuote] = 0
                results[thanosQuote] += quoteData[searchTerm].score
            }
        }
    }
    let sortedQuotes = Object.keys(results).sort((a, b)=>{
        return results[a]-results[b]
    })
    if(sortedQuotes.length == 0) sortedQuotes.push(getRandomQuote())
    res.send({quote: sortedQuotes[0]})
})
app.post('/train', (req, res)=>{
    res.type('json')
    res.status(200).send({success: true})
    let washedResult = req.body.result.replace('\\','')
    console.log('washed result', washedResult)
    if(!thanosQuotes[washedResult]){
        console.error('bad result passed')
        return
    }
    let direction = parseInt(req.body.goodOrBad)
    for(let queryInd in req.body.query){
        let searchTerm = req.body.query[queryInd]
        console.log('search term', searchTerm)
        if(!thanosQuotes[washedResult][searchTerm] && direction > 0){
            thanosQuotes[washedResult][searchTerm] = {count: 0, score: 0}
        }
        if(thanosQuotes[washedResult][searchTerm]){
            thanosQuotes[washedResult][searchTerm].count += direction
            console.log('new count', thanosQuotes[washedResult][searchTerm].count)
            if(thanosQuotes[washedResult][searchTerm].count <= 0){
                console.log('result deleted', searchTerm)
                delete thanosQuotes[washedResult][searchTerm]
            }
        }
    }
    let totals = {inputs: {}, outcomes: {}, grand: 0}
    for(let thanosQuote in thanosQuotes){
        let searchTraining = thanosQuotes[thanosQuote]
        totals.inputs[thanosQuote] = 0
        for(let searchTerm in searchTraining){
            let outcomeCount = searchTraining[searchTerm].count
            if(!totals.outcomes[searchTerm]) totals.outcomes[searchTerm] = 0
            totals.inputs[thanosQuote] += outcomeCount
            totals.outcomes[searchTerm] += outcomeCount
            totals.grand += outcomeCount
        }
    }
    for(let thanosQuote in thanosQuotes){
        let searchTraining = thanosQuotes[thanosQuote]
        let inputTotal = totals.inputs[thanosQuote]
        for(let searchTerm in searchTraining){
            let searchCount = searchTraining[searchTerm].count
            let outcomeTotal = totals.outcomes[searchTerm]
            let grandTotal = totals.grand
            let probBoth = parseFloat(searchCount / outcomeTotal)
            let probInput = parseFloat(inputTotal / grandTotal)
            let probOutcome = parseFloat(outcomeTotal / grandTotal)
            let finalScore = parseFloat(parseFloat(probBoth * probInput) / probOutcome)
            thanosQuotes[thanosQuote][searchTerm].score = finalScore
        }
    }
})
app.listen(8080, ()=>{console.log('online')})