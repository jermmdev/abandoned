# Ask Thanos
http://starter-site-starter-site.1d35.starter-us-east-1.openshiftapps.com/